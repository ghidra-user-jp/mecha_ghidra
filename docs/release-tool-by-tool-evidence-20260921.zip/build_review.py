from pathlib import Path
import ast
import inspect
import json

from ghidra_mcp.contracts.tool_spec import get_all_tool_specs
from ghidra_headless.handlers.core_command_registry import COMMAND_TO_IMPL

ROOT = Path('/Users/samsepi0l/ghidra/mecha_ghidra')
WORK = Path(__file__).resolve().parent

# Each entry records the individual review, rather than deriving conclusions from test names.
NOTES = '''
list_targets|L|登録のみ・ロード済みの両状態、取得中のcloseとの競合、返却するdomain_pathを確認。
create_project|L|.gpr名の正規化、既存.gpr/.repの保護、overwrite時の使用中判定、作成後closeを確認。
open_program|L|新規targetの作成、初回解析・保存、失敗時の旧binding復元とconsumer解放を確認。解析を伴うwriteとして説明されている。
register_target|L|プログラムを開かずprojectを登録する動作、別projectにロード中のtargetとの衝突、再登録の扱いを確認。
close_session|L|通常の保存、discard時の未保存破棄、quarantine回復、close失敗時の状態保持を確認。projectの登録は残る。
close_session_and_remove_program|L|remove_program=Trueの配線、versionedファイル拒否、closeとprivateファイル削除の順序を確認。
list_project_programs|L|DomainFileの一覧と同期情報、project-only target、PROJECT_LOCKED時のmetadata snapshotの明示を確認。
import_program|L|auto/rawの切替、BinaryLoaderの数値変換、entry bootstrap、重複名、後処理失敗のrollbackとpartial_importを確認。
load_project_program|L|同一プログラムの再open、切替前の保存、過去versionのread-only、別targetの所有、初期化失敗の復元を確認。
save_project_program|L|現在のdomain_pathとの一致、Program.isChangedによる保存判定、保存後のdirty/pending_syncの扱いを確認。
get_program_info|P|Program Informationの未登録optionを読み取りで作らないこと、revision、dirty、undo/redo、entry上限を確認。既存のGhidra hash属性を読むだけ。
undo_program_change|P|count=1..100、履歴なしのnoop、実際のundo件数、decompilerとdirty状態の追従を確認。履歴はreloadで消える。
redo_program_change|P|redo件数、履歴枯渇時の停止、返却する残り履歴、undo後の状態復元を確認。
export_program|P|許可rootで解決したパスをそのまま使用、overwrite/親ディレクトリ、exporter失敗の伝播を確認。gzfは保存済み状態を出力する仕様。
list_scripts|S|実行せずcatalogを列挙、runtime/category/originで絞込、offset/limit、bundled公開設定とavailabilityを確認。
get_script_info|S|完全ID・一意な短名・曖昧名の扱い、snapshotからのsource取得、サイズ超過時のsource_truncatedを確認。
run_script|S|sourceとIDの排他、runtime判定、args/timeout/revision、Java/Jython/PyGhidra例外、transaction、残存thread、inline後始末を確認。timeoutは協調キャンセル。
get_bsim_database_status|B|DB初期化/close、count/categories/backend情報、PostgreSQL追加情報の任意性、資格情報のmaskを確認。
bsim_add_executable_category|B|category名の検証、既存categoryのalready_exists、登録結果とDB closeを確認。
list_bsim_executables|B|name/md5/arch/compilerとlimitの転送、category情報、満杯ページのtruncated、資格情報maskを確認。
get_bsim_executable|B|nameの完全一致による再選別、複数候補の拒否、100件+sentinelで不完全な一意性判断を防ぐ実装を確認。
bsim_update_executable_metadata|B|既存category名、完全MD5/名前、最新recordからのcategory merge、空値での削除、bad_executables返却を確認。
bsim_load_matched_executable|B|matched_refのversion/MD5/path/関数、既存target再利用、remote cacheのhost/port/repo、ロード検証失敗のrollbackを確認。
bsim_register_target|B|署名生成とDB insert、library stub件数、事前category設定、checkout要求、DB/GenSignatures解放を確認。categoryは先にProgram Informationへ保存する仕様。
bsim_apply_matches|B|F1・F2修正済。自己除外後の件数、significance、既定名のみ、同率別名の除外、dry_run、部分的rename失敗の明示を確認。
bsim_update_target_signatures|B|feature vectorを再生成しない更新、未登録Program拒否、DBのみのcategory保持、更新・失敗件数を確認。
bsim_delete_executable|B|confirm照合、名前の完全一致・一意性、対象MD5を固定したdelete、missedと実削除件数を確認。
list_functions|F|大文字小文字を無視したfilterとDEFAULT sourceによる絞込がpaginationより先、body size・thunk情報を確認。
list_namespaces|M|global除外、namespace階層の列挙、SymbolTypeによるClass判定、絞込後のpaginationを確認。
decompile_function|F|address優先・名前の一意性、function containing、失敗伝播、decompiler再利用と大きな結果の回収を確認。
create_function|E|既存entryはcreated=false、関数内部は拒否、必要時のみdisassemble、作成失敗時rollbackを確認。
delete_function|E|entry/包含関数の選択、removeFunctionの成否確認、命令を残して関数定義を削除する範囲を確認。
analyze_program|E|解析済みのnoopとforce、解析transaction、分析完了のmark、例外伝播を確認。
get_function|F|address優先・同名の曖昧性、prototype、local/parameter storage、namespace、thunk、bodyの返却を確認。
list_segments|M|MemoryBlockの範囲・サイズ・R/W/Xとoffset/limit、空結果を確認。
list_imports|M|ExternalSymbolsの列挙、library・full_name・address、paginationを確認。
list_exports|M|external entryからprimary symbolを取得、export判定後のpaginationを確認。
list_data_items|M|DefinedDataのみ、型名はDisplayName、label/value/length、paginationを確認。
list_strings|M|hasStringValueによる選択、case-insensitive filter後のpagination、標準limit=2000を確認。
get_data_by_label|M|同じ短いlabel名の全symbolを列挙し、DefinedDataAtがあるものだけ返す処理を確認。namespace付きの一意選択APIではない。
list_data_types|M|category完全一致とname/display/pathの部分一致、絞込後のpagination、型の要約を確認。
get_bytes|M|size=1..1MiB、address解決、memory read失敗の伝播とhexdump出力を確認。
search_bytes|M|公開patternから内部bytesへの変換、whole-byte ??、空/全wildcard拒否、重複位置、memory終端停止を確認。
set_function_prototype|E|address優先、C signature parse、ApplyFunctionSignatureCmdのfalse/例外でrollback、返却する実関数名を確認。
set_local_variable_type|E|型解決、高位symbol/parameterのDB commit、local/parameter fallback、見つからない変数のrollbackを確認。
set_global_data_type|D|型とclear_mode解決、DataUtilities.createData、失敗時rollback、lengthの転送を確認。
set_bytes|E|公開bytes_hexから内部bytesへの変換、1MiB制限、空の拒否、Memory.setBytesのtransactionを確認。
get_comments|P|5種類のCommentType公開API、未設定null、編集・削除とのround tripを確認。
search_symbols|P|部分一致とglob、大文字小文字を無視した検索、SymbolTypeによる絞込後のpaginationを確認。
create_label|P|空名拒否、USER_DEFINED source、make_primaryの挙動と既存label再利用を確認。
add_bookmark|E|address/category/typeの必須条件、BookmarkManager.setBookmark、transactionと返却値を確認。
list_bookmarks|M|address/type/categoryの組合せ、filter後のpagination、削除に使えるidの返却を確認。
delete_bookmark|E|id優先またはaddress+type+category、comment絞込、未一致の拒否、削除前snapshotを確認。
create_struct|D|F3修正済。size/明示offset/暗黙append、管理下datatype、途中失敗時の新規型・成長のrollbackを確認。
add_struct_members|D|F3修正済。既存型の一意解決、明示offsetのgrow、packed配置の固定、既存memberとrollbackを確認。
delete_data_type|D|category指定時の完全解決、曖昧名拒否、manager.removeの成否、削除前の型情報を確認。
remove_struct_members|D|members=[]のnoop、clear_allの明示、混在拒否、ordinal降順削除による対象ずれの防止を確認。
rename_data_type|D|category/一意な名前での解決、renameのtransaction、返却情報を確認。
create_enum|D|size=1/2/4/8、整数/数値文字列/コメント、bool拒否、Ghidraの値範囲・signednessとrollbackを確認。
set_enum_values|D|置換対象を先に全部削除してsignednessの順序依存を除去、remove未一致拒否、残存値との衝突rollbackを確認。
parse_c_declarations|D|1M文字上限、public CParserで型を実登録、構文エラー情報、途中作成のrollbackを確認。
get_project_sync_status|Y|domain_path明示/active選択、refresh、未保存編集のoverlay、取得失敗を成功としない処理を確認。
get_version_history|Y|versioned限定、降順、limitとtotal_versions、接続/履歴取得失敗を確認。
get_version_diff|Y|存在する2version、同版の空差分、range/details上限、timeout、read-only Programのconsumer解放を確認。
checkout_project_program|Y|exclusiveの設定既定値、checkout拒否、未保存編集、既checkout、reloadと事後確認のpartial successを確認。
add_project_program_to_version_control|Y|comment必須、既versionedのnoop、保存/close/add/reopen順、keep_checked_outの実効値を確認。
commit_project_program|Y|auto checkoutとclean noop時の取消、stale checkoutのabort/discard/keep、保存後再確認、commit済みのpartial successを確認。
pull_project_program|Y|未保存・保存済み編集のabort/discard、hijack解消、metadataだけ更新されたProgramのreopen、最新versionの事後確認を確認。
undo_checkout_project_program|Y|未checkoutのnoop、discard/keep、.keep名の特定、preserved Programへのreopen、事後確認を確認。
terminate_project_program_checkout|Y|実在checkout ID、現在使用中のcheckout拒否、複数cache間の所有者、排他区間と事後確認を確認。
delete_shared_project_file|Y|正規化pathのconfirm、複数cacheのload状態、checkout、expected version、非atomic削除の明示、削除後確認を確認。
get_xrefs|Q|to/from、両端の関数、operand index、cursorのquery/revision固定、途中変更検出を確認。
get_call_edges|Q|in/out、data参照除外、tail call/thunk、未解決call、EXTERNAL宛先、cursorを確認。
disassemble|Q|functionとrangeの排他、end/length、address space境界、非連続bodyとseek cursorを確認。既存命令を読むだけ。
get_data_type|Q|完全pathまたは一意名、struct/union/enum/typedef、include_members=false、revision metadataを確認。
apply_edits|A|7種類のedit、atomic/非atomic/dry_run、before/after取得失敗も含むrollback、revision・checkout、項目別statusを確認。
bsim_query|B|F1・F2修正済。program/functionsのselector制約、閾値、自己一致除外、関数別上限と全体上限、matched_ref/provenanceを確認。
batch_read|A|5子ツールの公開可否、全入力事前検証、1lock、revision変化時の全破棄、soft deadline、項目errorとfield projectionを確認。
read_result|R|text/JSONの引数排他、offsetと上限、エスケープ込みresponse予算、巨大itemを飛ばすoffsetとtext回収、期限切れを確認。
search_result|R|regex worker/timeout、scan上限、count_complete、zero-lengthと\\Kのcursor、reverse制約、context共有、response予算を確認。
'''

GROUP_TESTS = {
 'L': ['test_target_service.py', 'test_runtime_target_lifecycle.py', 'test_project_handle.py', 'test_runtime_import_lifecycle.py', 'test_runtime_registry_shared_sync_commands.py'],
 'P': ['test_program_tools.py', 'test_runtime_dirty_state.py', 'test_runtime_resource_safety.py'],
 'S': ['test_script_catalog.py', 'test_script_service.py', 'test_runtime_script_commands.py', 'test_runtime_script_threads.py'],
 'B': ['test_bsim_service.py', 'test_bsim_infra_helpers.py', 'test_bsim_headless_commands.py', 'test_runtime_bsim_commands.py', 'test_runtime_bsim_loading.py'],
 'F': ['test_function_lookup_precedence.py', 'test_runtime_readonly_commands.py', 'test_runtime_tool_revision.py'],
 'M': ['test_headless_command_helpers.py', 'test_runtime_readonly_commands.py', 'test_runtime_mutating_commands.py'],
 'E': ['test_mutating_command_units.py', 'test_runtime_mutating_commands.py', 'test_runtime_dirty_state.py'],
 'D': ['test_mutating_command_units.py', 'test_program_tools.py', 'test_runtime_datatype_edits.py', 'test_runtime_mutating_commands.py'],
 'Y': ['test_sync_service.py', 'test_runtime_sync_operations.py', 'test_runtime_registry_shared_sync_commands.py', 'test_project_handle.py'],
 'Q': ['test_query_pagination.py', 'test_runtime_tool_revision.py', 'test_runtime_readonly_commands.py'],
 'A': ['test_batch_read.py', 'test_runtime_batch_read.py', 'test_runtime_tool_revision.py', 'test_runtime_dirty_state.py'],
 'R': ['test_result_efficiency.py', 'test_presentation_context_compaction.py', 'test_wire_envelopes.py'],
}

def function_location(path, name):
    tree = ast.parse(path.read_text())
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == name:
            return node.lineno
    raise ValueError((path, name))

def link(path, label=None, line=None):
    path = Path(path)
    return f'[{label or path.name}]({path}' + (f':{line}' if line else '') + ')'

specs = get_all_tool_specs()
notes = {name: (group, note) for name, group, note in (line.split('|', 2) for line in NOTES.strip().splitlines())}
assert set(notes) == set(specs) | {'read_result', 'search_result'}
rows=[]
for name, (group,note) in notes.items():
    if name in COMMAND_TO_IMPL and name not in {'run_script','export_program'}:
        fn=COMMAND_TO_IMPL[name]; source=Path(inspect.getsourcefile(fn)); lineno=inspect.getsourcelines(fn)[1]
    else:
        module = {
         'L': 'infrastructure/ghidra_adapter/runtime/target_lifecycle.py',
         'Y': 'infrastructure/ghidra_adapter/runtime/sync_operations.py',
         'B': 'application/services/bsim_service.py',
         'S': 'application/services/script_service.py',
         'R': 'presentation/result_tools.py',
        }.get(group)
        if name == 'export_program':
            source=ROOT/'src/ghidra_headless/handlers/commands/program_tools.py'; method=name
        else:
            source=ROOT/'src/ghidra_mcp'/module
            method=specs[name].command_or_method if name in specs else name
        lineno=function_location(source,method)
    rows.append({'name':name,'group':group,'note':note,'source':str(source.relative_to(ROOT)),'line':lineno,'tests':GROUP_TESTS[group]})
(WORK/'review-ledger.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))

header='''# 公開80ツールの個別レビュー（2026-09-21）

対象は現在の作業ツリーのToolSpec 78件と、結果取得用のread_result / search_resultの2件。プロファイルで通常は非公開になる高度操作・BSim・共有同期・scriptsも含めた。内部専用のrename_function等はapply_editsの各操作として確認した。

各行は、公開引数と内部引数の対応、処理と出力、副作用・失敗時の状態、関連テストを個別に照合した記録。「確認済」はこの範囲で新たな不具合を特定しなかった意味であり、全環境・全入力の保証ではない。テスト群の成功件数を個別レビューの代わりにはしていない。

## 今回特定した問題

- **F1 / P2: BSimの関数別件数制限。** 自己一致除外用に1件多く検索した後、実際に自己一致を除外した場合だけ再制限していた。対象ProgramがDBに未登録の場合などにmatches_per_function=1でも2件返る。共通の_collect_matchesで常に上限を適用した。bsim_query / bsim_apply_matchesに影響。再現テストは修正前1 failed・8 passed。
- **F2 / P2: BSim significanceの誤った上限。** bsim_apply_matchesの公開入力だけ0〜1となっており、内部APIが受け付ける2.5等をMCP経由で使用できなかった。bsim_queryと共通の「有限・非負、上限なし」に統一。負数・非有限値を早期拒否する契約も揃えた。MCP call_tool境界で修正前4 failed・4 passed（内3件はqueryの境界検証位置の不一致で、サービス層では元から拒否）。
- **F3 / P2: 構造体offsetの暗黙変換。** create_struct / add_struct_membersが32.5を32、trueを1へ変換して異なる配置を確定していた。浮動小数・booleanを拒否し、従来の整数・整数文字列の扱いを保持。実Ghidraで修正前4 failed・2 passed。失敗前のmember追加もtransactionで戻ることを検証した。

## 個別確認

| # | ツール / 主な実装 | 個別確認内容 | 結論 | テスト参照 |
|---:|---|---|---|---|
'''
lines=[header]
for i,row in enumerate(rows,1):
    name=row['name']; status='修正済 F1/F2' if name in {'bsim_query','bsim_apply_matches'} else '修正済 F3' if name in {'create_struct','add_struct_members'} else '確認済'
    lines.append(f"| {i} | {link(ROOT/row['source'],name,row['line'])} | {row['note']} | {status} | {row['group']} |\n")
lines.append('\n## 関連テストの対応\n\n各行の記号は関連テスト群。1ファイルが複数ツールを呼ぶものもあり、記号ごとの成功件数をツール数として数えていない。\n\n')
for group,tests in GROUP_TESTS.items():
    lines.append(f"- **{group}**: "+', '.join(link(ROOT/'tests'/t) for t in tests)+'\n')
lines.append('''
公開境界はtest_mcp_boundary_contract.py、test_tool_specs.py、test_spec_handler_parameters.py、test_tool_contracts.py、test_wire_envelopes.pyでも横断確認。個別のサービス・handlerまで追跡し、public APIのみの要件と実行後の状態を確認した。

## 実行結果

実行完了後に記入。

## 仕様上の境界

- run_scriptのtimeoutはmonitorを確認する処理への協調キャンセル。任意スクリプトのOS/ネットワーク操作はProgram transactionではrollbackされない。Java/Jython/PyGhidraを実行する製品の既存仕様として確認した。
- batch_readの時間制限は各読み取りの間で確認するsoft deadline。全入力・全出力が同じrevisionであることを検査する。
- export_programのgzfは保存済みProgramを対象とする。最新編集を含める場合はsave_project_programが必要。
- 共有versionedファイルの削除はGhidra側にatomic compare-and-deleteがなく、既存の明示オプションとversion照合を保持。
- BSim update_target_signaturesは名前・metadataの更新。feature vectorの再生成はdelete後の再登録で行う。
- 今回の実機検証対象はmacOS arm64 / Ghidra 12.1.3 / Java 21。Windows、Linux、remote PostgreSQL/Elasticsearchの実機検証を今回実施したとは扱わない。
''')
(ROOT/'docs/release-tool-by-tool-review-20260921.ja.md').write_text(''.join(lines))
print(f'Wrote {len(rows)} individual reviews')
