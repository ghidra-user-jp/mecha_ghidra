from pathlib import Path
import difflib
import json
import platform
import subprocess
import sys
import xml.etree.ElementTree as ET
import zipfile
from importlib.metadata import version

ROOT = Path('/Users/samsepi0l/ghidra/mecha_ghidra')
WORK = Path(__file__).resolve().parent
REPORT = ROOT / 'docs/release-tool-by-tool-review-20260921.ja.md'


def dump(name, value):
    (WORK / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


def cases(path):
    return {(n.get('classname'), n.get('name')): n for n in ET.parse(path).findall('.//testcase')}


skipped = {key for key, node in cases(WORK / 'final.xml').items() if node.find('skipped') is not None}
latest = {}
native_runs = ['native', 'offsets-after', 'scripts-after', 'shared', 'bsim', 'resources-after', 'transport']
for run in native_runs:
    for key, node in cases(WORK / run / 'result.xml').items():
        passed = not any(node.find(tag) is not None for tag in ('failure', 'error', 'skipped'))
        latest[key] = (passed, run + '/result.xml')
missing = sorted(key for key in skipped if not latest.get(key, (False,))[0])
dump('native-coverage.json', {
    'normal_skipped': len(skipped),
    'covered': len(skipped) - len(missing),
    'missing': missing,
    'evidence': [{'test': key, 'source': latest[key][1]} for key in sorted(skipped) if key not in missing],
})
assert len(skipped) == 219 and not missing

ledger = json.loads((WORK / 'review-ledger.json').read_text())
exposed = json.loads((WORK / 'exposed-tools.json').read_text())
assert len(ledger) == len(exposed) == 80
assert {r['name'] for r in ledger} == set(exposed)
assert sum(line.startswith('| ') and line.split('|')[1].strip().isdigit() for line in REPORT.read_text().splitlines()) == 80

changed = []
diffs = []
with zipfile.ZipFile(WORK / 'before.zip') as before:
    paths = set(before.namelist())
    assert paths == {str(p.relative_to(ROOT)) for folder in ('src', 'tests') for p in (ROOT / folder).rglob('*.py')}
    for name in sorted(paths):
        previous = before.read(name)
        current = (ROOT / name).read_bytes()
        if previous != current:
            changed.append(name)
            diffs.extend(difflib.unified_diff(previous.decode().splitlines(True), current.decode().splitlines(True),
                                            fromfile='before/' + name, tofile='after/' + name))
assert len(changed) == 9
assert sum(p.startswith('src/') for p in changed) == 3
dump('changed-files.json', changed)
(WORK / 'implementation.patch').write_text(''.join(diffs))

checks = json.loads((WORK / 'quality-checks.json').read_text())
assert all(check['exit_code'] == 0 for check in checks)
dump('environment.json', {'platform': platform.platform(), 'machine': platform.machine(),
                          'python': sys.version, 'packages': {p: version(p) for p in ('mcp', 'pyghidra', 'pydantic', 'pytest')},
                          'ghidra': '12.1.3', 'java': 'Temurin 21',
                          'git_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
                          'working_tree_was_dirty': True})

files = [p for p in WORK.iterdir() if p.is_file() and p.suffix in ('.json', '.xml', '.log', '.py', '.patch')]
for run in native_runs + ['offsets-before']:
    for name in ('runtime.log', 'result.xml', 'invocation.json', 'setup-result.json', 'setup.log',
                 'shutdown.json', 'extra-calls.json', 'extra.log', 'create.log'):
        p = WORK / run / name
        if p.exists():
            files.append(p)

summary = '''公開80ツールの個別レビュー証跡 / 2026-09-21

通常テスト: final.xml 1627 passed / 219 skipped。
実機テスト: native-coverage.jsonで219件すべての成功をJUnitのテストIDで照合。
実機テストは複数実行の集合であり、各ファイルの件数を単純合算しない。
native/result.xmlの初回15失敗はテスト配線を修正しscripts-after/result.xmlで解消。
offsets-beforeの4失敗は製品修正後offsets-after/result.xmlで解消。
修正前BSim/MCP境界の失敗ログも保存。これらを最終結果と混同しない。
BSimの追加実測はbsim/extra-calls.json（全11 BSimツールを含む19呼び出し）。

変更: implementation.patchはこのレビューの開始時点との差分。
before/とafter/は今回変更した9ファイルのみ。Git HEADには元から未確定変更あり。
review-ledger.jsonに各80ツールの実装位置・確認内容・関連テストを記録。
report.mdに日本語のレビュー結果を収録。

補助スクリプトにはローカルGhidra/JDK/Jython extensionのパスが含まれる。
再実行する際は環境に合わせて変更する。テストのプロジェクト/DB/秘密鍵は収録しない。
共有テスト用サーバーの停止結果はshared/shutdown.json。
'''
archive = ROOT / 'docs/release-tool-by-tool-evidence-20260921.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as output:
    output.writestr('README.txt', summary)
    output.write(REPORT, 'report.md')
    for p in sorted(files):
        output.write(p, str(p.relative_to(WORK)))
    with zipfile.ZipFile(WORK / 'before.zip') as before:
        for name in changed:
            output.writestr('before/' + name, before.read(name))
            output.write(ROOT / name, 'after/' + name)
with zipfile.ZipFile(archive) as check:
    assert check.testzip() is None
print(json.dumps({'archive': str(archive), 'bytes': archive.stat().st_size,
                  'reviewed_tools': len(ledger), 'native_tests_passed': len(skipped),
                  'changed_python_files': len(changed)}, indent=2))
