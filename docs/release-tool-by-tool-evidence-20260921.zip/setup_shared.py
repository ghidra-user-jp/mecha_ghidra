import json
import sys
from pathlib import Path

from ghidra_headless.launcher import start_headless_jvm

start_headless_jvm()
from ghidra.framework.client import ClientUtil
from ghidra_headless.session import ProjectHandle
from cli_support import ToolHarness
cli = ToolHarness()

work = Path(sys.argv[1])
port = int(sys.argv[2])
server = ClientUtil.getRepositoryServer('127.0.0.1', port, True)
repository = server.createRepository('review')
repository.connect()
cache = work / 'cache'
url = f'ghidra://127.0.0.1:{port}/review'
created = ProjectHandle.create_repository_cache_project(str(cache), 'shared', repository_url=url)
assert created['created']
metadata = cache / 'shared.rep/project.prp'
original = metadata.read_bytes()
assert ProjectHandle.create_repository_cache_project(str(cache), 'shared', repository_url=url)['status'] == 'exists'
for wrong_url in (f'ghidra://other.invalid:{port}/review', f'ghidra://127.0.0.1:{port + 3}/review'):
    try:
        ProjectHandle.create_repository_cache_project(str(cache), 'shared', repository_url=wrong_url)
    except Exception as exc:
        assert 'PROJECT_ALREADY_EXISTS' in str(exc), exc
    else:
        raise AssertionError(f'Incorrectly reused cache for {wrong_url}')
assert metadata.read_bytes() == original
cli.register_target(target='seed', project_location=str(cache), project_name='shared')
binary = work / 'seed.bin'
binary.write_bytes(bytes.fromhex('b8 2a 00 00 00 c3'))
imported = cli.import_program(target='seed', binary_path=str(binary), import_mode='raw_binary', language_id='x86:LE:64:default', base_address='0x1000', entry_address='0x1000', analyze_imported=True)
added = cli.add_project_program_to_version_control(target='seed', domain_path=imported['program'], comment='disposable review seed', keep_checked_out=False)
assert added['is_versioned']
cli.registry.close_all()
(work/'setup-result.json').write_text(json.dumps({'created':created,'seed':imported,'versioned':added,'cache_identity_checks':3},indent=2))
