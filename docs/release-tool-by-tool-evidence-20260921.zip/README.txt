公開80ツールの個別レビュー証跡 / 2026-09-21

通常テスト: final.xml 1627 passed / 219 skipped。
実機テスト: native-coverage.jsonで219件すべての成功をJUnitのテストIDで照合。
実機テストは複数実行の集合であり、各ファイルの件数を単純合算しない。
native/result.xmlの初回15失敗はテスト配線を修正しscripts-after/result.xmlで解消。
offsets-beforeの4失敗は製品修正後offsets-after/result.xmlで解消。
修正前BSim/MCP境界の失敗ログも保存。これらを最終結果と混同しない。
BSimの追加実測はbsim/extra-calls.json（全11 BSimツールを含む19呼び出し）。

変更: implementation.patchはこのレビューの開始時点との差分。
before/とafter/は今回変更した9ファイルのみ。Git HEADには元から未確定変更あり。
review-ledger.jsonに各80ツールの実装位置・確認内容・関連テストを記録。
report.mdに日本語のレビュー結果を収録。

補助スクリプトにはローカルGhidra/JDK/Jython extensionのパスが含まれる。
再実行する際は環境に合わせて変更する。テストのプロジェクト/DB/秘密鍵は収録しない。
共有テスト用サーバーの停止結果はshared/shutdown.json。
