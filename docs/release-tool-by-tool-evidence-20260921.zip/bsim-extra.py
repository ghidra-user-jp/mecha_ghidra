import json
import os
from pathlib import Path

from ghidra_headless.launcher import start_headless_jvm
from ghidra_mcp.application.services.bsim_service import BsimConfig
from ghidra_mcp.contracts.tool_spec import get_all_tool_specs
from cli_support import ToolHarness

work=Path(__file__).resolve().parent/'bsim'
start_headless_jvm()
api=ToolHarness()
api.configure(selected_specs=get_all_tool_specs(),bsim_config=BsimConfig(bsim_url=os.environ['GHIDRA_BSIM_URL']))
events=[]
def call(name, **args):
    result=getattr(api,name)(**args)
    events.append({'tool':name,'arguments':args,'result':result})
    return result

try:
    setup=json.loads((work/'setup-result.json').read_text())
    call('open_program',target='query-review',project_location=str(work/'project'),project_name='corpus',domain_path='/query.bin')
    query={'target':'query-review','scope':'functions','function_names':[setup['query_function']],
           'similarity_threshold':0.7,'significance_threshold':2.5,'exclude_self':True,'max_results':10}
    two=call('bsim_query',**query,matches_per_function=2)
    one=call('bsim_query',**query,matches_per_function=1)
    assert two['count']==2 and one['count']==1, (two,one)
    assert one['excluded_self_matches']==0
    match=one['matches'][0]
    address=match['query_ref']['address']
    call('apply_edits',target='query-review',edits=[{'kind':'rename_function','address':address,'new_name':'review_query_name'}])
    apply={'target':'query-review','addresses':[address],'significance_threshold':2.5,'matches_per_function':1,
           'max_functions':1,'only_default_names':False}
    preview=call('bsim_apply_matches',**apply,dry_run=True)
    assert preview['applied_count']==1 and preview['dry_run']
    assert call('get_function',target='query-review',address=address)['name']=='review_query_name'
    applied=call('bsim_apply_matches',**apply)
    assert applied['applied_count']==1 and applied['failed_count']==0
    assert call('get_function',target='query-review',address=address)['name']==preview['applied'][0]['new_name']
    loaded=call('bsim_load_matched_executable',matched_ref=match['matched_ref'],target='reference-review')
    assert loaded['status']=='loaded'
    ref_md5=match['matched_ref']['executable_md5']
    category=call('bsim_add_executable_category',category='tool_review')
    assert category['status']=='created'
    update=call('bsim_update_executable_metadata',md5=ref_md5,categories={'tool_review':['checked']})
    assert update['updated_executables']==1
    signed=call('bsim_update_target_signatures',target='reference-review')
    assert signed['preserved_categories']['tool_review']==['checked']
    assert call('get_bsim_executable',md5=ref_md5)['categories']['tool_review']==['checked']
    registered=call('bsim_register_target',target='query-review',categories={'tool_review':'query'})
    assert registered['inserted_functions']>0
    query_md5=call('get_program_info',target='query-review')['executable_md5']
    assert call('list_bsim_executables',md5=query_md5)['count']==1
    deleted=call('bsim_delete_executable',md5=query_md5,confirm=query_md5)
    assert deleted['status']=='deleted' and deleted['deleted_functions']>0
    assert call('list_bsim_executables',md5=query_md5)['count']==0
    assert call('get_bsim_database_status')['executable_count']==2
finally:
    api.registry.close_all()
    (work/'extra-calls.json').write_text(json.dumps(events,indent=2,ensure_ascii=False))
print(json.dumps({'status':'passed','calls':len(events),'bsim_tools':sorted({e['tool'] for e in events if 'bsim' in e['tool']})}))
