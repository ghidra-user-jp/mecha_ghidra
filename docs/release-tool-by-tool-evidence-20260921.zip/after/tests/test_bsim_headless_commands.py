from __future__ import annotations

import pytest

from ghidra_headless.handlers.commands.read_only_bsim import (
    _format_address,
    _iter_items,
    _matched_domain_path,
    _rows_to_result,
)


class FakeDomainFile:
    def getPathname(self):
        return "/query_sample"


class FakeProgram:
    def getDomainFile(self):
        return FakeDomainFile()


class FakeContext:
    program = FakeProgram()


class FakeExecutableRecord:
    def __init__(self, *, md5: str, name: str) -> None:
        self._md5 = md5
        self._name = name

    def getMd5(self):
        return self._md5

    def getNameExec(self):
        return self._name

    def getRepository(self):
        return "ghidra:/tmp/bsim_project"

    def getURLString(self):
        return "ghidra:/tmp/bsim_project"

    def getPath(self):
        return "/matches"

    def isLibrary(self):
        return False

    def getAllCategories(self):
        return None


class FakeFunctionDescription:
    def __init__(self, *, address: int, name: str, record: FakeExecutableRecord | None = None) -> None:
        self._address = address
        self._name = name
        self._record = record

    def getAddress(self):
        return self._address

    def getFunctionName(self):
        return self._name

    def getExecutableRecord(self):
        return self._record


class FakeMatchRow:
    def __init__(self, *, md5: str, similarity: float, significance: float, address: int) -> None:
        self._matched = FakeFunctionDescription(
            address=address,
            name=f"match_{md5[:4]}",
            record=FakeExecutableRecord(md5=md5, name=f"{md5[:4]}.bin"),
        )
        self._similarity = similarity
        self._significance = significance

    def getOriginalFunctionDescription(self):
        return FakeFunctionDescription(address=0x401000, name="query_func")

    def getMatchFunctionDescription(self):
        return self._matched

    def getSimilarity(self):
        return self._similarity

    def getSignificance(self):
        return self._significance


def test_bsim_rows_are_versioned_and_stably_sorted_before_limit():
    rows = [
        FakeMatchRow(md5="bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb", similarity=0.8, significance=9.0, address=0x30),
        FakeMatchRow(md5="cccccccccccccccccccccccccccccccc", similarity=0.9, significance=1.0, address=0x20),
        FakeMatchRow(md5="aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", similarity=0.9, significance=5.0, address=0x10),
    ]

    result = _rows_to_result(FakeContext(), {"query_target": "query", "max_results": 2}, rows)

    assert result["count"] == 2
    assert result["truncated"] is True
    assert [item["matched_ref"]["executable_md5"] for item in result["matches"]] == [
        "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
        "cccccccccccccccccccccccccccccccc",
    ]
    assert result["matches"][0]["matched_ref"]["matched_ref_version"] == 1


@pytest.mark.parametrize("include_self", [False, True])
def test_bsim_per_function_limit_applies_even_without_a_self_match(include_self):
    own_md5 = "dddddddddddddddddddddddddddddddd"
    rows = [
        FakeMatchRow(md5="bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb", similarity=0.8, significance=9.0, address=0x30),
        FakeMatchRow(md5="aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", similarity=0.9, significance=5.0, address=0x10),
    ]
    if include_self:
        rows.append(FakeMatchRow(md5=own_md5, similarity=1.0, significance=10.0, address=0x401000))
    # Another query function must retain its own result; the limit is not global.
    other = FakeMatchRow(md5="cccccccccccccccccccccccccccccccc", similarity=0.7, significance=1.0, address=0x20)
    other.getOriginalFunctionDescription = lambda: FakeFunctionDescription(address=0x402000, name="other_func")
    rows.append(other)

    result = _rows_to_result(FakeContext(), {"matches_per_function": 1, "max_results": 10}, rows, exclude_md5=own_md5)

    assert result["count"] == 2
    assert result["excluded_self_matches"] == int(include_self)
    assert [item["matched_ref"]["executable_md5"] for item in result["matches"]] == ["a" * 32, "c" * 32]
    assert [item["query_ref"]["address"] for item in result["matches"]] == ["0x401000", "0x402000"]


class _PathRecord:
    def __init__(self, *, path, name):
        self._path = path
        self._name = name

    def getPath(self):
        return self._path

    def getNameExec(self):
        return self._name


def test_matched_domain_path_always_appends_program_name():
    # Folder basename equals the program name (one-folder-per-sample layout); the path
    # must not collapse to the folder.
    record = _PathRecord(path="/emotet", name="emotet")
    assert _matched_domain_path(record) == "/emotet/emotet"


def test_matched_domain_path_joins_folder_and_name():
    record = _PathRecord(path="/samples", name="old.exe")
    assert _matched_domain_path(record) == "/samples/old.exe"


def test_matched_domain_path_handles_missing_folder():
    record = _PathRecord(path=None, name="x")
    assert _matched_domain_path(record) == "/x"


def test_format_address_masks_signed_long():
    # Ghidra returns getAddress() as a signed Java long; the high-bit case must not
    # render as a negative "0x-..." string.
    assert _format_address(0x401000) == "0x401000"
    assert _format_address(-2) == "0xfffffffffffffffe"


def test_iter_items_propagates_mid_iteration_errors():
    def _exploding():
        yield 1
        yield 2
        raise RuntimeError("boom")

    collected = []
    with pytest.raises(RuntimeError, match="boom"):
        for item in _iter_items(_exploding()):
            collected.append(item)

    assert collected == [1, 2]


def test_iter_items_supports_bare_next_iterator():
    class _BareNext:
        def __init__(self):
            self._values = iter([10, 20])

        def next(self):
            return next(self._values)

    assert list(_iter_items(_BareNext())) == [10, 20]
