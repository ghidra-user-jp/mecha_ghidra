import json
import uuid
from pathlib import Path

import jpype
import pytest

from ghidra_mcp import cli
from test_runtime_script_commands import _nested_script_project, _run, _domain_error

WORK = Path(__file__).parent


def save(name, value):
    (WORK / (name + '.json')).write_text(json.dumps(value, indent=2) + '\n')


BACKGROUND = '''import ghidra.app.script.GhidraScript;
import ghidra.program.model.listing.Program;
import java.util.concurrent.CountDownLatch;
public class ReviewBackground extends GhidraScript {
    public void run() {
        String key = getScriptArgs()[0];
        Program program = currentProgram;
        CountDownLatch go = (CountDownLatch) System.getProperties().get(key + ".go");
        CountDownLatch edited = (CountDownLatch) System.getProperties().get(key + ".edited");
        CountDownLatch stop = (CountDownLatch) System.getProperties().get(key + ".stop");
        Thread worker = new Thread(() -> {
            try {
                go.await();
                int tx = program.startTransaction("Background transaction after quarantine");
                program.endTransaction(tx, true);
                edited.countDown();
                stop.await();
            } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        }, "review-background-worker");
        worker.setDaemon(true);
        System.getProperties().put(key + ".thread", worker);
        worker.start();
    }
}
'''


def test_quarantine_must_retain_live_thread_evidence_after_later_transaction(tmp_path):
    with _nested_script_project(tmp_path, {'ReviewBackground.java': BACKGROUND}) as (target, _):
        from ghidra_headless.handlers.core_runtime import _CONTEXTS
        system = jpype.JClass('java.lang.System')
        latch_cls = jpype.JClass('java.util.concurrent.CountDownLatch')
        seconds = jpype.JClass('java.util.concurrent.TimeUnit').SECONDS
        props = system.getProperties()
        key = 'mecha-review-' + uuid.uuid4().hex
        go, edited, stop = latch_cls(1), latch_cls(1), latch_cls(1)
        for suffix, value in [('go', go), ('edited', edited), ('stop', stop)]:
            props.put(key + '.' + suffix, value)
        worker = None
        try:
            with pytest.raises(Exception, match='SCRIPT_FAILED') as exc_info:
                _run(target, script_id='t:ReviewBackground.java', args=[key])
            first = _domain_error(exc_info.value)
            ctx = _CONTEXTS[target]
            program = ctx.program
            before = dict(ctx.execution_invalid)
            assert before['stray_threads'], before
            worker = props.get(key + '.thread')
            assert worker.isAlive()
            # Recovery correctly refuses to release a live worker's program initially.
            with pytest.raises(Exception, match='RUNTIME_DEGRADED'):
                cli.close_session(target=target, discard_changes=True)
            go.countDown()
            assert edited.await_(10, seconds)
            after = dict(ctx.execution_invalid)
            assert worker.isAlive()
            close_result = None
            close_error = None
            try:
                close_result = cli.close_session(target=target, discard_changes=True)
            except Exception as exc:
                close_error = _domain_error(exc)
            observation = {'initial_error': first, 'before': before, 'after': after,
                           'worker_alive': bool(worker.isAlive()), 'program_closed': bool(program.isClosed()),
                           'close_result': close_result, 'close_error': close_error}
            save('quarantine-thread-evidence', observation)
            assert close_error is not None and close_error['code'] == 'RUNTIME_DEGRADED', observation
        finally:
            go.countDown()
            stop.countDown()
            if worker is not None:
                worker.join(10000)
            if target in _CONTEXTS:
                cli.close_session(target=target, discard_changes=True)
            for suffix in ('go', 'edited', 'stop', 'thread'):
                props.remove(key + '.' + suffix)


def test_java_constructor_worker_must_not_escape_thread_observation(tmp_path):
    key = 'mecha-constructor-review-' + uuid.uuid4().hex
    source = '''import ghidra.app.script.GhidraScript;
import java.util.concurrent.CountDownLatch;
public class ReviewConstructor extends GhidraScript {
    public ReviewConstructor() {
        CountDownLatch stop = (CountDownLatch) System.getProperties().get("KEY.stop");
        Thread worker = new Thread(() -> {
            try { stop.await(); }
            catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        }, "review-constructor-worker");
        worker.setDaemon(true);
        System.getProperties().put("KEY.thread", worker);
        worker.start();
    }
    public void run() { println("RUN_COMPLETED"); }
}
'''.replace('KEY', key)
    with _nested_script_project(tmp_path, {'ReviewConstructor.java': source}) as (target, _):
        from ghidra_headless.handlers.core_runtime import _CONTEXTS
        props = jpype.JClass('java.lang.System').getProperties()
        stop = jpype.JClass('java.util.concurrent.CountDownLatch')(1)
        props.put(key + '.stop', stop)
        worker = None
        try:
            result, error = None, None
            try:
                result = _run(target, script_id='t:ReviewConstructor.java')
            except Exception as exc:
                error = _domain_error(exc)
            worker = props.get(key + '.thread')
            assert worker is not None and worker.isAlive()
            observation = {'result': result, 'error': error, 'quarantine': _CONTEXTS[target].execution_invalid,
                           'worker_alive': bool(worker.isAlive()), 'worker_id': int(worker.threadId())}
            save('constructor-thread-observation', observation)
            assert error is not None and error['details']['stray_threads'], observation
        finally:
            stop.countDown()
            if worker is not None:
                worker.join(10000)
            cli.close_session(target=target, discard_changes=True)
            props.remove(key + '.stop')
            props.remove(key + '.thread')
