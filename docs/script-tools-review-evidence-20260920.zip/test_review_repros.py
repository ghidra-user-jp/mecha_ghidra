"""Review repros: expect the promised snapshot integrity boundary to hold."""
import contextlib
import hashlib
import uuid

import pytest

from ghidra_mcp import cli
from ghidra_mcp.application.services.script_service import ScriptConfig
from ghidra_mcp.contracts.tool_spec import ToolProfile, filter_tool_specs
from test_runtime_script_commands import (
    _start_pyghidra_if_needed, _ensure_project_created, _load_sample,
    _release_script_runtime, _run, _plate,
)


@contextlib.contextmanager
def project(tmp_path):
    install_dir = _start_pyghidra_if_needed()
    parents = tmp_path / "parents"
    helpers = tmp_path / "helpers"
    parents.mkdir()
    helpers.mkdir()
    (parents / "Parent.py").write_text('# @runtime PyGhidra\nrunScript("ReviewChild.py")\n')
    (helpers / "ReviewChild.py").write_text('# @runtime PyGhidra\nprintln("ORIGINAL_CHILD")\n')
    from pathlib import Path
    config = ScriptConfig(roots=(("parents", parents), ("helpers", helpers)),
                          snapshot_base=tmp_path / "snap", ghidra_install_dir=Path(install_dir))
    registry = cli._get_registry(filter_tool_specs(profile=ToolProfile.FULL), script_config=config)
    cli._script_service.initialize()
    cli._prepare_script_runtime(cli._script_service)
    project_dir = tmp_path / "proj"
    _ensure_project_created(project_dir, "review")
    target = "review_" + uuid.uuid4().hex[:6]
    try:
        _load_sample(target, project_dir, "review")
        yield target, cli.get_program_info(target=target)["min_address"]
    finally:
        registry.close_all()
        cli._script_service.shutdown()
        _release_script_runtime()


@pytest.mark.parametrize("inline", [False, True])
def test_reject_changed_child_in_another_root(tmp_path, inline):
    with project(tmp_path) as (target, address):
        service = cli._script_service
        child = service.snapshot_base / "helpers" / "ReviewChild.py"
        child.write_text('# @runtime PyGhidra\nprintln("CHANGED_CHILD_EXECUTED")\n'
                         'setPlateComment(currentProgram.getMinAddress(), "CHANGED_CHILD_EDIT")\n')
        with pytest.raises(Exception, match="SCRIPT_SNAPSHOT_CORRUPT"):
            _run(target, script_id="helpers:ReviewChild.py")
        if inline:
            args = {"source": '# @runtime PyGhidra\nrunScript("ReviewChild.py")\n'}
        else:
            args = {"script_id": "parents:Parent.py",
                    "expected_sha256": service.get_script_info("parents:Parent.py")["sha256"]}
        result = _run(target, **args)
        actual = _plate(target, address)
        print("review evidence:", inline, result["stdout"], result["transaction_outcome"], actual)
        assert "CHANGED_CHILD_EXECUTED" not in result["stdout"]["text"], result
        assert actual != "CHANGED_CHILD_EDIT"


def test_verified_parent_cannot_change_while_waiting_for_its_lock(tmp_path):
    with project(tmp_path) as (target, address):
        service = cli._script_service
        source = service.snapshot_base / "parents" / "Parent.py"
        info = service.get_script_info("parents:Parent.py")
        original_acquire = service._lock_manager.acquire
        @contextlib.contextmanager
        def change_on_lock_entry(*args, **kwargs):
            # Deterministically model an earlier script changing this file while
            # this request waits between validation and actual lock ownership.
            source.write_text('# @runtime PyGhidra\nprintln("CHANGED_PARENT_EXECUTED")\n')
            with original_acquire(*args, **kwargs):
                yield
        service._lock_manager.acquire = change_on_lock_entry
        result = _run(target, script_id="parents:Parent.py", expected_sha256=info["sha256"])
        actual_sha = hashlib.sha256(source.read_bytes()).hexdigest()
        print("review evidence:", result["stdout"], result["sha256"], actual_sha)
        assert result["sha256"] == actual_sha


def test_script_queue_obeys_configured_lock_timeout(tmp_path):
    import threading
    import time
    from ghidra_mcp.application.locks import SCRIPT_BARRIER
    from ghidra_mcp.domain import configure_lock_timeout_seconds, get_lock_timeout_seconds
    with project(tmp_path) as (target, address):
        cli._script_service.list_scripts()
        original_timeout = get_lock_timeout_seconds()
        done = threading.Event()
        results = []
        errors = []
        def run():
            try:
                results.append(_run(target, source='# @runtime PyGhidra\nprintln("QUEUED_SCRIPT_EXECUTED")\n'))
            except Exception as exc:
                errors.append(exc)
            finally:
                done.set()
        thread = threading.Thread(target=run, name="ReviewRequestWorker", daemon=True)
        configure_lock_timeout_seconds(0.05)
        try:
            # Model the process barrier owned by a script on a different project;
            # the new request can acquire its own application target/project locks.
            with SCRIPT_BARRIER.write_lock():
                thread.start()
                start = time.monotonic()
                finished_while_blocked = done.wait(0.5)
                elapsed = time.monotonic() - start
            thread.join(10)
            assert not thread.is_alive()
            print("review queue evidence:", finished_while_blocked, elapsed,
                  [str(e) for e in errors], [r["stdout"] for r in results])
            assert finished_while_blocked, "script request exceeded the configured lock wait by at least 10x"
            assert len(errors) == 1 and "LOCK_TIMEOUT" in str(errors[0])
        finally:
            configure_lock_timeout_seconds(original_timeout)
            thread.join(10)
