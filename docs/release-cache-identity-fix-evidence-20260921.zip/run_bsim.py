import json
import os
from pathlib import Path
import subprocess

root=Path('/Users/samsepi0l/ghidra/mecha_ghidra')
work=Path(__file__).resolve().parent/'bsim'
work.mkdir(exist_ok=True)
for name in ('home','settings','tmp','cache'):
    (work/name).mkdir(exist_ok=True)
env=dict(os.environ)
for key in list(env):
    if key.startswith(('GHIDRA_BSIM','GHIDRA_SERVER')):
        env.pop(key)
env.update({'JAVA_HOME':'/Library/Java/JavaVirtualMachines/temurin-21.jdk/Contents/Home','GHIDRA_INSTALL_DIR':'/Users/samsepi0l/ghidra/ghidra_12.1.3_PUBLIC','PYTHONPATH':str(root/'src')+':'+str(root/'tests'),'GHIDRA_BSIM_RUNTIME_VALIDATION':'1','GHIDRA_BSIM_MUTATION_VALIDATION':'1','PYTHONDONTWRITEBYTECODE':'1','XDG_CACHE_HOME':str(work/'cache')})
env['JAVA_TOOL_OPTIONS']=f'-Xmx2g -Duser.home={work/"home"} -Dapplication.settingsdir={work/"settings"} -Djava.io.tmpdir={work/"tmp"} -Djava.awt.headless=true'
url='file:'+str(work/'review')
env['GHIDRA_BSIM_URL']=url
cmd=[env['GHIDRA_INSTALL_DIR']+'/support/bsim','createdatabase',url,'medium_nosize']
print('Creating disposable H2 BSim database',flush=True)
with (work/'create.log').open('w') as log:
    subprocess.run(cmd,cwd=work,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)
with (work/'setup.log').open('w') as log:
    subprocess.run([str(root/'.venv/bin/python'),str(work.parent/'setup_bsim.py'),str(work),url],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=240)
setup=json.loads((work/'setup-result.json').read_text())
env.update({'GHIDRA_BSIM_PROJECT_LOCATION':str(work/'project'),'GHIDRA_BSIM_PROJECT_NAME':'corpus','GHIDRA_BSIM_QUERY_DOMAIN_PATH':'/query.bin','GHIDRA_BSIM_QUERY_FUNCTION':setup['query_function']})
cmd=[str(root/'.venv/bin/python'),'-m','pytest','-q','-W','error::mcp.MCPDeprecationWarning','--tb=short','--junitxml='+str(work/'result.xml'),'tests/test_runtime_bsim_commands.py']
(work/'invocation.json').write_text(json.dumps({'cmd':cmd,'env':{k:v for k,v in env.items() if k.startswith(('GHIDRA_BSIM','JAVA_TOOL_OPTIONS'))}},indent=2))
print('Running BSim regression',flush=True)
with (work/'runtime.log').open('w') as log:
    result=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=300)
print((work/'runtime.log').read_text()[-18000:])
raise SystemExit(result.returncode)
