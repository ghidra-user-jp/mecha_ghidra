import json
from pathlib import Path
import sys

from ghidra_headless.launcher import start_headless_jvm
start_headless_jvm()
from ghidra_mcp import cli
from ghidra_mcp.application.services.bsim_service import BsimConfig
from ghidra_mcp.contracts.tool_spec import get_all_tool_specs

work=Path(sys.argv[1])
url=sys.argv[2]
cli._get_registry(selected_specs=get_all_tool_specs(),bsim_config=BsimConfig(bsim_url=url))
project=work/'project'
cli.create_project(project_location=str(project),project_name='corpus')
cli.register_target(target='setup',project_location=str(project),project_name='corpus')
reference=work/'reference.bin'
reference.write_bytes(Path('/bin/ls').read_bytes())
query=work/'query.bin'
query.write_bytes(reference.read_bytes()+b'\x00review-query')
for binary in (reference,query):
    result=cli.import_program(target='setup',binary_path=str(binary),analyze_imported=True)
    if binary==reference:
        cli.load_project_program(target='setup',domain_path=result['program'])
        functions=cli.list_functions(target='setup',limit=1000)
        selected=max(functions,key=lambda item:int(item.get('size',0)))['name']
        registration=cli.bsim_register_target(target='setup')
        assert registration['inserted_functions']>0,registration
        cli.close_session(target='setup')
cli._get_registry().close_all()
(work/'setup-result.json').write_text(json.dumps({'query_function':selected,'registration':registration},indent=2))
