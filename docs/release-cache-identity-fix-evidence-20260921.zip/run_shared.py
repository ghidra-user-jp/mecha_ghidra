import json
import os
from pathlib import Path
import random
import socket
import subprocess
import sys
import time

root = Path('/Users/samsepi0l/ghidra/mecha_ghidra')
install = Path('/Users/samsepi0l/ghidra/ghidra_12.1.3_PUBLIC')
work = Path(__file__).resolve().parent / (sys.argv[1] if len(sys.argv) > 1 else 'shared')
work.mkdir(exist_ok=True)
for name in ('server-data','home','settings','tmp','cache-home'):
    (work/name).mkdir(exist_ok=True)
env = dict(os.environ)
for key in list(env):
    if key.startswith(('GHIDRA_SERVER','GHIDRA_RUNTIME_SHARED')):
        env.pop(key)
env.update({'JAVA_HOME':'/Library/Java/JavaVirtualMachines/temurin-21.jdk/Contents/Home','GHIDRA_INSTALL_DIR':str(install),'GHIDRA_RUNTIME_VALIDATION':'1','GHIDRA_RUNTIME_BINARY_PATH':'/bin/ls','PYTHONPATH':str(root/'src')+':'+str(root/'tests'),'XDG_CACHE_HOME':str(work/'cache-home'),'PYTHONDONTWRITEBYTECODE':'1'})
vmargs = f'-Duser.home={work / "home"} -Dapplication.settingsdir={work / "settings"} -Djava.io.tmpdir={work / "tmp"} -Djava.awt.headless=true'
env['JAVA_TOOL_OPTIONS'] = '-Xmx2g ' + vmargs
classpath = ':'.join(line.split('=',1)[1].replace('${ghidra_home}',str(install)) for line in (install/'Ghidra/Features/GhidraServer/data/classpath.frag').read_text().splitlines())
for attempt in range(100):
    port = random.randrange(40000,55000)
    sockets = []
    try:
        for current in range(port,port+3):
            sock = socket.socket()
            sockets.append(sock)
            sock.bind(('127.0.0.1',current))
    except OSError:
        continue
    finally:
        for sock in sockets:
            sock.close()
    break
else:
    raise RuntimeError('No free local port range')
java = str(Path(env['JAVA_HOME'])/'bin/java')
keystore = work / 'localhost.p12'
with (work/'keytool.log').open('w') as output:
    subprocess.run([str(Path(env['JAVA_HOME'])/'bin/keytool'),'-genkeypair','-alias','review','-keyalg','RSA','-keysize','2048','-validity','1','-dname','CN=localhost','-ext','SAN=ip:127.0.0.1','-ext','KU=digitalSignature,keyEncipherment','-ext','EKU=serverAuth','-storetype','PKCS12','-keystore',str(keystore),'-storepass','disposable-review','-keypass','disposable-review','-noprompt'],env=env,cwd=work,stdout=output,stderr=subprocess.STDOUT,check=True,timeout=30)
cmd = [java,'-Xmx512m',*vmargs.split(),f'-Dghidra.keystore={keystore}','-Dghidra.password=disposable-review','-cp',classpath,'ghidra.server.remote.GhidraServer','-i','127.0.0.1','-ip','127.0.0.1',f'-p{port}',str(work/'server-data')]
(work/'invocation.json').write_text(json.dumps({'server_cmd':cmd,'port':port},indent=2))
print('Starting disposable localhost server',port,flush=True)
with (work/'server.log').open('w') as log:
    process = subprocess.Popen(cmd,cwd=work,env=env,stdout=log,stderr=subprocess.STDOUT)
    try:
        deadline=time.monotonic()+60
        while time.monotonic()<deadline:
            if process.poll() is not None:
                raise RuntimeError((work/'server.log').read_text())
            if 'Registered Ghidra Server' in (work/'server.log').read_text():
                break
            time.sleep(0.25)
        else:
            raise RuntimeError('Server startup timeout: '+(work/'server.log').read_text())
        config=work/'server.conf'
        config.write_text(f'ghidra.repositories.dir={work / "server-data"}\n')
        admin=[str(install/'support/launch.sh'),'fg','jre','review-admin','128M',vmargs,'ghidra.server.ServerAdmin',str(config),'-add','samsepi0l']
        with (work/'admin.log').open('w') as output:
            subprocess.run(admin,env=env,cwd=work,stdout=output,stderr=subprocess.STDOUT,check=True,timeout=45)
        deadline=time.monotonic()+20
        while time.monotonic()<deadline:
            users=work/'server-data/users'
            if users.exists() and 'samsepi0l:' in users.read_text():
                break
            time.sleep(0.2)
        else:
            raise RuntimeError('Test user was not provisioned')
        with (work/'setup.log').open('w') as output:
            subprocess.run([str(root/'.venv/bin/python'),str(work.parent/'setup_shared.py'),str(work),str(port)],cwd=root,env=env,stdout=output,stderr=subprocess.STDOUT,check=True,timeout=180)
        env.update({'GHIDRA_RUNTIME_SHARED_PROJECT_LOCATION':str(work/'cache'),'GHIDRA_RUNTIME_SHARED_PROJECT_NAME':'shared','GHIDRA_RUNTIME_SHARED_DOMAIN_PATH':'/seed.bin'})
        cmd=[str(root/'.venv/bin/python'),'-m','pytest','-q','-W','error::mcp.MCPDeprecationWarning','--tb=short','--junitxml='+str(work/'result.xml'),'tests/test_runtime_registry_shared_sync_commands.py']
        print('Running real shared-repository regression',flush=True)
        with (work/'runtime.log').open('w') as output:
            result=subprocess.run(cmd,cwd=root,env=env,stdout=output,stderr=subprocess.STDOUT,timeout=900)
        print((work/'runtime.log').read_text()[-18000:],flush=True)
        if result.returncode:
            raise SystemExit(result.returncode)
    finally:
        process.terminate()
        try:
            code=process.wait(timeout=20)
        except subprocess.TimeoutExpired:
            process.kill()
            code=process.wait(timeout=10)
        (work/'shutdown.json').write_text(json.dumps({'server_pid':process.pid,'returncode':code,'stopped':process.poll() is not None}))
