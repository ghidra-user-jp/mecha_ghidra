import json
from pathlib import Path
import pytest
from test_runtime_resource_safety import runtime as _runtime

runtime = _runtime
TARGET = 'resource_safety'
OUT = Path(__file__).parent

@pytest.mark.parametrize('offset', [None, 0])
def test_create_struct_does_not_modify_existing_definition(runtime, offset):
    api = runtime
    original = api['create_struct'](target=TARGET, name='Header', category='/review', members=[{'name':'magic','type':'int'}])
    before = api['get_data_type'](target=TARGET,path='/review/Header')
    member = {'name':'length','type':'short'}
    if offset is not None:
        member['offset'] = offset
    error = None
    created = None
    try:
        created = api['create_struct'](target=TARGET, name='Header', category='/review', members=[member])
    except Exception as exc:
        error = str(exc)
    after = api['get_data_type'](target=TARGET,path='/review/Header')
    (OUT/f'struct-duplicate-{offset}.json').write_text(json.dumps({'original':original,'before':before,'returned':created,'error':error,'after':after},indent=2))
    assert after['members'] == before['members']

@pytest.mark.parametrize('value', [0x7fffffffffffffff, 0x8000000000000000, 0xffffffffffffffff])
def test_enum_64_hex_value(runtime, value):
    result = runtime['create_enum'](target=TARGET, name='Flags', size=8, values={'VALUE':hex(value)})
    (OUT/f'enum-{value:x}.json').write_text(json.dumps(result,indent=2))
    assert (int(result['values'][0]['value']) & ((1<<64)-1)) == value
