import json
from pathlib import Path

import jpype
import pyghidra

from test_runtime_readonly_commands import _start_pyghidra_if_needed

ROOT = Path("/Users/samsepi0l/ghidra/mecha_ghidra")
WORK = Path(__file__).parent
SAMPLE = ROOT / "samples/hello.bin"


def test_default_auto_import_avoids_deprecated_api(tmp_path):
    _start_pyghidra_if_needed()
    from ghidra_headless.session import ProjectHandle

    ProjectHandle.create_project(str(tmp_path), "auto")
    handle = ProjectHandle(str(tmp_path), "auto")
    actual = handle.project
    calls = []

    class ObservedProject:
        def __getattr__(self, name):
            return getattr(actual, name)

        def importProgram(self, source):
            methods = [m for m in actual.getClass().getMethods()
                       if str(m.getName()) == "importProgram"
                       and [str(p.getName()) for p in m.getParameterTypes()] == ["java.io.File"]]
            assert len(methods) == 1
            annotation = methods[0].getAnnotation(jpype.JClass("java.lang.Deprecated").class_)
            calls.append({"method": str(methods[0]), "deprecated": annotation is not None,
                          "since": None if annotation is None else str(annotation.since()),
                          "for_removal": False if annotation is None else bool(annotation.forRemoval())})
            return actual.importProgram(source)

    handle.project = ObservedProject()
    try:
        imported = handle.import_program(str(SAMPLE))
        observation = {"domain_path": str(imported.getPathname()), "calls": calls}
        (WORK / "observed-import.json").write_text(json.dumps(observation, indent=2))
        assert observation["domain_path"] == "/hello.bin"
        assert not any(call["deprecated"] for call in calls), observation
    finally:
        handle.project = actual
        handle.close(force=True)


def test_program_loader_auto_import_public_replacement(tmp_path):
    _start_pyghidra_if_needed()
    from ghidra_headless.session import ProjectHandle

    ProjectHandle.create_project(str(tmp_path), "builder")
    handle = ProjectHandle(str(tmp_path), "builder")
    try:
        builder = (pyghidra.program_loader().project(handle.project.getProject())
                   .projectFolderPath("/").source(str(SAMPLE)).name("hello.bin"))
        results = builder.load()
        try:
            primary = results.getPrimary()
            assert primary is not None
            saved = primary.save(jpype.JClass("ghidra.util.task.TaskMonitor").DUMMY)
            observation = {"domain_path": str(saved.getPathname()), "content_type": str(saved.getContentType())}
            (WORK / "replacement-import.json").write_text(json.dumps(observation, indent=2))
            assert observation["domain_path"] == "/hello.bin"
        finally:
            results.close()
        reopened = handle.open_program("/hello.bin")
        try:
            assert int(reopened.get_program().getMemory().getSize()) > 0
        finally:
            reopened.close(save=False)
    finally:
        handle.close(force=True)
