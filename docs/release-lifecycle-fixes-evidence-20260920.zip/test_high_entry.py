import json
from pathlib import Path

import pytest

from ghidra_mcp.contracts.tool_spec import get_all_tool_specs, get_checkout_required_tool_names
from ghidra_mcp.presentation.cli_runtime import create_cli_runtime
from test_runtime_readonly_commands import _start_pyghidra_if_needed

WORK = Path(__file__).parent


@pytest.mark.parametrize("selector", ["entry_offset", "entry_address"])
def test_raw_import_accepts_upper_half_64_bit_entry(tmp_path, selector):
    _start_pyghidra_if_needed()
    from ghidra_headless.handlers import core, core_runtime

    specs = get_all_tool_specs()
    bundle = create_cli_runtime(registered_specs=specs, core_accessor=lambda: core,
                                checkout_required_commands=get_checkout_required_tool_names(specs))
    api = bundle.runtime.tools
    high = "0xffff800000001000"
    observation = {"selector": selector, "base_address": high}
    try:
        api["create_project"](project_location=str(tmp_path), project_name="high")
        api["register_target"](target="high", project_location=str(tmp_path), project_name="high")
        binary = tmp_path / "kernel.bin"
        binary.write_bytes(bytes.fromhex("b8 2a 00 00 00 c3"))
        try:
            result = api["import_program"](target="high", binary_path=str(binary), import_mode="raw_binary",
                language_id="x86:LE:64:default", base_address=high, analyze_imported=False,
                **{selector: 0 if selector == "entry_offset" else high})
        except Exception as exc:
            observation["error"] = getattr(exc, "domain_error", {"message": str(exc)})
            observation["remaining_programs"] = str(api["list_project_programs"](target="high"))
            raise
        observation["import_result"] = result
        api["load_project_program"](target="high", domain_path=result["program"])
        program = core_runtime._CONTEXTS["high"].program
        address = program.getMinAddress()
        observation["min_address"] = str(address)
        observation["function_count"] = int(program.getFunctionManager().getFunctionCount())
        assert str(address) == high[2:]
        assert program.getFunctionManager().getFunctionAt(address) is not None
    finally:
        (WORK / (selector + ".json")).write_text(json.dumps(observation, indent=2))
        bundle.target_service.close_all()
