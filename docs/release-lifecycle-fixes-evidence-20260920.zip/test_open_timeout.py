import json
import threading
from pathlib import Path

import pytest

from ghidra_mcp.contracts.tool_spec import get_all_tool_specs, get_checkout_required_tool_names
from ghidra_mcp.domain import configure_lock_timeout_seconds, get_lock_timeout_seconds
from ghidra_mcp.presentation.cli_runtime import create_cli_runtime
from test_runtime_readonly_commands import _start_pyghidra_if_needed, _unwrap_runtime_result

WORK = Path(__file__).parent


@pytest.mark.parametrize("registered_before", [False, True])
def test_open_timeout_preserves_target_binding(tmp_path, registered_before):
    _start_pyghidra_if_needed()
    from ghidra_headless.handlers import core

    specs = get_all_tool_specs()
    bundle = create_cli_runtime(registered_specs=specs, core_accessor=lambda: core,
                                checkout_required_commands=get_checkout_required_tool_names(specs))
    api = bundle.runtime.tools
    release = threading.Event()
    acquired = threading.Event()
    holder = None
    previous_timeout = get_lock_timeout_seconds()
    try:
        for name in ("original", "busy"):
            api["create_project"](project_location=str(tmp_path), project_name=name)
        api["register_target"](target="owner", project_location=str(tmp_path), project_name="busy")
        binary = tmp_path / "tiny.bin"
        binary.write_bytes(bytes.fromhex("b8 2a 00 00 00 c3"))
        imported = api["import_program"](target="owner", binary_path=str(binary), import_mode="raw_binary",
                                         language_id="x86:LE:64:default", analyze_imported=False)
        if registered_before:
            api["register_target"](target="subject", project_location=str(tmp_path), project_name="original")
        before = [row for row in api["list_targets"]() if row["target"] == "subject"]
        store = bundle.runtime_backend._store
        project_lock = store.project_locks[store.target_projects["owner"]]

        def hold():
            with project_lock:
                acquired.set()
                assert release.wait(10)

        holder = threading.Thread(target=hold, daemon=True)
        holder.start()
        assert acquired.wait(3)
        configure_lock_timeout_seconds(0.05)
        try:
            with pytest.raises(Exception, match="LOCK_TIMEOUT") as failed:
                api["open_program"](target="subject", project_location=str(tmp_path), project_name="busy",
                                    domain_path=imported["program"])
            error = failed.value.domain_error
            assert error["code"] == "LOCK_TIMEOUT"
            assert error["details"]["lock"] == "project"
        finally:
            release.set()
            holder.join(5)
            configure_lock_timeout_seconds(previous_timeout)
        assert not holder.is_alive()
        after = [row for row in api["list_targets"]() if row["target"] == "subject"]
        observation = {"registered_before": registered_before, "before": before, "after": after,
                       "error": error, "has_session": "subject" in store.sessions}
        if registered_before:
            observation["subsequent_list_programs"] = _unwrap_runtime_result(api["list_project_programs"](target="subject"))
        (WORK / ("registered-timeout.json" if registered_before else "new-target-timeout.json")).write_text(
            json.dumps(observation, indent=2))
        assert after == before, "a failed open must not create or rebind a target"
    finally:
        configure_lock_timeout_seconds(previous_timeout)
        release.set()
        if holder is not None:
            holder.join(5)
        bundle.target_service.close_all()
