import json
from pathlib import Path
import pytest
from test_runtime_import_lifecycle import bundle

@pytest.mark.parametrize('operation',['noop_function','noop_analysis','noop_undo','preview','rollback','edit_undo','edit','noop_script'])
def test_dirty_state(bundle,tmp_path,operation):
    api=bundle.runtime.tools
    api['create_project'](project_location=str(tmp_path),project_name='state')
    api['register_target'](target='state',project_location=str(tmp_path),project_name='state')
    binary=tmp_path/'tiny.bin'; binary.write_bytes(bytes.fromhex('b8 2a 00 00 00 c3'))
    imported=api['import_program'](target='state',binary_path=str(binary),import_mode='raw_binary',language_id='x86:LE:64:default',base_address='0x1000',entry_address='0x1000',analyze_imported=True)
    api['load_project_program'](target='state',domain_path=imported['program'])
    api['save_project_program'](target='state')
    store=bundle.runtime_backend._store
    def observe():
        p=store.sessions['state'].get_program()
        return {'changed':bool(p.isChanged()),'dirty':store.is_dirty_program('state',imported['program']),'can_undo':bool(p.canUndo())}
    before=observe()
    edit={'kind':'set_comment','address':'0x1000','comment_type':'pre','comment':'preview only'}
    if operation=='noop_function': result=api['create_function'](target='state',address='0x1000')
    elif operation=='noop_analysis':result=api['analyze_program'](target='state')
    elif operation=='noop_undo':result=api['undo_program_change'](target='state')
    elif operation=='preview':result=api['apply_edits'](target='state',edits=[edit],dry_run=True)
    elif operation=='rollback':result=api['apply_edits'](target='state',edits=[edit,{'kind':'rename_function','address':'0x9999','new_name':'none'}])
    elif operation=='noop_script':result=api['run_script'](target='state',source='print("no edit")',runtime='PyGhidra')
    else:
        result=api['apply_edits'](target='state',edits=[edit])
        if operation=='edit_undo':result=api['undo_program_change'](target='state')
    after=observe()
    saved=api['save_project_program'](target='state')
    record={'operation':operation,'before':before,'after':after,'result':result,'saved':saved}
    (Path(__file__).parent/f'{operation}.json').write_text(json.dumps(record,indent=2))
    if not after['changed']:
        assert not after['dirty'],record
        assert not saved['saved'],record
