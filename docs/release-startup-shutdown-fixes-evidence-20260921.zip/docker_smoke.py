from pathlib import Path
import json
import subprocess
import sys
import time
from http.client import RemoteDisconnected
from urllib.error import URLError
from urllib.request import ProxyHandler, Request, build_opener
from jsonschema import Draft202012Validator

WORK = Path(__file__).resolve().parent
IMAGE = 'mecha-ghidra:release-audit-20260921'
VERSION = '2026-07-28'

def docker(*args, **kwargs):
    result = subprocess.run(['docker', *args], capture_output=True, text=True, timeout=180, **kwargs)
    if result.returncode:
        raise RuntimeError(f'docker {args}: {result.stderr}')
    return (result.stdout + (result.stderr if args[0] == 'logs' else '')).strip()

def exercise(name, scripts):
    records = []
    def request(method, params):
        params = dict(params)
        params['_meta'] = {
            'io.modelcontextprotocol/protocolVersion': VERSION,
            'io.modelcontextprotocol/clientCapabilities': {},
            'io.modelcontextprotocol/clientInfo': {'name': 'docker-release-audit', 'version': '1'},
        }
        headers = {'Accept': 'application/json, text/event-stream', 'MCP-Protocol-Version': VERSION,
                   'Mcp-Method': method, 'Connection': 'close', 'Content-Type': 'application/json'}
        if 'name' in params:
            headers['Mcp-Name'] = params['name']
        req = Request(url, headers=headers, data=json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params}).encode())
        with build_opener(ProxyHandler({})).open(req, timeout=120) as response:
            assert 'mcp-session-id' not in response.headers
            body = json.load(response)
        assert 'error' not in body, body
        return body['result']

    def call(name, arguments, *, error=False):
        result = request('tools/call', {'name': name, 'arguments': arguments})
        records.append({'name': name, 'arguments': arguments, 'result': result})
        assert result.get('isError', False) == error, result
        Draft202012Validator(schemas[name]['outputSchema']).validate(result['structuredContent'])
        return result['structuredContent']

    try:
        port = docker('port', name, '8081/tcp').rsplit(':', 1)[1]
        url = f'http://127.0.0.1:{port}/mcp'
        deadline = time.monotonic() + 120
        while True:
            try:
                discovery = request('server/discover', {})
                break
            except (URLError, RemoteDisconnected):
                assert time.monotonic() < deadline
                assert docker('inspect', '-f', '{{.State.Running}}', name) == 'true', docker('logs', name)
                time.sleep(.25)
        assert 'Ghidra' in discovery['instructions']
        schemas = {tool['name']: tool for tool in request('tools/list', {})['tools']}
        for tool in schemas.values():
            Draft202012Validator.check_schema(tool['inputSchema'])
            Draft202012Validator.check_schema(tool['outputSchema'])
        assert ('run_script' in schemas) == scripts
        assert docker('exec', name, 'id', '-u') == '10001'
        assert call('list_targets', {})['result'][0]['target'] == 'default'
        call('create_project', {'project_location': '/data/projects', 'project_name': 'default'})
        docker('exec', name, '/app/.venv/bin/python', '-c', "from pathlib import Path; Path('/samples/tiny.bin').write_bytes(bytes.fromhex('b8 2a 00 00 00 c3'))")
        imported = call('import_program', {'target': 'default', 'binary_path': '/samples/tiny.bin', 'import_mode': 'raw_binary', 'language_id': 'x86:LE:64:default', 'base_address': '0x1000', 'entry_address': '0x1000', 'analyze_imported': True})
        domain = imported['result']['program']
        call('load_project_program', {'target': 'default', 'domain_path': domain})
        assert '0x2a' in call('decompile_function', {'target': 'default', 'address': '0x1000'})['result']
        if scripts:
            for runtime in ('Java', 'Jython', 'PyGhidra'):
                source = 'print("docker script success")\n'
                args = {'target': 'default', 'runtime': runtime, 'source': source}
                if runtime == 'Java':
                    args.update(script_name='DockerCheck.java', source='import ghidra.app.script.GhidraScript;\npublic class DockerCheck extends GhidraScript { public void run() { println("docker script success"); } }\n')
                data = call('run_script', args)['result']
                assert data['transaction_outcome'] == 'unchanged', data
                assert 'docker script success' in data['stdout']['text'], data
            call('run_script', {'target': 'default', 'runtime': 'PyGhidra', 'source': 'raise RuntimeError("docker expected failure")\n'}, error=True)
        call('save_project_program', {'target': 'default'})
        call('close_session', {'target': 'default'})
        call('load_project_program', {'target': 'default', 'domain_path': domain})
        assert '0x2a' in call('decompile_function', {'target': 'default', 'address': '0x1000'})['result']
        call('close_session', {'target': 'default'})
        print(json.dumps({'container': name, 'tools': len(schemas), 'calls': len(records), 'scripts': scripts, 'status': 'passed'}), flush=True)
    finally:
        (WORK / f'{name}-calls.json').write_text(json.dumps(records, ensure_ascii=False, indent=2))
        docker('stop', '--time', '30', name)
        state = json.loads(docker('inspect', name))[0]['State']
        (WORK / f'{name}-state.json').write_text(json.dumps(state, indent=2))
        (WORK / f'{name}.log').write_text(docker('logs', name))
        filesystem = docker('diff', name)
        (WORK / f'{name}-filesystem.txt').write_text(filesystem)
        docker('rm', name)
        assert 'mecha_ghidra_scripts_' not in filesystem, filesystem
        assert state['ExitCode'] != 137, state

if '--scripts-only' not in sys.argv:
    docker('run', '-d', '--name', 'mecha-release-audit-20260921', '-p', '127.0.0.1::8081', '--memory', '4g', '-e', 'JAVA_TOOL_OPTIONS=-Xmx2g', IMAGE)
    exercise('mecha-release-audit-20260921', False)
name = 'mecha-release-scripts-20260921'
cmd = json.loads(docker('image', 'inspect', IMAGE))[0]['Config']['Cmd']
docker('run', '-d', '--name', name, '-p', '127.0.0.1::8081', '--memory', '4g', '-e', 'JAVA_TOOL_OPTIONS=-Xmx2g', IMAGE, *cmd, '--add-category', 'scripts')
exercise(name, True)
