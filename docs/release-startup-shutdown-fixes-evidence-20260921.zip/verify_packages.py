from pathlib import Path
import json
import os
import subprocess
import tarfile
import zipfile

root = Path('/Users/samsepi0l/ghidra/mecha_ghidra')
work = Path(__file__).resolve().parent
source = {str(p.relative_to(root/'src')): p.read_bytes() for p in (root/'src').rglob('*.py')}
with zipfile.ZipFile(work/'dist/ghidra_mcp-1.0.0-py3-none-any.whl') as archive:
    for name, data in source.items():
        assert archive.read(name) == data, name
    archive.extractall(work/'wheel-extracted-final')
with tarfile.open(work/'dist/ghidra_mcp-1.0.0.tar.gz') as archive:
    for name, data in source.items():
        assert archive.extractfile('ghidra_mcp-1.0.0/src/'+name).read() == data, name
code = '''import ghidra_mcp, ghidra_headless
from pathlib import Path
import sys
base = Path(sys.argv[1])
assert Path(ghidra_mcp.__file__).is_relative_to(base)
assert Path(ghidra_headless.__file__).is_relative_to(base)
from ghidra_mcp.cli import main
main(['--help'])
'''
env = dict(os.environ, PYTHONPATH=str(work/'wheel-extracted-final'), PYTHONDONTWRITEBYTECODE='1')
result = subprocess.run([str(root/'.venv/bin/python'), '-c', code, str(work/'wheel-extracted-final')], cwd=work, env=env, capture_output=True, text=True)
(work/'wheel-cli-help-final.log').write_text(result.stdout+result.stderr)
assert result.returncode == 0, result.stderr
report = {'source_modules':len(source), 'wheel_matches_source': True, 'sdist_matches_source': True, 'wheel_cli_help': 'passed', 'dependency_environment': 'existing .venv; application code from extracted wheel'}
(work/'package-validation-final.json').write_text(json.dumps(report, indent=2))
print(json.dumps(report))
