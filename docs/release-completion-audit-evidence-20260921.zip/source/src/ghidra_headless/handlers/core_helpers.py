"""Core helper functions extracted from legacy core handler."""

from __future__ import absolute_import, print_function

import os

import jpype
from ghidra.app.decompiler import DecompInterface
from ghidra.app.util.parser import FunctionSignatureParser
from ghidra.program.model.data import (
    BooleanDataType,
    CategoryPath,
    CharDataType,
    DataUtilities,
    DoubleDataType,
    FloatDataType,
    IntegerDataType,
    LongLongDataType,
    ShortDataType,
    StringDataType,
    UnicodeDataType,
    UnsignedCharDataType,
    UnsignedIntegerDataType,
    UnsignedLongLongDataType,
    UnsignedShortDataType,
    VoidDataType,
)

from ghidra_headless.errors import HeadlessError
from ghidra_headless.installation import validate_linux_arm64_decompiler_install

_GHIDRA_PROGRAM_UTILITIES = None
_GHIDRA_SCRIPT_UTIL = None


def _to_int(value, default):
    if value is None:
        return default
    try:
        return int(value)
    except Exception:
        return default


def _txn(ctx, description, func):
    _ensure_checkout_for_versioned_program(ctx)
    tx_id = ctx.program.startTransaction(description)
    success = False
    try:
        result = func()
        success = True
        return result
    finally:
        ctx.program.endTransaction(tx_id, success)


def _safe_call(obj, name, *args):
    method = getattr(obj, name, None)
    if method is None:
        return None
    try:
        return method(*args)
    except Exception:
        return None


def _required_domain_file_call(domain_file, name):
    method = getattr(domain_file, name, None)
    if method is None:
        raise HeadlessError("SYNC_STATUS_UNAVAILABLE: DomainFile.%s is unavailable" % name)
    try:
        return method()
    except Exception as exc:
        raise HeadlessError("SYNC_STATUS_UNAVAILABLE: failed to call DomainFile.%s: %s" % (name, exc)) from exc


def _iter_items(items):
    if items is None:
        return

    has_next = getattr(items, "hasNext", None)
    next_item = getattr(items, "next", None)
    if callable(has_next) and callable(next_item):
        while bool(has_next()):
            yield next_item()
        return

    iterator_fn = getattr(items, "iterator", None)
    if callable(iterator_fn):
        # Do not use _safe_call here: failure to acquire a backend iterator is
        # an operation failure, not evidence that the collection is empty.
        iterator = iterator_fn()
        if iterator is not None:
            for item in _iter_items(iterator):
                yield item
            return

    try:
        python_iter = iter(items)
    except TypeError:
        python_iter = None
    if python_iter is not None:
        # Only the iter() acquisition may fail for a non-iterable; do not wrap the
        # consumption loop, otherwise a mid-iteration error silently truncates the
        # result and the caller reports a partial list as complete.
        for item in python_iter:
            yield item
        return

    if callable(next_item):
        while True:
            try:
                yield next_item()
            except StopIteration:
                break
            except Exception as exc:
                # Java-style iterators exposing next() without hasNext signal
                # exhaustion with java.util.NoSuchElementException (mapped by
                # jpype), not StopIteration; any other error must propagate so
                # a mid-iteration failure does not truncate the result.
                if _is_java_no_such_element(exc):
                    break
                raise


def _is_java_no_such_element(exc):
    return any(
        getattr(cls, "__name__", "") in {"NoSuchElementException", "java.util.NoSuchElementException"}
        for cls in type(exc).__mro__
    )


def _json_safe(value):
    if value is None or isinstance(value, (bool, int, float, str)):
        return value
    if isinstance(value, dict):
        return {str(k): _json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [_json_safe(v) for v in value]

    has_next = getattr(value, "hasNext", None)
    next_item = getattr(value, "next", None)
    if callable(has_next) and callable(next_item):
        return [_json_safe(v) for v in _iter_items(value)]

    iterator_fn = getattr(value, "iterator", None)
    if callable(iterator_fn):
        return [_json_safe(v) for v in _iter_items(value)]

    return str(value)


def _namespace_key(namespace):
    namespace_id = _safe_call(namespace, "getID")
    if namespace_id is not None:
        return "id:%s" % namespace_id
    full_name = _safe_call(namespace, "getName", True)
    if full_name:
        return "name:%s" % full_name
    return "repr:%s" % namespace


def _iter_symbol_table_symbols(symbol_table):
    probes = [
        ("getAllSymbols", (True,)),
        ("getAllSymbols", ()),
        ("getSymbolIterator", (True,)),
        ("getSymbolIterator", ()),
    ]
    for method_name, args in probes:
        symbols = _safe_call(symbol_table, method_name, *args)
        if symbols is None:
            continue
        for symbol in _iter_items(symbols):
            yield symbol
        return


def _iter_namespaces(ctx):
    manager = getattr(ctx, "namespace_manager", None)
    if manager is not None:
        for args in ((True,), ()):
            namespaces = _safe_call(manager, "getNamespaces", *args)
            if namespaces is None:
                continue
            for namespace in _iter_items(namespaces):
                yield namespace
            return

    seen = set()
    for symbol in _iter_symbol_table_symbols(ctx.symbol_table):
        parent = _safe_call(symbol, "getParentNamespace")
        if parent is not None and not bool(_safe_call(parent, "isGlobal")):
            key = _namespace_key(parent)
            if key not in seen:
                seen.add(key)
                yield parent

        symbol_type = _safe_call(symbol, "getSymbolType")
        if symbol_type is None or str(symbol_type).upper() != "CLASS":
            continue
        class_namespace = _safe_call(symbol, "getObject")
        if class_namespace is None or bool(_safe_call(class_namespace, "isGlobal")):
            continue
        class_key = _namespace_key(class_namespace)
        if class_key in seen:
            continue
        seen.add(class_key)
        yield class_namespace


def _is_exported_symbol(ctx, symbol):
    if symbol is None:
        return False

    exported = _safe_call(symbol, "isExported")
    if exported is not None:
        return bool(exported)

    exported = _safe_call(symbol, "isExternalEntryPoint")
    if exported is not None:
        return bool(exported)

    address = _safe_call(symbol, "getAddress")
    if address is not None:
        exported = _safe_call(ctx.symbol_table, "isExternalEntryPoint", address)
        if exported is not None:
            return bool(exported)
    return False


def _ensure_checkout_for_versioned_program(ctx):
    program = getattr(ctx, "program", None)
    if program is None:
        return
    try:
        domain_file = program.getDomainFile()
    except Exception as exc:
        raise HeadlessError("SYNC_STATUS_UNAVAILABLE: failed to resolve DomainFile: %s" % exc)
    if domain_file is None:
        return

    is_versioned = _required_domain_file_call(domain_file, "isVersioned")
    is_hijacked = _required_domain_file_call(domain_file, "isHijacked")
    if bool(is_hijacked):
        raise HeadlessError(
            "HIJACKED_PROGRAM: mutating a hijacked shared-project file is not allowed. "
            "Resolve the hijacked file before retrying"
        )
    if not bool(is_versioned):
        return
    is_checked_out = _required_domain_file_call(domain_file, "isCheckedOut")
    if bool(is_checked_out):
        return
    raise HeadlessError(
        "CHECKOUT_REQUIRED: checkout is required for mutating operations on shared projects. "
        "Run checkout_project_program first"
    )


def _pick_function(candidates):
    """Resolve one function without guessing between names in different namespaces."""
    unique = {str(fn.getEntryPoint()): fn for fn in candidates if fn is not None}
    if len(unique) > 1:
        raise HeadlessError(
            "AMBIGUOUS_FUNCTION: use an address or a unique qualified name",
            details={
                "candidates": [
                    {"entry": entry, "full_name": str(fn.getName(True))} for entry, fn in sorted(unique.items())[:20]
                ],
                "candidate_count": len(unique),
            },
        )
    return next(iter(unique.values()), None)


def _indexed_functions_named(ctx, name):
    """Yield functions named ``name`` through the symbol table index.

    ``SymbolTable.getSymbols(name)`` is an indexed lookup, unlike walking every
    function with ``getFunctions(True)``.  Returns None when the index is not
    available so the caller can fall back to the full scan.
    """
    symbol_table = getattr(ctx, "symbol_table", None)
    symbols = _safe_call(symbol_table, "getSymbols", name) if symbol_table is not None else None
    if symbols is None:
        return None
    functions = []
    for symbol in _iter_items(symbols):
        symbol_type = _safe_call(symbol, "getSymbolType")
        if symbol_type is None or str(symbol_type).upper() != "FUNCTION":
            continue
        function = _safe_call(symbol, "getObject")
        if function is not None:
            functions.append(function)
    return functions


def _find_function_by_name(ctx, name):
    name = str(name)
    qualified = "::" in name
    indexed = _indexed_functions_named(ctx, name.rsplit("::", 1)[-1])
    if indexed is not None:
        if qualified:
            indexed = [fn for fn in indexed if str(fn.getName(True)) == name]
        picked = _pick_function(indexed)
        if picked is not None:
            return picked
    iterator = ctx.function_manager.getFunctions(True)
    return _pick_function(
        fn for fn in _iter_items(iterator) if str(fn.getName(True) if qualified else fn.getName()) == name
    )


def _get_address(ctx, address_text):
    if not address_text:
        raise ValueError("address is empty")
    address = ctx.address_factory.getAddress(address_text)
    if address is None:
        raise ValueError("Invalid address: %s" % address_text)
    return address


def _collect(iterator, offset, limit, to_value):
    if limit <= 0:
        return []
    offset = max(offset, 0)
    result = []
    idx = 0
    for item in _iter_items(iterator):
        if idx >= offset:
            result.append(to_value(item))
            if len(result) >= limit:
                break
        idx += 1
    return result


def _dt_manager(ctx):
    return ctx.program.getDataTypeManager()


def _find_data_type_by_name(dtm, type_name):
    if not type_name:
        return None

    query = str(type_name).strip()
    if not query:
        return None
    query_lower = query.lower()
    query_compact = query_lower.replace(" ", "")
    # An explicit path never falls back to a similarly named type elsewhere.
    if "/" in query:
        return dtm.getDataType(query if query.startswith("/") else "/" + query)

    candidates = {}

    iterator = _safe_call(dtm, "getAllDataTypes")
    if iterator is not None:
        while iterator.hasNext():
            data_type = iterator.next()
            names = [
                _safe_call(data_type, "getName"),
                _safe_call(data_type, "getDisplayName"),
                _safe_call(data_type, "getPathName"),
                _safe_call(data_type, "getName", True),
            ]
            for name in names:
                if not name:
                    continue
                text = str(name)
                text_lower = text.lower()
                if text_lower.replace(" ", "") == query_compact or text_lower.endswith("/" + query_lower):
                    candidates[str(data_type.getPathName())] = data_type
    if len(candidates) > 1:
        raise HeadlessError(
            "AMBIGUOUS_DATA_TYPE: use the full data type path",
            details={"candidates": sorted(candidates)[:20], "candidate_count": len(candidates)},
        )
    return next(iter(candidates.values()), None)


def _parse_clear_data_mode(clear_mode_text):
    clear_data_mode = DataUtilities.ClearDataMode
    mapping = {
        "CHECK_FOR_SPACE": clear_data_mode.CHECK_FOR_SPACE,
        "CLEAR_SINGLE_DATA": clear_data_mode.CLEAR_SINGLE_DATA,
        "CLEAR_ALL_UNDEFINED_CONFLICT_DATA": clear_data_mode.CLEAR_ALL_UNDEFINED_CONFLICT_DATA,
        "CLEAR_ALL_DEFAULT_CONFLICT_DATA": clear_data_mode.CLEAR_ALL_DEFAULT_CONFLICT_DATA,
        "CLEAR_ALL_CONFLICT_DATA": clear_data_mode.CLEAR_ALL_CONFLICT_DATA,
    }
    if not clear_mode_text:
        return mapping["CHECK_FOR_SPACE"]
    normalized = str(clear_mode_text).strip().upper()
    mode = mapping.get(normalized)
    if mode is None:
        allowed = ", ".join(sorted(mapping.keys()))
        raise ValueError("Invalid clear_mode: %s (allowed: %s)" % (clear_mode_text, allowed))
    return mode


def _parse_data_type(ctx, type_str):
    if not type_str:
        raise ValueError("data_type is required")

    dtm = _dt_manager(ctx)
    text = type_str.strip()
    for needle in ("\t", "\n", "\r"):
        text = text.replace(needle, " ")
    text = " ".join(text.split())
    text = " ".join([token for token in text.split(" ") if token.lower() not in {"const", "volatile"}])

    pointer_depth = 0
    while text.endswith("*"):
        pointer_depth += 1
        text = text[:-1].strip()

    builtin = {
        "void": VoidDataType.dataType,
        "char": CharDataType.dataType,
        "signed char": CharDataType.dataType,
        "uchar": UnsignedCharDataType.dataType,
        "unsigned char": UnsignedCharDataType.dataType,
        "short": ShortDataType.dataType,
        "unsigned short": UnsignedShortDataType.dataType,
        "ushort": UnsignedShortDataType.dataType,
        "int": IntegerDataType.dataType,
        "unsigned": UnsignedIntegerDataType.dataType,
        "unsigned int": UnsignedIntegerDataType.dataType,
        "uint": UnsignedIntegerDataType.dataType,
        "long long": LongLongDataType.dataType,
        "unsigned long long": UnsignedLongLongDataType.dataType,
        "ull": UnsignedLongLongDataType.dataType,
        "float": FloatDataType.dataType,
        "double": DoubleDataType.dataType,
        "bool": BooleanDataType.dataType,
        "boolean": BooleanDataType.dataType,
        "string": StringDataType.dataType,
        "unicode": UnicodeDataType.dataType,
    }

    pointer_alias = {
        "pvoid": "void",
        "lpvoid": "void",
        "lpcstr": "char",
        "pcstr": "char",
        "lpstr": "char",
        "lpwstr": "unicode",
        "lpcwstr": "unicode",
        "pwstr": "unicode",
    }

    lowered = text.lower()
    dt = None
    if lowered in builtin:
        dt = builtin[lowered]
    elif lowered in pointer_alias:
        dt = builtin[pointer_alias[lowered]]
        pointer_depth += 1
    else:
        dt = _find_data_type_by_name(dtm, text)
    if dt is None:
        raise ValueError("unknown data type: %s" % type_str)

    for _ in range(pointer_depth):
        dt = dtm.getPointer(dt)
    return dt


def _new_java_byte_buffer(size):
    try:
        return jpype.JArray(jpype.JByte)(size)
    except Exception:
        return bytearray(size)


def _hexdump(memory, start_address, size):
    buffer = _new_java_byte_buffer(size)
    read = memory.getBytes(start_address, buffer)
    if read < 0:
        raise RuntimeError("Failed to read memory")
    lines = []
    base = start_address
    for idx in range(0, read, 16):
        chunk = [int(buffer[i]) & 0xFF for i in range(idx, min(idx + 16, read))]
        hex_part = " ".join(["%02X" % b for b in chunk])
        lines.append("%s  %s" % (base.add(idx), hex_part))
    return "\n".join(lines)


def _ghidra_program_utilities():
    global _GHIDRA_PROGRAM_UTILITIES
    if _GHIDRA_PROGRAM_UTILITIES is None:
        from ghidra.program.util import GhidraProgramUtilities

        _GHIDRA_PROGRAM_UTILITIES = GhidraProgramUtilities
    return _GHIDRA_PROGRAM_UTILITIES


def _ghidra_script_util():
    global _GHIDRA_SCRIPT_UTIL
    if _GHIDRA_SCRIPT_UTIL is None:
        from ghidra.app.script import GhidraScriptUtil

        _GHIDRA_SCRIPT_UTIL = GhidraScriptUtil
    return _GHIDRA_SCRIPT_UTIL


def _analyze_program_if_needed(ctx):
    utilities = _ghidra_program_utilities()
    if not utilities.shouldAskToAnalyze(ctx.program):
        return False
    script_util = _ghidra_script_util()
    script_util.acquireBundleHostReference()
    try:
        ctx.flat_api.analyzeAll(ctx.program)
        utilities.markProgramAnalyzed(ctx.program)
    finally:
        script_util.releaseBundleHostReference()
    return True


def _analyze_program(ctx, force=False):
    _ensure_checkout_for_versioned_program(ctx)
    utilities = _ghidra_program_utilities()
    if not force and not utilities.shouldAskToAnalyze(ctx.program):
        return False
    script_util = _ghidra_script_util()
    script_util.acquireBundleHostReference()
    try:

        def _analyze():
            ctx.flat_api.analyzeAll(ctx.program)
            utilities.markProgramAnalyzed(ctx.program)
            return True

        _txn(ctx, "Auto analysis", _analyze)
    finally:
        script_util.releaseBundleHostReference()
    return True


DECOMPILE_TIMEOUT_SECONDS = 120


def _open_decompiler(ctx):
    """Return the context's shared decompiler or a one-shot interface."""
    shared = getattr(ctx, "decompiler", None)
    if callable(shared):
        interface = shared(DecompInterface)
        if interface is not None:
            return interface, False
    else:
        interface = DecompInterface()
        if interface.openProgram(ctx.program):
            return interface, True
        interface.dispose()
    ghidra_install_dir = os.environ.get("GHIDRA_INSTALL_DIR")
    try:
        validate_linux_arm64_decompiler_install(ghidra_install_dir)
    except RuntimeError as exc:
        raise RuntimeError(str(exc))
    raise RuntimeError("Failed to initialize decompiler")


def _with_decompiler(ctx, action):
    interface, one_shot = _open_decompiler(ctx)
    try:
        results = action(interface)
    except Exception:
        # A failed call may leave the native process unusable; drop the shared
        # instance so the next call starts a fresh decompiler.
        reset = getattr(ctx, "reset_decompiler", None)
        if callable(reset) and not one_shot:
            reset()
        raise
    finally:
        if one_shot:
            interface.dispose()
    return results


def _decompile_function_object(ctx, function):
    def _run(interface):
        results = interface.decompileFunction(function, DECOMPILE_TIMEOUT_SECONDS, ctx.monitor())
        if results is None:
            raise RuntimeError("Decompilation failed")
        decompiled = results.getDecompiledFunction()
        if decompiled is not None:
            return decompiled.getC()
        detail = (results.getErrorMessage() or "").strip()
        if detail:
            raise RuntimeError("Decompilation result is empty: %s" % detail)
        raise RuntimeError("Decompilation result is empty")

    return _with_decompiler(ctx, _run)


def _decompile_high_function(ctx, function):
    def _run(interface):
        results = interface.decompileFunction(function, DECOMPILE_TIMEOUT_SECONDS, ctx.monitor())
        if results is None:
            raise RuntimeError("Decompilation failed")
        if not results.decompileCompleted():
            detail = (results.getErrorMessage() or "").strip()
            if detail:
                raise RuntimeError("Decompilation failed: %s" % detail)
            raise RuntimeError("Decompilation failed")
        high_function = results.getHighFunction()
        if high_function is None:
            raise RuntimeError("Failed to obtain high-level function info")
        return high_function

    try:
        return _with_decompiler(ctx, _run)
    except RuntimeError as exc:
        # Do not start a multi-minute auto-analysis as a hidden side effect of a
        # rename/retype call: tell the caller what to run instead.
        try:
            needs_analysis = bool(_ghidra_program_utilities().shouldAskToAnalyze(ctx.program))
        except Exception:
            needs_analysis = False
        if needs_analysis:
            raise HeadlessError(
                "PROGRAM_NOT_ANALYZED: the program has not been analyzed, so decompiler "
                "symbols are unavailable; run analyze_program first (%s)" % exc
            ) from exc
        raise


def _requires_full_param_commit(high_symbol, high_function):
    try:
        if high_symbol is not None and not bool(high_symbol.isParameter()):
            return False
        function = high_function.getFunction()
        params = function.getParameters()
        local_symbol_map = high_function.getLocalSymbolMap()
        num_params = int(local_symbol_map.getNumParams())
        if num_params != len(params):
            return True
        for index in range(num_params):
            param_symbol = local_symbol_map.getParamSymbol(index)
            if param_symbol is None:
                return True
            if int(param_symbol.getCategoryIndex()) != index:
                return True
            storage = param_symbol.getStorage()
            if storage is None:
                return True
            if int(storage.compareTo(params[index].getVariableStorage())) != 0:
                return True
        return False
    except Exception:
        return True


def _build_signature_parser(ctx):
    data_type_manager = ctx.program.getDataTypeManager()
    try:
        return FunctionSignatureParser(data_type_manager, None)
    except TypeError:
        # Some environments only provide the single-argument signature.
        return FunctionSignatureParser(data_type_manager)


def _decode_hex_bytes(hex_string):
    cleaned = "".join(hex_string.split())
    if len(cleaned) % 2 != 0:
        raise ValueError("Invalid bytes length")
    try:
        return bytearray.fromhex(cleaned)
    except Exception:
        raise ValueError("bytes must be hexadecimal")


def _get_struct_datatype(ctx, name, category):
    dtm = _dt_manager(ctx)
    cp = CategoryPath(category) if category else CategoryPath("/")
    return dtm.getDataType(cp, name)


def _get_enum_datatype(ctx, name, category):
    dtm = _dt_manager(ctx)
    cp = CategoryPath(category) if category else CategoryPath("/")
    return dtm.getDataType(cp, name)


def _describe_struct(struct_dt):
    members = []
    for component in struct_dt.getComponents():
        members.append(
            {
                "offset": component.getOffset(),
                "length": component.getLength(),
                "name": component.getFieldName() or "",
                "type": component.getDataType().getDisplayName(),
                "comment": component.getComment() or "",
            }
        )
    category = struct_dt.getCategoryPath()
    return {
        "name": struct_dt.getName(),
        "category": category.getPath() if category else "/",
        "length": struct_dt.getLength(),
        "members": members,
    }


def _describe_enum(enum_dt):
    values = []
    for name in enum_dt.getNames():
        values.append(
            {
                "name": name,
                "value": int(enum_dt.getValue(name)),
                "comment": enum_dt.getComment(name) or "",
            }
        )
    category = enum_dt.getCategoryPath()
    return {
        "name": enum_dt.getName(),
        "category": category.getPath() if category else "/",
        "size": enum_dt.getLength(),
        "count": enum_dt.getCount(),
        "values": values,
        "isSigned": bool(enum_dt.isSigned()),
    }


def _describe_data_type(data_type):
    category = _safe_call(data_type, "getCategoryPath")
    path = _safe_call(data_type, "getPathName")
    java_class = _safe_call(data_type, "getClass")
    kind = None
    if java_class is not None:
        kind = _safe_call(java_class, "getSimpleName")
    return {
        "name": _safe_call(data_type, "getName"),
        "display_name": _safe_call(data_type, "getDisplayName"),
        "path": str(path) if path is not None else None,
        "category": category.getPath() if category else "/",
        "length": _safe_call(data_type, "getLength"),
        "kind": str(kind) if kind is not None else data_type.__class__.__name__,
    }


def _component_length(data_type):
    length = data_type.getLength()
    return length if length > 0 else 1


__all__ = [
    "_to_int",
    "_txn",
    "_safe_call",
    "_iter_items",
    "_json_safe",
    "_namespace_key",
    "_iter_symbol_table_symbols",
    "_iter_namespaces",
    "_is_exported_symbol",
    "_ensure_checkout_for_versioned_program",
    "_find_function_by_name",
    "_get_address",
    "_collect",
    "_dt_manager",
    "_find_data_type_by_name",
    "_parse_clear_data_mode",
    "_parse_data_type",
    "_new_java_byte_buffer",
    "_hexdump",
    "_ghidra_program_utilities",
    "_ghidra_script_util",
    "_analyze_program_if_needed",
    "_analyze_program",
    "_decompile_function_object",
    "_decompile_high_function",
    "_requires_full_param_commit",
    "_build_signature_parser",
    "_decode_hex_bytes",
    "_get_struct_datatype",
    "_get_enum_datatype",
    "_describe_struct",
    "_describe_enum",
    "_describe_data_type",
    "_component_length",
]
