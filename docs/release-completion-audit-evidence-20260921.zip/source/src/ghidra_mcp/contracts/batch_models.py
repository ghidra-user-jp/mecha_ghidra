"""Derive a discriminated batch contract from the existing read input models."""

from typing import Annotated, Literal, Union

from pydantic import Field, create_model, model_validator

from .tool_models import ToolInputModel

# The headless core has an independent guard for direct callers. Keep this
# contract independent of the runtime layer; parity is checked in tests.
BATCH_READ_TOOLS = frozenset({"get_function", "get_comments", "get_data_type", "get_xrefs", "get_call_edges"})


class BatchInput(ToolInputModel):
    @model_validator(mode="after")
    def check_requests(self):
        ids = [request.id for request in self.requests]
        if len(set(ids)) != len(ids):
            raise ValueError("batch_read ids must be unique")
        page_rows = 0
        for request in self.requests:
            args = request.arguments.model_dump(exclude_none=True)
            if request.tool in {"get_function", "get_call_edges"} and not (args.get("address") or args.get("name")):
                raise ValueError("%s requires address or name" % request.tool)
            if request.tool in {"get_comments", "get_xrefs"} and not args.get("address"):
                raise ValueError("%s requires address" % request.tool)
            if request.tool == "get_data_type" and not args.get("path"):
                raise ValueError("get_data_type requires path")
            if request.tool in {"get_xrefs", "get_call_edges"}:
                page_rows += args["limit"]
        if page_rows > 2000:
            raise ValueError("batch_read page limits must total at most 2000 rows")
        return self


def batch_input_model(specs):
    variants = []
    for name in sorted(BATCH_READ_TOOLS):
        variants.append(
            create_model(
                "Batch" + specs[name].input_model.__name__,
                __base__=ToolInputModel,
                id=(Annotated[str, Field(min_length=1, max_length=32, pattern=r"^[A-Za-z0-9_-]+$")], ...),
                tool=(Literal[name], ...),
                arguments=(specs[name].input_model, ...),
                fields=(
                    Annotated[
                        list[Annotated[str, Field(min_length=1, max_length=128)]], Field(min_length=1, max_length=32)
                    ]
                    | None,
                    None,
                ),
            )
        )
    request_type = Annotated[Union[tuple(variants)], Field(discriminator="tool")]
    return create_model(
        "BatchReadInput",
        __base__=BatchInput,
        requests=(Annotated[list[request_type], Field(min_length=1, max_length=20)], ...),
        expected_revision=(Annotated[str, Field(max_length=128)] | None, None),
        timeout_seconds=(Annotated[int, Field(ge=1, le=60)], 10),
        max_output_chars=(Annotated[int, Field(ge=2048, le=12000)], 12000),
    )
