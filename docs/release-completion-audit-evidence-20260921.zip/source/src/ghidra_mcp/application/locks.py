"""Shared locking primitives for application and runtime operations."""

from __future__ import annotations

import contextlib
import threading
import time
from collections import deque
from collections.abc import Callable, Hashable, Iterable, Iterator
from contextlib import ExitStack
from dataclasses import dataclass
from typing import Any

from ghidra_mcp.domain import LOCK_ORDER, DomainError, ErrorCode, get_lock_timeout_seconds


class _UsePolicy:
    """Sentinel: resolve the wait from the runtime lock policy at call time."""


USE_POLICY_TIMEOUT = _UsePolicy()


class ScriptBarrier:
    """Process-wide reader/writer barrier around Ghidra script execution.

    Scripts mutate state that no per-RuntimeState lock covers (sys.modules,
    the OSGi bundle host, the Jython runtime), so every runtime instance in
    the process shares one barrier: ordinary commands hold it as readers,
    script execution and provider initialization as the writer.

    A script may run for up to an hour, or forever when it ignores its
    monitor, so readers do not wait for it unboundedly: while a writer is
    pending or active, ``read_lock`` waits at most ``timeout`` seconds (the
    runtime lock policy by default) and then raises a retryable
    ``LOCK_TIMEOUT``.  ``write_lock(timeout=...)`` gives shutdown the same
    bound against running readers and scripts. Acquisition and ownership
    changes use one condition: no unbounded lock acquisition follows the
    timed wait. Waiting writers run in FIFO order and block new readers;
    existing owners may re-enter without waiting for themselves.
    """

    def __init__(self) -> None:
        self._condition = threading.Condition()
        self._readers: dict[threading.Thread, int] = {}
        self._writer: threading.Thread | None = None
        self._writer_depth = 0
        self._pending_writers: deque[object] = deque()

    @property
    def writer_pending(self) -> bool:
        with self._condition:
            return self._writer is not None or bool(self._pending_writers)

    def _wait_until(self, predicate: Callable[[], bool], timeout: float | _UsePolicy | None, *, role: str) -> None:
        """Wait with the condition held; the caller records ownership before releasing it."""
        if isinstance(timeout, _UsePolicy):
            timeout = get_lock_timeout_seconds()
        if self._condition.wait_for(predicate, timeout=timeout):
            return
        raise DomainError(
            code=ErrorCode.LOCK_TIMEOUT,
            message=(
                f"Failed to acquire the script barrier as {role}: another operation or Ghidra script "
                "has not finished within the lock timeout"
            ),
            hint="Retry after the running operation completes; long scripts should check monitor.checkCancelled()",
            retryable=True,
            details={"lock": "script_barrier", "timeout": timeout},
        )

    @contextlib.contextmanager
    def read_lock(self, timeout: float | _UsePolicy | None = USE_POLICY_TIMEOUT) -> Iterator[None]:
        current = threading.current_thread()
        with self._condition:
            self._wait_until(
                lambda: (
                    self._writer is current
                    or (self._writer is None and (current in self._readers or not self._pending_writers))
                ),
                timeout,
                role="reader",
            )
            self._readers[current] = self._readers.get(current, 0) + 1
        try:
            yield
        finally:
            with self._condition:
                self._readers[current] -= 1
                if self._readers[current] == 0:
                    del self._readers[current]
                self._condition.notify_all()

    @contextlib.contextmanager
    def write_lock(self, timeout: float | _UsePolicy | None = None) -> Iterator[None]:
        """Exclusive section.  ``timeout=None`` (the default) queues behind a running writer."""

        current = threading.current_thread()
        with self._condition:
            if self._writer is current:
                self._writer_depth += 1
            else:
                if current in self._readers:
                    raise RuntimeError("Cannot upgrade a script barrier reader to a writer")
                ticket = object()
                self._pending_writers.append(ticket)
                try:
                    self._wait_until(
                        lambda: self._writer is None and not self._readers and self._pending_writers[0] is ticket,
                        timeout,
                        role="writer",
                    )
                    self._writer = current
                    self._writer_depth = 1
                finally:
                    # Timeouts and interruptions must not strand readers or
                    # later writers behind a ticket that can never acquire.
                    self._pending_writers.remove(ticket)
                    self._condition.notify_all()
        try:
            yield
        finally:
            with self._condition:
                self._writer_depth -= 1
                if self._writer_depth == 0:
                    self._writer = None
                self._condition.notify_all()


SCRIPT_BARRIER = ScriptBarrier()


@contextlib.contextmanager
def acquire_ordered_locks(
    locks: Iterable[tuple[str, Any]],
    *,
    timeout: float | _UsePolicy | None = USE_POLICY_TIMEOUT,
    order: tuple[str, ...] = LOCK_ORDER,
    message_prefix: str = "",
) -> Iterator[None]:
    """Acquire locks in caller-supplied order using one shared deadline.

    ``timeout=None`` waits forever; the default reads the configurable policy
    (``configure_lock_timeout_seconds``) when the lock is requested.
    """

    if isinstance(timeout, _UsePolicy):
        timeout = get_lock_timeout_seconds()
    deadline = None if timeout is None else time.monotonic() + timeout
    acquired: list[Any] = []
    try:
        for lock_name, lock in locks:
            if deadline is None:
                acquired_lock = lock.acquire()
            else:
                remaining = max(0.0, deadline - time.monotonic())
                acquired_lock = lock.acquire(timeout=remaining)
            if not acquired_lock:
                raise DomainError(
                    code=ErrorCode.LOCK_TIMEOUT,
                    message=f"Failed to acquire {message_prefix}{lock_name} lock",
                    hint=f"Lock acquisition order: {' -> '.join(order)}",
                    retryable=True,
                    details={"lock": lock_name, "timeout": timeout},
                )
            acquired.append(lock)
        yield
    finally:
        while acquired:
            acquired.pop().release()


@dataclass(slots=True)
class _KeyedLockEntry:
    lock: threading.RLock
    users: int = 0


class KeyedLockPool:
    """Provide per-key locks and evict them after the last user exits."""

    def __init__(self) -> None:
        self._entries: dict[Hashable, _KeyedLockEntry] = {}
        self._state_lock = threading.Lock()

    @contextlib.contextmanager
    def reserve(self, key: Hashable) -> Iterator[threading.RLock]:
        with self._state_lock:
            entry = self._entries.get(key)
            if entry is None:
                entry = _KeyedLockEntry(lock=threading.RLock())
                self._entries[key] = entry
            entry.users += 1
        try:
            yield entry.lock
        finally:
            with self._state_lock:
                entry.users -= 1
                if entry.users == 0 and self._entries.get(key) is entry:
                    self._entries.pop(key, None)

    @contextlib.contextmanager
    def acquire(
        self,
        key: Hashable,
        *,
        timeout: float | None = None,
        lock_name: str = "keyed",
    ) -> Iterator[None]:
        with self.reserve(key) as lock:
            with acquire_ordered_locks(
                [(lock_name, lock)],
                timeout=timeout,
                order=(lock_name,),
            ):
                yield

    @property
    def active_count(self) -> int:
        with self._state_lock:
            return len(self._entries)


class LockManager:
    """Fail-fast target/project lock manager with fixed acquisition order."""

    def __init__(self) -> None:
        self._target_pool = KeyedLockPool()
        self._project_pool = KeyedLockPool()

    @contextlib.contextmanager
    def acquire(
        self,
        *,
        target: str | None = None,
        project_key: str | None = None,
        timeout: float | _UsePolicy | None = USE_POLICY_TIMEOUT,
    ) -> Iterator[None]:
        locks: list[tuple[str, threading.RLock]] = []
        with ExitStack() as reservations:
            if target is not None:
                lock = reservations.enter_context(self._target_pool.reserve(target))
                locks.append(("target", lock))
            if project_key is not None:
                lock = reservations.enter_context(self._project_pool.reserve(project_key))
                locks.append(("project", lock))
            with acquire_ordered_locks(locks, timeout=timeout):
                yield

    @property
    def cached_lock_counts(self) -> dict[str, int]:
        return {
            "target": self._target_pool.active_count,
            "project": self._project_pool.active_count,
        }


__all__ = [
    "SCRIPT_BARRIER",
    "USE_POLICY_TIMEOUT",
    "KeyedLockPool",
    "LockManager",
    "ScriptBarrier",
    "acquire_ordered_locks",
]
