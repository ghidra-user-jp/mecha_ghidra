from __future__ import annotations

from typing import Any, Literal, get_args, get_origin

import pytest
from pydantic import BaseModel

from ghidra_mcp import cli
from ghidra_mcp.application.commands import DATATYPE_COMMANDS, FUNCTION_COMMANDS, MEMORY_COMMANDS, SYMBOL_COMMANDS
from ghidra_mcp.contracts.tool_spec import ExecutorKind, ToolCategoryTag, get_all_tool_specs, get_tool_spec
from ghidra_mcp.presentation.tool_dispatcher import dispatch_tool

_LIST_CORE_COMMANDS = {
    "list_functions",
    "list_segments",
    "list_imports",
    "list_exports",
    "list_namespaces",
    "list_data_items",
    "list_data_types",
    "list_strings",
    "get_data_by_label",
    "search_bytes",
    "search_symbols",
    "list_bookmarks",
}
_CORE_COMMANDS = set(FUNCTION_COMMANDS) | set(MEMORY_COMMANDS) | set(SYMBOL_COMMANDS) | set(DATATYPE_COMMANDS)


class RecordingCoreService:
    def __init__(self) -> None:
        self.calls: list[tuple[str, dict[str, Any], str]] = []

    def call(self, command: str, params: dict[str, Any], target: str):
        self.calls.append((command, dict(params), target))
        if command == "batch_read":
            return {
                "program": "/main",
                "revision": "r:0",
                "status": "ok",
                "succeeded_count": len(params["requests"]),
                "failed_count": 0,
                "not_run_count": 0,
                "items": [
                    {"id": item["id"], "tool": item["tool"], "status": "ok", "data": {}} for item in params["requests"]
                ],
            }
        if command in {"get_xrefs", "get_call_edges", "disassemble"}:
            return {"program": "/main", "revision": "r:0", "items": [], "has_more": False, "next_cursor": None}
        if command in _LIST_CORE_COMMANDS:
            return []
        if command == "decompile_function":
            return "void main(void) {}"
        if command == "get_bytes":
            return "90"
        if command in _CORE_COMMANDS:
            return {"command": command, "target": target}
        return {"command": command, "target": target}


class RecordingService:
    def __init__(self, label: str) -> None:
        self.label = label
        self.calls: list[tuple[str, tuple[Any, ...], dict[str, Any]]] = []

    def __getattr__(self, name: str):
        def _method(*args: Any, **kwargs: Any):
            self.calls.append((name, args, dict(kwargs)))
            if name in {"list_targets", "list_programs"}:
                return []
            if name == "validate_export_path":
                return args[0]
            if name == "create_project":
                project_location = args[0] if args else kwargs["project_location"]
                return {
                    "status": "ok",
                    "project_location": project_location,
                    "project_name": kwargs.get("project_name") or "sample",
                    "project_file": f"{project_location}/sample.gpr",
                    "created": True,
                    "overwritten": bool(kwargs.get("overwrite", False)),
                }
            if name in {"load_program", "import_program"}:
                return "/program"
            if name == "save_project_program":
                target = args[0]
                return {
                    "status": "ok",
                    "target": target,
                    "program": kwargs.get("domain_path") or "/program",
                    "saved": True,
                }
            if name == "create_session":
                target = args[0]
                project_location = args[1]
                return {
                    "target": target,
                    "project_location": project_location,
                    "project_name": kwargs.get("project_name"),
                    "domain_path": kwargs.get("domain_path"),
                }
            if name == "close_session":
                target = args[0]
                return {
                    "closed": True,
                    "target": target,
                    "remove_program": bool(kwargs.get("remove_program", False)),
                }
            if name == "get_project_sync_status":
                target = args[0]
                return {
                    "target": target,
                    "program": kwargs.get("domain_path") or "/main",
                    "is_versioned": True,
                    "is_checked_out": False,
                    "is_checked_out_exclusive": False,
                    "is_latest_version": True,
                    "modified_since_checkout": False,
                    "can_add_to_repository": False,
                    "can_checkout": True,
                    "can_checkin": False,
                    "can_merge": False,
                    "is_hijacked": False,
                    "version": 1,
                    "latest_version": 1,
                    "checkout_status": None,
                    "checkouts": [],
                    "shared_project_url": None,
                }
            if name == "checkout_project_program":
                target = args[0]
                return {
                    "status": "ok",
                    "target": target,
                    "program": kwargs.get("domain_path") or "/main",
                    "checked_out": True,
                    "already_checked_out": False,
                    "exclusive": bool(kwargs.get("exclusive", False)),
                }
            if name == "add_project_program_to_version_control":
                target = args[0]
                return {
                    "status": "ok",
                    "target": target,
                    "program": kwargs.get("domain_path") or "/main",
                    "is_versioned": True,
                    "version": 1,
                    "latest_version": 1,
                    "checked_out": bool(kwargs.get("keep_checked_out", False)),
                    "effective_keep_checked_out": bool(kwargs.get("keep_checked_out", False)),
                }
            if name == "commit_project_program":
                target = args[0]
                return {
                    "status": "ok",
                    "target": target,
                    "program": kwargs.get("domain_path") or "/main",
                    "new_version": 2,
                    "checked_out": bool(kwargs.get("keep_checked_out", False)),
                    "effective_keep_checked_out": bool(kwargs.get("keep_checked_out", False)),
                    "is_latest_version": True,
                }
            if name == "pull_project_program":
                target = args[0]
                return {
                    "status": "ok",
                    "target": target,
                    "program": kwargs.get("domain_path") or "/main",
                    "updated": False,
                    "merged": False,
                    "discarded_local_changes": False,
                    "followed_latest": False,
                    "reloaded": False,
                    "checked_out": False,
                    "version": 1,
                    "latest_version": 1,
                    "is_latest_version": True,
                }
            if name == "undo_checkout_project_program":
                target = args[0]
                return {
                    "status": "ok",
                    "target": target,
                    "program": kwargs.get("domain_path") or "/main",
                    "checked_out": False,
                    "version": 1,
                    "is_latest_version": True,
                }
            if name == "terminate_project_program_checkout":
                target = args[0]
                return {
                    "status": "ok",
                    "target": target,
                    "program": kwargs.get("domain_path") or "/main",
                    "checkout_id": int(kwargs.get("checkout_id", 1)),
                    "active_checkouts": [],
                }
            if name == "delete_shared_project_file":
                target = args[0]
                return {
                    "status": "ok",
                    "target": target,
                    "program": kwargs["domain_path"],
                    "domain_path": kwargs["domain_path"],
                    "deleted": True,
                    "content_type": "Program",
                    "was_versioned": True,
                    "version": 1,
                    "latest_version": 1,
                    "atomic_version_guard": False,
                }
            if name == "get_version_history":
                target = args[0]
                return {
                    "target": target,
                    "program": kwargs.get("domain_path") or "/main",
                    "current_version": 1,
                    "latest_version": 1,
                    "total_versions": 1,
                    "versions": [],
                }
            if name == "get_version_diff":
                target = args[0]
                return {
                    "target": target,
                    "program": kwargs.get("domain_path") or "/main",
                    "from_version": int(kwargs.get("from_version", 1)),
                    "to_version": int(kwargs.get("to_version", 2)),
                    "total_diff_addresses": 0,
                    "total_diff_ranges": 0,
                    "diff_types": [],
                    "ranges": [],
                    "ranges_truncated": False,
                    "details": [],
                    "details_truncated": False,
                    "warnings": None,
                }
            if name == "bsim_load_matched_executable":
                return {
                    "status": "already_loaded",
                    "target": kwargs.get("target") or "bsim_match",
                    "program": kwargs["matched_ref"].get("domain_path") or "/matched",
                    "matched_function_address": kwargs["matched_ref"].get("address"),
                    "matched_function_name": kwargs["matched_ref"].get("name"),
                    "executable_md5": kwargs["matched_ref"].get("executable_md5"),
                    "matched_ref_version": kwargs["matched_ref"].get("matched_ref_version", 1),
                }
            return {"service": self.label, "method": name}

        return _method


def _sample_for_field(name: str, annotation: Any) -> Any:
    origin = get_origin(annotation)
    if isinstance(annotation, type) and issubclass(annotation, BaseModel):
        return {
            key: _sample_for_field(key, field.annotation)
            for key, field in annotation.model_fields.items()
            if field.is_required()
        }

    if origin is Literal:
        return get_args(annotation)[0]

    if origin in {list, tuple, set}:
        inner = get_args(annotation)[0] if get_args(annotation) else Any
        if inner is str:
            return ["item"]
        inner_origin = get_origin(inner)
        if inner is dict or inner_origin is dict:
            return [{"name": "field", "type": "int"}]
        return [_sample_for_field(name, inner)]

    if origin is dict:
        return {"name": "field", "type": "int"}

    union_args = [arg for arg in get_args(annotation) if arg is not type(None)]  # noqa: E721
    if union_args:
        return _sample_for_field(name, union_args[0])

    if annotation is bool:
        return True
    if annotation is int:
        if name == "from_version":
            return 1
        if name == "to_version":
            return 2
        if name == "checkout_id":
            return 7
        return 3

    if annotation is str:
        if name in {"address", "function_address"}:
            return "0x401000"
        if name == "project_location":
            return "/tmp/sample.gpr"
        if name == "domain_path":
            return "/main"
        if name == "binary_path":
            return "/tmp/sample.exe"
        if name == "on_local_changes":
            return "abort"
        if name == "clear_mode":
            return "CLEAR_ALL_DEFAULT_CONFLICT_DATA"
        if name in {"data_type", "new_type"}:
            return "int"
        if name in {"type"}:
            return "Info"
        if name in {"bytes"}:
            return "90"
        if name in {"message", "comment"}:
            return "msg"
        return "value"

    if annotation is dict:
        return {"key": "value"}

    return "value"


def _required_raw_args(spec_name: str) -> dict[str, Any]:
    if spec_name == "batch_read":
        return {"requests": [{"id": "a", "tool": "get_function", "arguments": {"address": "0x1000"}}]}
    spec = get_tool_spec(spec_name)
    raw: dict[str, Any] = {}
    for key, field in spec.input_model.model_fields.items():
        if field.is_required():
            raw[key] = _sample_for_field(key, field.annotation)
    if spec_name == "decompile_function":
        raw["name"] = "main"
    return raw


@pytest.mark.parametrize("tool_name", sorted(get_all_tool_specs().keys()))
def test_service_registry_adapter_routes_all_tools(tool_name: str):
    spec = get_tool_spec(tool_name)
    target_name = "fw"
    raw_args = _required_raw_args(tool_name)

    core = RecordingCoreService()
    target = RecordingService("target")
    sync = RecordingService("sync")
    bsim = RecordingService("bsim")
    script = RecordingService("script")
    adapter = cli.ServiceRegistryAdapter(
        core_command_service=core,
        target_service=target,
        sync_service=sync,
        bsim_service=bsim,
        script_service=script,
    )

    dispatch_tool(tool_name, raw_args, target_name, registry=adapter)

    validated = spec.input_model.model_validate(raw_args).model_dump(exclude_none=True)

    if spec.executor_kind == ExecutorKind.CORE_COMMAND:
        assert core.calls == [(spec.command_or_method, validated, target_name)]
        assert target.calls == []
        assert sync.calls == []
        assert bsim.calls == []
        return

    expected_kwargs = {**validated, **spec.static_kwargs}

    if tool_name == "export_program":
        # A registry method that polices the output path, then runs the core command.
        assert target.calls == [("validate_export_path", (validated["output_path"],), {})]
        assert core.calls == [("export_program", validated, target_name)]
        assert sync.calls == [] and bsim.calls == []
        return

    if spec.executor_kind == ExecutorKind.REGISTRY_METHOD:
        assert core.calls == []
        services = {"target": target, "bsim": bsim, "script": script}
        if spec.category_tag == ToolCategoryTag.BSIM:
            expected_name = "bsim"
        elif spec.category_tag == ToolCategoryTag.SCRIPTS and spec.command_or_method != "close_session":
            expected_name = "script"
        else:
            expected_name = "target"
        expected_service = services.pop(expected_name)
        assert sync.calls == []
        for other_service in services.values():
            assert other_service.calls == []
        assert len(expected_service.calls) == 1
        method_name, args, kwargs = expected_service.calls[0]
        assert method_name == spec.command_or_method
        if spec.include_target:
            assert args
            assert args[0] == target_name
        else:
            assert args == ()
        for key, value in expected_kwargs.items():
            if key in kwargs:
                assert kwargs[key] == value
            else:
                assert value in args
        return

    assert spec.executor_kind == ExecutorKind.SHARED_SYNC_METHOD
    assert core.calls == []
    assert target.calls == []
    assert bsim.calls == []
    assert len(sync.calls) == 1
    method_name, args, kwargs = sync.calls[0]
    assert method_name == spec.command_or_method
    assert args
    assert args[0] == target_name
    for key, value in expected_kwargs.items():
        if key in kwargs:
            assert kwargs[key] == value
        else:
            assert value in args


def test_service_registry_adapter_create_session_requires_domain_path():
    core = RecordingCoreService()
    target = RecordingService("target")
    sync = RecordingService("sync")
    bsim = RecordingService("bsim")
    adapter = cli.ServiceRegistryAdapter(
        core_command_service=core,
        target_service=target,
        sync_service=sync,
        bsim_service=bsim,
    )

    with pytest.raises(ValueError, match="domain_path is required"):
        adapter.create_session("fw", "/tmp/sample.gpr", project_name="sample")


def test_service_registry_adapter_forwards_close_remove_flag():
    core = RecordingCoreService()
    target = RecordingService("target")
    sync = RecordingService("sync")
    bsim = RecordingService("bsim")
    adapter = cli.ServiceRegistryAdapter(
        core_command_service=core,
        target_service=target,
        sync_service=sync,
        bsim_service=bsim,
    )

    dispatch_tool("close_session_and_remove_program", {}, "fw", registry=adapter)

    assert target.calls == [("close_session", ("fw",), {"remove_program": True})]


def test_service_registry_adapter_forwards_only_supplied_shared_sync_arguments():
    core = RecordingCoreService()
    target = RecordingService("target")
    sync = RecordingService("sync")
    bsim = RecordingService("bsim")
    adapter = cli.ServiceRegistryAdapter(
        core_command_service=core,
        target_service=target,
        sync_service=sync,
        bsim_service=bsim,
    )

    dispatch_tool("get_project_sync_status", {}, "fw", registry=adapter)

    # The adapter forwards exactly what the dispatcher supplies; the service's own
    # ``domain_path=None`` default applies, so no synthetic None is injected.
    assert sync.calls == [("get_project_sync_status", ("fw",), {})]
