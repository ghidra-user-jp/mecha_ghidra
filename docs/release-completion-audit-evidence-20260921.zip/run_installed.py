from pathlib import Path
import json
import os
import subprocess
import sys

ROOT = Path('/private/tmp/mecha-final-audit-20260921')
WORK = Path(__file__).resolve().parent / sys.argv[1]
WORK.mkdir(exist_ok=True)
for name in ('home', 'settings', 'tmp', 'cache'):
    (WORK / name).mkdir(exist_ok=True)
extension = WORK / 'settings/samsepi0l-ghidra/ghidra_12.1.3_PUBLIC/Extensions/Jython'
extension.parent.mkdir(parents=True, exist_ok=True)
if not extension.exists():
    extension.symlink_to('/private/tmp/mecha-mcp22-review-ng91lgm9/settings/samsepi0l-ghidra/ghidra_12.1.3_PUBLIC/Extensions/Jython', target_is_directory=True)
label = sys.argv[1]
run = WORK
env = dict(os.environ)
env.update({
    'GHIDRA_INSTALL_DIR': '/Users/samsepi0l/ghidra/ghidra_12.1.3_PUBLIC',
    'JAVA_HOME': '/Library/Java/JavaVirtualMachines/temurin-21.jdk/Contents/Home',
    'JAVA_TOOL_OPTIONS': f'-Xmx2g -Duser.home={WORK / "home"} -Dapplication.settingsdir={WORK / "settings"} -Djava.io.tmpdir={WORK / "tmp"}',
    'XDG_CACHE_HOME': str(WORK / 'cache'),
    'PYTHONDONTWRITEBYTECODE': '1',
    'PYTHONPATH': str(ROOT / 'installed-tests'),
    'GHIDRA_RUNTIME_VALIDATION': '1',
    'GHIDRA_JYTHON_RUNTIME_VALIDATION': '1',
    'GHIDRA_BSIM_RUNTIME_VALIDATION': '0',
    'GHIDRA_RUNTIME_BINARY_PATH': '/bin/ls',
})
cmd = [str(ROOT / 'venv/bin/python'), '-m', 'pytest', '-W', 'error::mcp.MCPDeprecationWarning', '-q', '--tb=short', '-o', 'cache_dir=' + str(run/'pytest-cache'), '--junitxml=' + str(run/'result.xml'), *sys.argv[2:]]
(run/'invocation.json').write_text(json.dumps({'cmd': cmd, 'env': {k: env[k] for k in ('GHIDRA_INSTALL_DIR','JAVA_HOME','JAVA_TOOL_OPTIONS','PYTHONPATH')}}, indent=2))
print('Running', label, flush=True)
with (run/'runtime.log').open('w') as log:
    result = subprocess.run(cmd, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=900)
print((run/'runtime.log').read_text()[-20000:])
raise SystemExit(result.returncode)
