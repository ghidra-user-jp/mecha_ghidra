import json
from pathlib import Path

import pytest

from ghidra_mcp.contracts.tool_spec import get_all_tool_specs, get_checkout_required_tool_names
from ghidra_mcp.presentation.cli_runtime import create_cli_runtime
from test_runtime_readonly_commands import _start_pyghidra_if_needed

WORK = Path(__file__).parent


@pytest.fixture
def api(tmp_path):
    _start_pyghidra_if_needed()
    from ghidra_headless.handlers import core

    specs = get_all_tool_specs()
    bundle = create_cli_runtime(
        registered_specs=specs, core_accessor=lambda: core,
        checkout_required_commands=get_checkout_required_tool_names(specs),
    )
    result = bundle.runtime.tools
    try:
        result['create_project'](project_location=str(tmp_path), project_name='numeric')
        result['register_target'](target='numeric', project_location=str(tmp_path), project_name='numeric')
        yield result
    finally:
        bundle.target_service.close_all()


@pytest.mark.parametrize('base_text', ['0x1000', '4096', '0o10000'])
def test_raw_base_matches_validated_integer(api, tmp_path, base_text):
    from ghidra_headless.handlers import core_runtime

    binary = tmp_path/'tiny.bin'
    binary.write_bytes(bytes.fromhex('b8 2a 00 00 00 c3'))
    observed = {'base_address': base_text, 'expected': int(base_text, 0)}
    try:
        imported = api['import_program'](
            target='numeric', binary_path=str(binary), import_mode='raw_binary',
            language_id='x86:LE:64:default', base_address=base_text,
            entry_offset=0, analyze_imported=False,
        )
        api['load_project_program'](target='numeric', domain_path=imported['program'])
        program = core_runtime._CONTEXTS['numeric'].program
        actual = int(str(program.getMinAddress().getOffsetAsBigInteger()))
        observed['actual'] = actual
        observed['function_count'] = int(program.getFunctionManager().getFunctionCount())
        assert actual == int(base_text, 0)
    except Exception as exc:
        observed['error'] = str(exc)
        raise
    finally:
        (WORK/f'base-{base_text}.json').write_text(json.dumps(observed, indent=2))


@pytest.mark.parametrize('overlay', [False, True])
def test_raw_overlay_matches_supported_loader_options(api, tmp_path, overlay):
    from ghidra_headless.handlers import core_runtime

    binary = tmp_path/'overlay.bin'
    binary.write_bytes(bytes.fromhex('b8 2a 00 00 00 c3'))
    observed = {'overlay': overlay}
    try:
        imported = api['import_program'](
            target='numeric', binary_path=str(binary), import_mode='raw_binary',
            language_id='x86:LE:64:default', base_address='0x1000', block_name='code',
            overlay=overlay, entry_offset=0, analyze_imported=False,
        )
        observed['import_result'] = imported
        api['load_project_program'](target='numeric', domain_path=imported['program'])
        program = core_runtime._CONTEXTS['numeric'].program
        address = program.getMemory().getLoadedAndInitializedAddressSet().getMinAddress()
        function = program.getFunctionManager().getFunctionAt(address)
        observed['loaded_start'] = str(address)
        observed['loaded_space'] = str(address.getAddressSpace().getName())
        observed['function_at_start'] = function is not None
        observed['function_count'] = int(program.getFunctionManager().getFunctionCount())
        observed['external_entry_points'] = [str(a) for a in program.getSymbolTable().getExternalEntryPointIterator()]
        assert function is not None
        assert bool(program.getSymbolTable().isExternalEntryPoint(address))
        assert not overlay, 'this Ghidra version does not expose an Overlay CLI option'
    except Exception as exc:
        observed['error'] = str(exc)
        observed['domain_error'] = getattr(exc, 'domain_error', None)
        causes = []
        current = exc
        while current is not None:
            causes.append(str(current))
            current = current.__cause__
        observed['causes'] = causes
        if overlay and any('RAW_LOADER_OPTION_UNAVAILABLE: Overlay' in cause for cause in causes):
            assert observed['domain_error']['code'] == 'IMPORT_FAILED'
            return
        raise
    finally:
        (WORK/f'overlay-{overlay}.json').write_text(json.dumps(observed, indent=2))
