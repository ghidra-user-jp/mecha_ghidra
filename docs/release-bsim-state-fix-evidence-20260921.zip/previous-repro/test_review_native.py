import hashlib
import json
from pathlib import Path
import pytest
from test_runtime_resource_safety import runtime
from test_runtime_readonly_commands import _unwrap_runtime_result

TARGET='resource_safety'
OUT=Path('/private/tmp/mecha-review-next-20260921')

@pytest.mark.parametrize('invalid', ['md5', 'address', None])
@pytest.mark.parametrize('registered', [False, True])
def test_bsim_load_validation_restores_target_on_failure(runtime,tmp_path,invalid,registered):
    api=runtime
    api['close_session'](target=TARGET)
    if registered:
        api['create_project'](project_location=str(tmp_path),project_name='original')
        api['register_target'](target='candidate',project_location=str(tmp_path),project_name='original')
    before=api['list_targets']()
    digest=hashlib.md5((tmp_path/'tiny.bin').read_bytes()).hexdigest()
    ref=dict(matched_ref_version=1,executable_md5=digest if invalid != "md5" else '0'*32,executable_name='tiny.bin',project_location=str(tmp_path),project_name='sample',domain_path='/tiny.bin',address='0x1001' if invalid == 'address' else '0x1000',name='entry')
    error=None;result=None
    try:
        result=api['bsim_load_matched_executable'](matched_ref=ref,target='candidate')
    except Exception as exc:
        error=str(exc)
    after=api['list_targets']()
    (OUT/f'bsim-{invalid}-{registered}.json').write_text(json.dumps(dict(before=before,after=after,error=error,result=result),default=str,indent=2))
    if invalid is None:
        assert error is None,error
        assert any(t['target']=='candidate' and t['domain_path']=='/tiny.bin' for t in after)
    else:
        assert 'BSIM_MATCH_STALE' in error,error
        assert after==before

@pytest.mark.parametrize('overlay',[False,True])
def test_byte_search_enumerates_initialized_blocks(runtime,overlay):
    from ghidra_headless.handlers.core_runtime import _CONTEXTS
    from ghidra.util.task import TaskMonitor
    api=runtime;program=_CONTEXTS[TARGET].program
    address=program.getAddressFactory().getAddress('2000')
    tx=program.startTransaction('Review memory')
    try:
        block=program.getMemory().createInitializedBlock('review',address,3,0,TaskMonitor.DUMMY,overlay)
        program.getMemory().setBytes(block.getStart(),bytes.fromhex('aa aa aa'))
    finally:
        program.endTransaction(tx,True)
    actual=[]
    for offset in range(4):
        actual.extend(_unwrap_runtime_result(api['search_bytes'](target=TARGET,pattern='aa aa',offset=offset,limit=1)))
    expected=[str(block.getStart()),str(block.getStart().add(1))]
    (OUT/f'bytes-{overlay}.json').write_text(json.dumps(dict(expected=expected,actual=actual),indent=2))
    assert actual==expected


def test_bsim_validation_failure_keeps_previously_loaded_program(runtime,tmp_path):
    api=runtime
    before=api['list_targets']()
    ref=dict(matched_ref_version=1,executable_md5='0'*32,executable_name='tiny.bin',project_location=str(tmp_path),project_name='sample',domain_path='/tiny.bin',address='0x1000',name='entry')
    with pytest.raises(Exception,match='BSIM_MATCH_STALE'):
        api['bsim_load_matched_executable'](matched_ref=ref,target=TARGET)
    assert api['list_targets']()==before
    assert '0x2a' in _unwrap_runtime_result(api['decompile_function'](target=TARGET,address='0x1000'))
