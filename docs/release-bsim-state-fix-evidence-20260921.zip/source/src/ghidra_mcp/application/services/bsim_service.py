"""Application service for BSim MCP tools."""

from __future__ import annotations

import getpass
import math
import os
import pathlib
import re
import threading
from dataclasses import dataclass
from typing import Any, Callable, TypeVar
from urllib.parse import quote, unquote, urlsplit, urlunsplit

from ghidra_mcp.application.locks import KeyedLockPool
from ghidra_mcp.application.services.ports import BsimBackendPort
from ghidra_mcp.domain import DomainError, ErrorCode
from ghidra_mcp.domain.bsim_url_masking import mask_bsim_url, mask_bsim_urls_in_text

from .core_command_service import CoreCommandService
from .target_service import TargetService

BSIM_MATCHED_REF_VERSION = 1
_BSIM_CODE_RE = re.compile(r"^BSIM_[A-Z0-9_]+(?::|$)")
_BSIM_GENERIC_CODE_PREFIXES = (
    "BSIM_DATABASE_INIT_FAILED:",
    "BSIM_QUERY_FAILED:",
    "BSIM_CLI_FAILED:",
    # InsertRequest reports "<name> is already ingested" through this wrapper;
    # strip it so the keyword rule below can promote it to BSIM_ALREADY_REGISTERED.
    "BSIM_INSERT_FAILED:",
)
_BSIM_CATEGORY_TYPE_RE = re.compile(r"^[A-Za-z0-9 ._:/()]+$")
_BSIM_MD5_RE = re.compile(r"^[0-9a-fA-F]{32}$")
_BSIM_SUPPORTED_URL_SCHEMES = frozenset({"postgresql", "elastic", "https", "file"})
_MAX_BSIM_LIST_LIMIT = 10_000
_MAX_BSIM_MATCHES_PER_FUNCTION = 1_000
_MAX_BSIM_QUERY_RESULTS = 10_000
_MAX_BSIM_QUERY_FUNCTIONS = 1_000
_MAX_BSIM_APPLY_FUNCTIONS = 10_000
_MAX_BSIM_MIN_FUNCTION_SIZE = 1_000_000
_REMOTE_CACHE_SLUG_RE = re.compile(r"[^A-Za-z0-9_.-]+")
_T = TypeVar("_T")


@dataclass(frozen=True)
class BsimConfig:
    bsim_url: str | None = None
    bsim_password: str | None = None
    bsim_password_env: str | None = None
    ghidra_install_dir: str | None = None
    # Directory for local caches of Ghidra Server repositories referenced by
    # ghidra:// matched_refs (``--bsim-remote-cache-dir``).  None disables
    # loading remote matches.
    remote_cache_dir: str | None = None


@dataclass(frozen=True)
class _MatchedRef:
    raw: dict[str, object]
    executable_md5: str
    executable_name: str
    domain_path: str
    address: str
    name: str
    project_location: str | None
    project_name: str | None
    repository: str | None
    ghidra_url: str | None


def _default_bsim_backend() -> BsimBackendPort:
    """Resolve the Ghidra-backed adapter when the composition root injected none.

    Kept as a late import so this application module has no module-level
    dependency on infrastructure; ``create_cli_runtime`` injects the adapter
    explicitly and tests inject fakes.
    """

    from ghidra_mcp.infrastructure.bsim import BsimJavaBackend

    return BsimJavaBackend()


def _bsim_message(code: str, message: str) -> str:
    text = str(message).strip() or "unknown error"
    if _BSIM_CODE_RE.match(text):
        return text
    return f"{code}: {text}"


def _classify_bsim_message(message: str, *, default_code: str = "BSIM_OPERATION_FAILED") -> str:
    text = str(message).strip() or "unknown error"
    has_specific_code = _BSIM_CODE_RE.match(text) and not text.startswith(_BSIM_GENERIC_CODE_PREFIXES)
    if has_specific_code:
        return text
    # Backend/headless errors arrive wrapped in a generic prefix (e.g.
    # "BSIM_QUERY_FAILED: ..."). Strip that wrapper so the keyword rules below can
    # promote it to a more specific code; otherwise _bsim_message would see the
    # existing prefix and return the text unchanged, defeating reclassification.
    for prefix in _BSIM_GENERIC_CODE_PREFIXES:
        if text.startswith(prefix):
            text = text[len(prefix) :].strip() or "unknown error"
            break
    lower = text.lower()
    if "function not found" in lower:
        return _bsim_message("BSIM_FUNCTION_NOT_FOUND", text)
    if "already ingested" in lower:
        return _bsim_message("BSIM_ALREADY_REGISTERED", text)
    if "password" in lower or "authentication" in lower or "auth failed" in lower:
        return _bsim_message("BSIM_AUTHENTICATION_FAILED", text)
    if (
        "refused" in lower
        or "could not connect" in lower
        or "connection to" in lower
        or "timed out" in lower
        or "timeout" in lower
        or "unknown host" in lower
        or "no route to host" in lower
        or "unreachable" in lower
    ):
        return _bsim_message("BSIM_DATABASE_UNREACHABLE", text)
    return _bsim_message(default_code, text)


def _classified_bsim_error(
    exc: Exception,
    *,
    default_code: str = "BSIM_OPERATION_FAILED",
) -> Exception:
    message = _classify_bsim_message(
        mask_bsim_urls_in_text(str(exc)),
        default_code=default_code,
    )
    if message == "BSIM_FUNCTION_NOT_FOUND" or message.startswith("BSIM_FUNCTION_NOT_FOUND:"):
        return LookupError(message)
    if message == "BSIM_EXECUTABLE_NOT_FOUND" or message.startswith("BSIM_EXECUTABLE_NOT_FOUND:"):
        return LookupError(message)
    if isinstance(exc, ValueError):
        return ValueError(message)
    return RuntimeError(message)


def _mask_bsim_payload_credentials(value: Any) -> Any:
    if isinstance(value, str):
        return mask_bsim_urls_in_text(value)
    if isinstance(value, dict):
        return {key: _mask_bsim_payload_credentials(item) for key, item in value.items()}
    if isinstance(value, list):
        return [_mask_bsim_payload_credentials(item) for item in value]
    if isinstance(value, tuple):
        return tuple(_mask_bsim_payload_credentials(item) for item in value)
    return value


def _validate_executable_category_name(category: object) -> str:
    text = str(category).strip()
    if not text:
        raise ValueError("BSIM_EXECUTABLE_CATEGORY_INVALID: category must not be empty")
    if _BSIM_CATEGORY_TYPE_RE.fullmatch(text) is None:
        raise ValueError("BSIM_EXECUTABLE_CATEGORY_INVALID: category contains unsupported characters")
    return text


def _iter_category_values(value: object) -> list[object]:
    if isinstance(value, (list, tuple, set, frozenset)):
        return list(value)
    return [value]


def _normalize_metadata_categories(categories: dict[str, object]) -> dict[str, list[str]]:
    if not isinstance(categories, dict) or not categories:
        raise ValueError("BSIM_EXECUTABLE_METADATA_INVALID: categories must be a non-empty object")

    normalized: dict[str, list[str]] = {}
    for key, raw_value in categories.items():
        category = _validate_executable_category_name(key)
        values: list[str] = []
        seen: set[str] = set()
        if raw_value is not None:
            for item in _iter_category_values(raw_value):
                if item is None:
                    continue
                text = str(item).strip()
                if not text or text in seen:
                    continue
                values.append(text)
                seen.add(text)
        normalized[category] = values
    return normalized


def _resolve_config_password(config: BsimConfig) -> str | None:
    env_name = (config.bsim_password_env or "").strip()
    has_password = config.bsim_password is not None
    if has_password and env_name:
        raise ValueError(
            "BSIM_PASSWORD_CONFIG_INVALID: --bsim-password and --bsim-password-env cannot be used together"
        )
    if has_password:
        if config.bsim_password == "":
            raise ValueError("BSIM_PASSWORD_CONFIG_INVALID: --bsim-password is empty")
        return config.bsim_password
    if not env_name:
        return None
    value = os.environ.get(env_name)
    if value is None:
        raise ValueError(f"BSIM_PASSWORD_CONFIG_INVALID: Environment variable '{env_name}' is not set")
    if value == "":
        raise ValueError(f"BSIM_PASSWORD_CONFIG_INVALID: Environment variable '{env_name}' is empty")
    return value


def _hostport(parts) -> str:
    hostname = parts.hostname
    if not hostname:
        raise ValueError("BSIM_URL_INVALID: --bsim-password requires bsim_url with a hostname")
    host = hostname
    if ":" in host and not host.startswith("["):
        host = f"[{host}]"
    if parts.port is not None:
        host = f"{host}:{parts.port}"
    return host


def _bsim_url_with_password(bsim_url: str, password: str | None) -> str:
    if password is None:
        return bsim_url
    parts = urlsplit(bsim_url)
    if not parts.scheme or not parts.netloc:
        # file:/local databases take no network credentials; leave them as-is.
        return bsim_url
    if parts.password is not None:
        raise ValueError(
            "BSIM_PASSWORD_CONFIG_INVALID: bsim_url already contains a password; "
            "use either bsim_url credentials or --bsim-password"
        )

    username = unquote(parts.username or "") or getpass.getuser()
    userinfo = f"{quote(username, safe='')}:{quote(password, safe='')}"
    return urlunsplit((parts.scheme, f"{userinfo}@{_hostport(parts)}", parts.path, parts.query, parts.fragment))


def _validate_bsim_url(bsim_url: str) -> str:
    try:
        parts = urlsplit(bsim_url)
    except ValueError:
        parts = None
    if parts is None:
        # urlsplit's error can quote the original netloc, including its userinfo.
        raise ValueError("BSIM_URL_INVALID: unable to parse BSim URL") from None
    scheme = parts.scheme.lower()
    if not scheme:
        raise ValueError(
            "BSIM_URL_INVALID: bsim_url requires a scheme (supported: postgresql://, elastic://, https://, file:)"
        )
    if scheme not in _BSIM_SUPPORTED_URL_SCHEMES:
        supported = ", ".join(sorted(_BSIM_SUPPORTED_URL_SCHEMES))
        raise ValueError(f"BSIM_URL_INVALID: unsupported BSim URL scheme '{parts.scheme}' (supported: {supported})")
    if scheme in {"postgresql", "elastic", "https"} and not parts.netloc:
        raise ValueError(f"BSIM_URL_INVALID: {scheme} BSim URL requires a host")
    if scheme in {"postgresql", "elastic", "https"}:
        try:
            _ = parts.port
        except ValueError:
            invalid_port = True
        else:
            invalid_port = False
        if invalid_port:
            raise ValueError(f"BSIM_URL_INVALID: {scheme} BSim URL has an invalid port") from None
        path = parts.path.strip("/")
        if not path:
            raise ValueError(f"BSIM_URL_INVALID: {scheme} BSim URL requires a database name")
        if "/" in path:
            raise ValueError(f"BSIM_URL_INVALID: {scheme} BSim URL database name must be one path element")
    if scheme == "file":
        path = parts.path
        normalized_path = path.replace("\\", "/")
        if parts.netloc:
            raise ValueError("BSIM_URL_INVALID: remote file BSim URL is not supported")
        if not path.strip("/"):
            raise ValueError("BSIM_URL_INVALID: file BSim URL requires a database path")
        if any(char in path for char in "';\""):
            raise ValueError("BSIM_URL_INVALID: file BSim URL contains an unsupported path character")
        if normalized_path.endswith("/") or not (
            normalized_path.startswith("/") or re.match(r"^[A-Za-z]:/", normalized_path)
        ):
            raise ValueError("BSIM_URL_INVALID: file BSim URL requires an absolute database path")
    return bsim_url


def _validate_float_range(value: float, *, name: str, minimum: float, maximum: float | None = None) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"BSIM_PARAMETER_INVALID: {name} must be a number") from exc
    if not math.isfinite(number):
        raise ValueError(f"BSIM_PARAMETER_INVALID: {name} must be finite")
    if number < minimum:
        raise ValueError(f"BSIM_PARAMETER_INVALID: {name} must be >= {minimum:g}")
    if maximum is not None and number > maximum:
        raise ValueError(f"BSIM_PARAMETER_INVALID: {name} must be <= {maximum:g}")
    return number


def _validate_positive_int(value: int, *, name: str, maximum: int) -> int:
    try:
        number = int(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"BSIM_PARAMETER_INVALID: {name} must be an integer") from exc
    if number < 1:
        raise ValueError(f"BSIM_PARAMETER_INVALID: {name} must be >= 1")
    if number > maximum:
        raise ValueError(f"BSIM_PARAMETER_INVALID: {name} must be <= {maximum}")
    return number


def _validate_non_negative_int(value: int, *, name: str, maximum: int) -> int:
    try:
        number = int(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"BSIM_PARAMETER_INVALID: {name} must be an integer") from exc
    if number < 0:
        raise ValueError(f"BSIM_PARAMETER_INVALID: {name} must be >= 0")
    if number > maximum:
        raise ValueError(f"BSIM_PARAMETER_INVALID: {name} must be <= {maximum}")
    return number


def _validate_function_selectors(
    addresses: list[str] | None,
    function_names: list[str] | None,
) -> tuple[list[str], list[str]]:
    def _clean(values: list[str] | None, *, name: str) -> list[str]:
        if values is None:
            return []
        if isinstance(values, (str, bytes)) or not isinstance(values, (list, tuple)):
            raise ValueError(f"BSIM_PARAMETER_INVALID: {name} must be a list of strings")
        cleaned: list[str] = []
        for item in values:
            text = BsimService._text(item)
            if text is not None and text not in cleaned:
                cleaned.append(text)
        return cleaned

    cleaned_addresses = _clean(addresses, name="addresses")
    cleaned_names = _clean(function_names, name="function_names")
    if len(cleaned_addresses) + len(cleaned_names) > _MAX_BSIM_QUERY_FUNCTIONS:
        raise ValueError(f"BSIM_PARAMETER_INVALID: at most {_MAX_BSIM_QUERY_FUNCTIONS} functions per call")
    return cleaned_addresses, cleaned_names


def _validate_query_parameters(
    *,
    similarity_threshold: float,
    significance_threshold: float,
    matches_per_function: int,
    max_results: int,
) -> tuple[float, float, int, int]:
    return (
        _validate_float_range(
            similarity_threshold,
            name="similarity_threshold",
            minimum=0.0,
            maximum=1.0,
        ),
        _validate_float_range(significance_threshold, name="significance_threshold", minimum=0.0),
        _validate_positive_int(
            matches_per_function,
            name="matches_per_function",
            maximum=_MAX_BSIM_MATCHES_PER_FUNCTION,
        ),
        _validate_positive_int(max_results, name="max_results", maximum=_MAX_BSIM_QUERY_RESULTS),
    )


def _normalize_domain_path(value: str | None) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    if not text:
        return None
    if not text.startswith("/"):
        text = "/" + text
    return pathlib.PurePosixPath(text).as_posix()


def _project_identity(project_location: str, project_name: str | None = None) -> tuple[str, str]:
    path = pathlib.Path(project_location).expanduser()
    if path.suffix.lower() == ".gpr":
        return (str(path.parent.resolve()), path.stem)
    if project_name:
        return (str(path.resolve()), str(project_name))
    raise ValueError("project_name is required when project_location is not a .gpr file")


def _remote_repository_parts(url: str) -> tuple[str, int, str] | None:
    """Return (host, port, repository) for a remote ghidra:// URL, else None."""
    try:
        parts = urlsplit(str(url))
        port = parts.port
    except ValueError:
        return None
    if parts.scheme != "ghidra" or not parts.hostname:
        return None
    segments = [segment for segment in parts.path.split("/") if segment]
    if not segments:
        return None
    return parts.hostname.lower(), int(port or 13100), segments[0]


def _remote_cache_project(cache_dir: str, url: str) -> tuple[str, str, str]:
    """Derive (project_location, project_name, repository_url) for a remote match cache.

    One cache per server repository: ``<cache_dir>/<host>_<port>_<repo>/<same>.gpr``.
    """
    remote = _remote_repository_parts(url)
    if remote is None:
        raise ValueError(f"BSIM_INVALID_MATCHED_REF: unsupported BSim ghidra URL: {url}")
    host, port, repository = remote
    slug = _REMOTE_CACHE_SLUG_RE.sub("_", f"{host}_{port}_{repository}").strip("_") or "repository"
    location = str(pathlib.Path(cache_dir).expanduser() / slug)
    return location, slug, f"ghidra://{host}:{port}/{repository}"


def _project_from_ghidra_url(url: str | None, *, remote_cache_dir: str | None = None) -> tuple[str, str | None]:
    if not url:
        raise ValueError("BSIM_INVALID_MATCHED_REF: matched_ref requires repository or ghidra_url")
    parts = urlsplit(str(url))
    if parts.scheme != "ghidra":
        raise ValueError(f"BSIM_INVALID_MATCHED_REF: unsupported BSim ghidra URL: {url}")
    if parts.netloc:
        if remote_cache_dir:
            location, name, _ = _remote_cache_project(remote_cache_dir, url)
            return (location, name)
        raise ValueError(
            "BSIM_REMOTE_PROJECT_LOAD_UNSUPPORTED: matched_ref points to a remote ghidra:// repository; "
            "start the server with --bsim-remote-cache-dir to let it create a local cache, or provide "
            "project_location/project_name in matched_ref"
        )
    path = pathlib.Path(parts.path).expanduser()
    if path.suffix.lower() == ".gpr":
        return (str(path), None)
    return (str(path) + ".gpr", None)


def _default_match_target(md5: str | None, executable_name: str | None) -> str:
    if md5:
        return "bsim_" + re.sub(r"[^0-9a-fA-F]", "", md5)[:12].lower()
    base = re.sub(r"[^A-Za-z0-9_]+", "_", executable_name or "match").strip("_")
    return "bsim_" + (base or "match")


def _validate_matched_ref(matched_ref: dict[str, object]) -> _MatchedRef:
    if not isinstance(matched_ref, dict):
        raise ValueError("BSIM_INVALID_MATCHED_REF: matched_ref must be an object")

    raw_version = matched_ref.get("matched_ref_version")
    if isinstance(raw_version, bool):
        version = None
    else:
        try:
            number = float(raw_version)
        except (TypeError, ValueError):
            version = None
        else:
            version = int(number) if number.is_integer() else None
    if version != BSIM_MATCHED_REF_VERSION:
        raise ValueError(
            f"BSIM_INVALID_MATCHED_REF: matched_ref.matched_ref_version must be {BSIM_MATCHED_REF_VERSION}"
        )

    def _field(name: str) -> str | None:
        return BsimService._text(matched_ref.get(name))

    executable_md5 = _field("executable_md5")
    executable_name = _field("executable_name")
    domain_path = _normalize_domain_path(_field("domain_path") or _field("path"))
    address = _field("address")
    name = _field("name")
    project_location = _field("project_location")
    project_name = _field("project_name")
    repository = _field("repository")
    ghidra_url = _field("ghidra_url")

    missing = [
        key
        for key, value in (
            ("executable_md5", executable_md5),
            ("executable_name", executable_name),
            ("domain_path", domain_path),
            ("address", address),
            ("name", name),
        )
        if value is None
    ]
    if missing:
        raise ValueError("BSIM_INVALID_MATCHED_REF: missing required keys: " + ", ".join(missing))
    if not project_location and not repository and not ghidra_url:
        raise ValueError("BSIM_INVALID_MATCHED_REF: matched_ref requires project_location, repository, or ghidra_url")

    return _MatchedRef(
        raw=matched_ref,
        executable_md5=executable_md5,
        executable_name=executable_name,
        domain_path=domain_path,
        address=address,
        name=name,
        project_location=project_location,
        project_name=project_name,
        repository=repository,
        ghidra_url=ghidra_url,
    )


class BsimService:
    def __init__(
        self,
        *,
        core_command_service: CoreCommandService,
        target_service: TargetService,
        config: BsimConfig | None = None,
        java_backend: BsimBackendPort | None = None,
    ) -> None:
        self._core_command_service = core_command_service
        self._target_service = target_service
        self._config = config or BsimConfig()
        self._java_backend = java_backend if java_backend is not None else _default_bsim_backend()
        self._loaded_match_index: dict[str, str] = {}
        self._matched_load_locks = KeyedLockPool()
        self._matched_load_state_lock = threading.Lock()

    def _resolve_bsim_url(self, bsim_url: str | None = None) -> str:
        override = (bsim_url or "").strip()
        configured = (self._config.bsim_url or "").strip()
        resolved = override or configured
        if not resolved:
            raise ValueError("BSIM_URL_REQUIRED: set --bsim-url or pass bsim_url")
        _validate_bsim_url(resolved)
        # The server-configured password belongs to the configured --bsim-url only.
        # A per-call bsim_url that targets a different database must carry its own
        # credentials; never forward the configured password to an arbitrary host.
        if not override or override == configured:
            password = _resolve_config_password(self._config)
            if password is not None:
                resolved = _bsim_url_with_password(resolved, password)
        return resolved

    @staticmethod
    def _mask_response_url(payload: dict[str, Any], bsim_url: str) -> dict[str, Any]:
        result = _mask_bsim_payload_credentials(dict(payload))
        result["bsim_url"] = mask_bsim_url(bsim_url)
        return result

    @staticmethod
    def _add_query_provenance(
        payload: dict[str, Any],
        *,
        scope: str,
        target: str,
        masked_bsim_url: str | None,
        similarity_threshold: float,
        significance_threshold: float,
        matches_per_function: int,
        max_results: int,
        address: str | None = None,
        function_name: str | None = None,
        addresses: list[str] | None = None,
        function_names: list[str] | None = None,
        exclude_self: bool | None = None,
        min_function_size: int | None = None,
    ) -> dict[str, Any]:
        result = dict(payload)
        query: dict[str, Any] = {
            "scope": scope,
            "target": target,
            "program": result.get("program"),
            "bsim_url": masked_bsim_url,
            "similarity_threshold": float(similarity_threshold),
            "significance_threshold": float(significance_threshold),
            "matches_per_function": int(matches_per_function),
            "max_results": int(max_results),
        }
        if address is not None:
            query["address"] = address
        if function_name is not None:
            query["function_name"] = function_name
        if addresses:
            query["addresses"] = list(addresses)
        if function_names:
            query["function_names"] = list(function_names)
        if exclude_self is not None:
            query["exclude_self"] = bool(exclude_self)
        if min_function_size is not None:
            query["min_function_size"] = int(min_function_size)
        result["query"] = query
        return result

    @staticmethod
    def _call_bsim(operation: Callable[[], _T], *, default_code: str = "BSIM_OPERATION_FAILED") -> _T:
        public_error: Exception | None = None
        try:
            return operation()
        except DomainError as exc:
            # Structured runtime errors (SESSION_NOT_FOUND, PROJECT_LOCKED, ...) already
            # carry a code/retryable payload; let them through so the presentation layer
            # renders the same envelope it does for every other tool. Core-command BSim
            # failures, however, reach us pre-wrapped by RuntimeBackend._invoke as the
            # generic OPERATION_FAILED with the headless message intact; without
            # reclassification the same database outage would surface as
            # BSIM_DATABASE_UNREACHABLE via the Java-backend path but as an opaque
            # OPERATION_FAILED via the core-command path.
            if exc.code is ErrorCode.OPERATION_FAILED:
                public_error = _classified_bsim_error(exc, default_code=default_code)
            else:
                # Preserve the structured contract while preventing credentials embedded
                # in a runtime message, hint, or details value from escaping this boundary.
                public_error = DomainError(
                    code=exc.code,
                    message=mask_bsim_urls_in_text(exc.message),
                    hint=(None if exc.hint is None else mask_bsim_urls_in_text(exc.hint)),
                    retryable=exc.retryable,
                    details=(None if exc.details is None else _mask_bsim_payload_credentials(exc.details)),
                )
        except Exception as exc:
            public_error = _classified_bsim_error(exc, default_code=default_code)

        # Raising after leaving the except suite prevents Python from attaching the raw
        # backend error as __context__; that object may itself contain credential URLs.
        if public_error is None:  # pragma: no cover - operation either returned or raised
            raise AssertionError("BSim operation failed without an exception")
        raise public_error from None

    def _ghidra_install_dir(self) -> str | None:
        configured = self._text(self._config.ghidra_install_dir) or self._text(os.environ.get("GHIDRA_INSTALL_DIR"))
        if configured is None:
            return None
        if configured.startswith("/") and "\\" not in configured:
            return pathlib.PurePosixPath(configured).as_posix()
        return str(pathlib.Path(configured).expanduser())

    def get_database_status(self, *, bsim_url: str | None = None) -> dict[str, Any]:
        resolved = self._resolve_bsim_url(bsim_url)
        result = self._call_bsim(
            lambda: self._java_backend.get_database_status(resolved),
            default_code="BSIM_DATABASE_STATUS_FAILED",
        )
        masked = self._mask_response_url(result, resolved)
        masked["ghidra_install_dir"] = self._ghidra_install_dir()
        masked["ghidra_version"] = self._call_bsim(
            self._java_backend.get_ghidra_version,
            default_code="BSIM_GHIDRA_VERSION_FAILED",
        )
        return masked

    def get_bsim_database_status(self, *, bsim_url: str | None = None) -> dict[str, Any]:
        return self.get_database_status(bsim_url=bsim_url)

    def list_categories(self, *, bsim_url: str | None = None) -> dict[str, Any]:
        resolved = self._resolve_bsim_url(bsim_url)
        result = self._call_bsim(
            lambda: self._java_backend.list_categories(resolved),
            default_code="BSIM_LIST_CATEGORIES_FAILED",
        )
        return self._mask_response_url(result, resolved)

    def add_executable_category(
        self,
        *,
        category: str,
        bsim_url: str | None = None,
    ) -> dict[str, Any]:
        resolved = self._resolve_bsim_url(bsim_url)
        normalized_category = _validate_executable_category_name(category)
        result = self._call_bsim(
            lambda: self._java_backend.add_executable_category(
                resolved,
                category=normalized_category,
            ),
            default_code="BSIM_ADD_EXECUTABLE_CATEGORY_FAILED",
        )
        return self._mask_response_url(result, resolved)

    def bsim_add_executable_category(
        self,
        *,
        category: str,
        bsim_url: str | None = None,
    ) -> dict[str, Any]:
        return self.add_executable_category(category=category, bsim_url=bsim_url)

    def list_executables(
        self,
        *,
        bsim_url: str | None = None,
        name: str | None = None,
        md5: str | None = None,
        arch: str | None = None,
        compiler: str | None = None,
        limit: int = 100,
    ) -> dict[str, Any]:
        resolved = self._resolve_bsim_url(bsim_url)
        limit = _validate_positive_int(limit, name="limit", maximum=_MAX_BSIM_LIST_LIMIT)
        result = self._call_bsim(
            lambda: self._java_backend.list_executables(
                resolved,
                name=name,
                md5=md5,
                arch=arch,
                compiler=compiler,
                limit=limit,
            ),
            default_code="BSIM_LIST_EXECUTABLES_FAILED",
        )
        return self._mask_response_url(result, resolved)

    def list_bsim_executables(
        self,
        *,
        bsim_url: str | None = None,
        name: str | None = None,
        md5: str | None = None,
        arch: str | None = None,
        compiler: str | None = None,
        limit: int = 100,
    ) -> dict[str, Any]:
        return self.list_executables(
            bsim_url=bsim_url,
            name=name,
            md5=md5,
            arch=arch,
            compiler=compiler,
            limit=limit,
        )

    def get_executable(
        self,
        *,
        bsim_url: str | None = None,
        md5: str | None = None,
        name: str | None = None,
    ) -> dict[str, Any]:
        resolved = self._resolve_bsim_url(bsim_url)
        result = self._call_bsim(
            lambda: self._java_backend.get_executable(resolved, md5=md5, name=name),
            default_code="BSIM_GET_EXECUTABLE_FAILED",
        )
        return self._mask_response_url(result, resolved)

    def get_bsim_executable(
        self,
        *,
        bsim_url: str | None = None,
        md5: str | None = None,
        name: str | None = None,
    ) -> dict[str, Any]:
        return self.get_executable(bsim_url=bsim_url, md5=md5, name=name)

    def update_executable_metadata(
        self,
        *,
        categories: dict[str, object],
        bsim_url: str | None = None,
        md5: str | None = None,
        name: str | None = None,
    ) -> dict[str, Any]:
        resolved = self._resolve_bsim_url(bsim_url)
        normalized_categories = _normalize_metadata_categories(categories)
        normalized_md5 = self._text(md5)
        normalized_name = self._text(name)
        if normalized_md5 is None and normalized_name is None:
            raise ValueError("BSIM_EXECUTABLE_LOOKUP_REQUIRED: md5 or name is required")
        if normalized_md5 is not None and _BSIM_MD5_RE.fullmatch(normalized_md5) is None:
            raise ValueError("BSIM_EXECUTABLE_LOOKUP_INVALID: md5 must be a 32-character hexadecimal string")
        result = self._call_bsim(
            lambda: self._java_backend.update_executable_metadata(
                resolved,
                categories=normalized_categories,
                md5=normalized_md5,
                name=normalized_name,
            ),
            default_code="BSIM_UPDATE_EXECUTABLE_METADATA_FAILED",
        )
        return self._mask_response_url(result, resolved)

    def bsim_update_executable_metadata(
        self,
        *,
        categories: dict[str, object],
        bsim_url: str | None = None,
        md5: str | None = None,
        name: str | None = None,
    ) -> dict[str, Any]:
        return self.update_executable_metadata(
            categories=categories,
            bsim_url=bsim_url,
            md5=md5,
            name=name,
        )

    def bsim_query(
        self, target: str, *, scope: str, addresses=None, function_names=None, min_function_size=0, **kwargs
    ):
        if scope == "functions":
            if min_function_size:
                raise ValueError("min_function_size is only available for program scope")
            return self.query_function(target, addresses=addresses, function_names=function_names, **kwargs)
        if scope == "program":
            if addresses is not None or function_names is not None:
                raise ValueError("program scope does not accept function selectors")
            return self.query_target(target, min_function_size=min_function_size, **kwargs)
        raise ValueError("scope must be program or functions")

    def query_target(
        self,
        target: str,
        *,
        bsim_url: str | None = None,
        similarity_threshold: float = 0.7,
        significance_threshold: float = 0.0,
        matches_per_function: int = 10,
        max_results: int = 500,
        exclude_self: bool = True,
        min_function_size: int = 0,
    ) -> dict[str, Any]:
        (
            similarity_threshold,
            significance_threshold,
            matches_per_function,
            max_results,
        ) = _validate_query_parameters(
            similarity_threshold=similarity_threshold,
            significance_threshold=significance_threshold,
            matches_per_function=matches_per_function,
            max_results=max_results,
        )
        min_function_size = _validate_non_negative_int(
            min_function_size, name="min_function_size", maximum=_MAX_BSIM_MIN_FUNCTION_SIZE
        )
        resolved = self._resolve_bsim_url(bsim_url)
        result = self._call_bsim(
            lambda: self._core_command_service.call(
                "bsim_query_target",
                {
                    "bsim_url": resolved,
                    "query_target": target,
                    "similarity_threshold": similarity_threshold,
                    "significance_threshold": significance_threshold,
                    "matches_per_function": matches_per_function,
                    "max_results": max_results,
                    "exclude_self": bool(exclude_self),
                    "min_function_size": min_function_size,
                },
                target,
            ),
            default_code="BSIM_QUERY_FAILED",
        )
        masked = self._mask_response_url(result, resolved)
        return self._add_query_provenance(
            masked,
            scope="target",
            target=target,
            masked_bsim_url=masked.get("bsim_url"),
            similarity_threshold=similarity_threshold,
            significance_threshold=significance_threshold,
            matches_per_function=matches_per_function,
            max_results=max_results,
            exclude_self=bool(exclude_self),
            min_function_size=min_function_size,
        )

    def query_function(
        self,
        target: str,
        *,
        bsim_url: str | None = None,
        address: str | None = None,
        function_name: str | None = None,
        addresses: list[str] | None = None,
        function_names: list[str] | None = None,
        similarity_threshold: float = 0.7,
        significance_threshold: float = 0.0,
        matches_per_function: int = 10,
        max_results: int = 100,
        exclude_self: bool = True,
    ) -> dict[str, Any]:
        (
            similarity_threshold,
            significance_threshold,
            matches_per_function,
            max_results,
        ) = _validate_query_parameters(
            similarity_threshold=similarity_threshold,
            significance_threshold=significance_threshold,
            matches_per_function=matches_per_function,
            max_results=max_results,
        )
        addresses, function_names = _validate_function_selectors(addresses, function_names)
        address = self._text(address)
        function_name = self._text(function_name)
        if address is None and function_name is None and not addresses and not function_names:
            raise ValueError("BSIM_PARAMETER_INVALID: address, function_name, addresses, or function_names is required")
        resolved = self._resolve_bsim_url(bsim_url)
        result = self._call_bsim(
            lambda: self._core_command_service.call(
                "bsim_query_function",
                {
                    "bsim_url": resolved,
                    "query_target": target,
                    "address": address,
                    "function_name": function_name,
                    "addresses": addresses,
                    "function_names": function_names,
                    "similarity_threshold": similarity_threshold,
                    "significance_threshold": significance_threshold,
                    "matches_per_function": matches_per_function,
                    "max_results": max_results,
                    "exclude_self": bool(exclude_self),
                },
                target,
            ),
            default_code="BSIM_QUERY_FAILED",
        )
        masked = self._mask_response_url(result, resolved)
        return self._add_query_provenance(
            masked,
            scope="function",
            target=target,
            masked_bsim_url=masked.get("bsim_url"),
            address=address,
            function_name=function_name,
            addresses=addresses or None,
            function_names=function_names or None,
            similarity_threshold=similarity_threshold,
            significance_threshold=significance_threshold,
            matches_per_function=matches_per_function,
            max_results=max_results,
            exclude_self=bool(exclude_self),
        )

    def apply_matches(
        self,
        target: str,
        *,
        bsim_url: str | None = None,
        similarity_threshold: float = 0.9,
        significance_threshold: float = 0.0,
        matches_per_function: int = 5,
        max_functions: int = 500,
        only_default_names: bool = True,
        exclude_self: bool = True,
        min_function_size: int = 0,
        dry_run: bool = False,
        addresses: list[str] | None = None,
        function_names: list[str] | None = None,
    ) -> dict[str, Any]:
        (
            similarity_threshold,
            significance_threshold,
            matches_per_function,
            _max_results,
        ) = _validate_query_parameters(
            similarity_threshold=similarity_threshold,
            significance_threshold=significance_threshold,
            matches_per_function=matches_per_function,
            max_results=1,
        )
        max_functions = _validate_positive_int(max_functions, name="max_functions", maximum=_MAX_BSIM_APPLY_FUNCTIONS)
        min_function_size = _validate_non_negative_int(
            min_function_size, name="min_function_size", maximum=_MAX_BSIM_MIN_FUNCTION_SIZE
        )
        addresses, function_names = _validate_function_selectors(addresses, function_names)
        resolved = self._resolve_bsim_url(bsim_url)
        result = self._call_bsim(
            lambda: self._core_command_service.call(
                "bsim_apply_matches",
                {
                    "bsim_url": resolved,
                    "query_target": target,
                    "similarity_threshold": similarity_threshold,
                    "significance_threshold": significance_threshold,
                    "matches_per_function": matches_per_function,
                    "max_functions": max_functions,
                    "only_default_names": bool(only_default_names),
                    "exclude_self": bool(exclude_self),
                    "min_function_size": min_function_size,
                    "dry_run": bool(dry_run),
                    "addresses": addresses,
                    "function_names": function_names,
                },
                target,
            ),
            default_code="BSIM_APPLY_MATCHES_FAILED",
        )
        masked = self._mask_response_url(result, resolved)
        return self._add_query_provenance(
            masked,
            scope="apply",
            target=target,
            masked_bsim_url=masked.get("bsim_url"),
            addresses=addresses or None,
            function_names=function_names or None,
            similarity_threshold=similarity_threshold,
            significance_threshold=significance_threshold,
            matches_per_function=matches_per_function,
            max_results=max_functions,
            exclude_self=bool(exclude_self),
            min_function_size=min_function_size,
        )

    def bsim_apply_matches(self, target: str, **kwargs: Any) -> dict[str, Any]:
        return self.apply_matches(target, **kwargs)

    def update_target_signatures(self, target: str, *, bsim_url: str | None = None) -> dict[str, Any]:
        resolved = self._resolve_bsim_url(bsim_url)
        result = self._call_bsim(
            lambda: self._core_command_service.call(
                "bsim_update_target_signatures",
                {"bsim_url": resolved, "query_target": target},
                target,
            ),
            default_code="BSIM_UPDATE_FAILED",
        )
        return self._mask_response_url(result, resolved)

    def bsim_update_target_signatures(self, target: str, *, bsim_url: str | None = None) -> dict[str, Any]:
        return self.update_target_signatures(target, bsim_url=bsim_url)

    def delete_executable(
        self,
        *,
        confirm: str,
        bsim_url: str | None = None,
        md5: str | None = None,
        name: str | None = None,
    ) -> dict[str, Any]:
        resolved = self._resolve_bsim_url(bsim_url)
        normalized_md5 = self._text(md5)
        normalized_name = self._text(name)
        if normalized_md5 is None and normalized_name is None:
            raise ValueError("BSIM_EXECUTABLE_LOOKUP_REQUIRED: md5 or name is required")
        if normalized_md5 is not None and _BSIM_MD5_RE.fullmatch(normalized_md5) is None:
            raise ValueError("BSIM_EXECUTABLE_LOOKUP_INVALID: md5 must be a 32-character hexadecimal string")
        # Deleting drops every function record of the executable; the caller must
        # repeat the identifier it is acting on (md5 when given, else the name).
        expected = normalized_md5.lower() if normalized_md5 is not None else normalized_name
        confirmation = self._text(confirm)
        if confirmation is None or (
            confirmation.lower() != expected if normalized_md5 is not None else confirmation != expected
        ):
            raise ValueError(
                "BSIM_DELETE_CONFIRMATION_MISMATCH: confirm must exactly match the md5 "
                "(or the name when md5 is omitted) of the executable to delete"
            )
        result = self._call_bsim(
            lambda: self._java_backend.delete_executable(resolved, md5=normalized_md5, name=normalized_name),
            default_code="BSIM_DELETE_EXECUTABLE_FAILED",
        )
        return self._mask_response_url(result, resolved)

    def bsim_delete_executable(
        self,
        *,
        confirm: str,
        bsim_url: str | None = None,
        md5: str | None = None,
        name: str | None = None,
    ) -> dict[str, Any]:
        return self.delete_executable(confirm=confirm, bsim_url=bsim_url, md5=md5, name=name)

    def _ensure_categories_configured(self, categories: dict[str, object], *, resolved_url: str) -> None:
        """Reject category names the database does not define.

        GenSignatures only ingests Program Information options whose names match a
        configured (case-sensitive) category, so an unconfigured or miscased name
        would be stored on the program and silently dropped at registration.
        """
        if not isinstance(categories, dict) or not categories:
            raise ValueError("BSIM_TARGET_METADATA_INVALID: categories must be a non-empty object")
        configured = self._call_bsim(
            lambda: self._java_backend.list_categories(resolved_url),
            default_code="BSIM_LIST_CATEGORIES_FAILED",
        )
        configured_names = {str(item) for item in (configured.get("items") or [])}
        requested: list[str] = []
        for key in categories:
            text = str(key).strip()
            if text and text not in requested:
                requested.append(text)
        unknown = sorted(name for name in requested if name not in configured_names)
        if unknown:
            raise ValueError(
                "BSIM_EXECUTABLE_CATEGORY_NOT_CONFIGURED: "
                + ", ".join(unknown)
                + "; call bsim_add_executable_category first"
            )

    def register_target(
        self,
        target: str,
        *,
        bsim_url: str | None = None,
        categories: dict[str, object] | None = None,
    ) -> dict[str, Any]:
        resolved = self._resolve_bsim_url(bsim_url)
        params: dict[str, Any] = {"bsim_url": resolved, "query_target": target}
        if categories:
            self._ensure_categories_configured(categories, resolved_url=resolved)
            params["categories"] = dict(categories)
        result = self._call_bsim(
            lambda: self._core_command_service.call("bsim_register_target", params, target),
            default_code="BSIM_REGISTER_FAILED",
        )
        return self._mask_response_url(result, resolved)

    def bsim_register_target(
        self,
        target: str,
        *,
        bsim_url: str | None = None,
        categories: dict[str, object] | None = None,
    ) -> dict[str, Any]:
        return self.register_target(target, bsim_url=bsim_url, categories=categories)

    def load_matched_executable(
        self,
        *,
        matched_ref: dict[str, object],
        target: str | None = None,
    ) -> dict[str, Any]:
        ref = _validate_matched_ref(matched_ref)
        explicit_target = bool((target or "").strip())
        requested_target = (target or "").strip() or _default_match_target(
            ref.executable_md5,
            ref.executable_name,
        )
        load_key = self._matched_load_key(
            matched_ref=ref.raw,
            executable_md5=ref.executable_md5,
            domain_path=ref.domain_path,
            requested_target=requested_target,
        )
        with self._matched_load_locks.acquire(load_key, lock_name="bsim_load"):
            return self._load_matched_executable_once(
                ref=ref,
                requested_target=requested_target,
                explicit_target=explicit_target,
            )

    def _load_matched_executable_once(
        self,
        *,
        ref: _MatchedRef,
        requested_target: str,
        explicit_target: bool,
    ) -> dict[str, Any]:
        executable_md5 = ref.executable_md5
        domain_path = ref.domain_path
        existing = self._find_loaded_match_target(
            executable_md5=executable_md5,
            matched_ref=ref.raw,
            domain_path=domain_path,
            requested_target=requested_target,
            allow_domain_only_requested_target=(explicit_target and self._is_remote_matched_ref(ref.raw)),
        )
        if existing is not None:
            self._validate_loaded_match(existing["target"], ref)
            return {
                "status": "already_loaded",
                "target": existing["target"],
                "program": existing["program"],
                "matched_function_address": ref.address,
                "matched_function_name": ref.name,
                "executable_md5": executable_md5,
                "matched_ref_version": BSIM_MATCHED_REF_VERSION,
            }

        project_location = ref.project_location
        project_name = ref.project_name
        if not project_location:
            repository_url = ref.repository or ref.ghidra_url
            project_location, project_name = _project_from_ghidra_url(
                repository_url,
                remote_cache_dir=self._config.remote_cache_dir,
            )
            if self._is_remote_matched_ref(ref.raw):
                # The local cache is what Ghidra calls a shared project: the
                # repository's files appear in it without a copy, and the server
                # authentication configured at start-up is reused on open.
                _, _, normalized_repository_url = _remote_cache_project(
                    str(self._config.remote_cache_dir),
                    str(repository_url),
                )
                self._target_service.create_repository_cache_project(
                    project_location,
                    project_name=project_name,
                    repository_url=normalized_repository_url,
                )

        created = self._target_service.create_session(
            requested_target,
            project_location,
            project_name=project_name,
            domain_path=domain_path,
            validate=lambda: self._validate_loaded_match(requested_target, ref),
        )
        self._remember_loaded_match(
            target=requested_target,
            executable_md5=executable_md5,
            matched_ref=ref.raw,
            project_location=created.get("project_location") or project_location,
            project_name=created.get("project_name") or project_name,
            domain_path=domain_path,
        )
        return {
            "status": "loaded",
            "target": requested_target,
            "program": created.get("domain_path") or domain_path,
            "matched_function_address": ref.address,
            "matched_function_name": ref.name,
            "executable_md5": executable_md5,
            "matched_ref_version": BSIM_MATCHED_REF_VERSION,
        }

    def _validate_loaded_match(self, target: str, ref: _MatchedRef) -> None:
        # The core gateway holds the target/project locks for this entire check.
        # Do not cache a claimed MD5 before inspecting the actual loaded Program.
        self._core_command_service.call(
            "bsim_validate_match",
            {"executable_md5": ref.executable_md5, "domain_path": ref.domain_path, "address": ref.address},
            target,
        )

    def _matched_load_key(
        self,
        *,
        matched_ref: dict[str, object],
        executable_md5: str | None,
        domain_path: str,
        requested_target: str,
    ) -> str:
        identity = self._matched_ref_project_identity(matched_ref)
        if identity is not None:
            return f"program:{identity[0]}::{identity[1]}::{domain_path}"
        repository = self._text(matched_ref.get("repository")) or self._text(matched_ref.get("ghidra_url"))
        if repository:
            return f"url:{repository}::{domain_path}"
        if executable_md5:
            return f"md5:{executable_md5.lower()}"
        return f"target:{requested_target}::{domain_path}"

    def bsim_load_matched_executable(
        self,
        *,
        matched_ref: dict[str, object],
        target: str | None = None,
    ) -> dict[str, Any]:
        return self.load_matched_executable(matched_ref=matched_ref, target=target)

    @staticmethod
    def _text(value: object | None) -> str | None:
        if value is None:
            return None
        text = str(value).strip()
        return text or None

    def _remember_loaded_match(
        self,
        *,
        target: str,
        executable_md5: str | None,
        matched_ref: dict[str, object],
        project_location: str,
        project_name: str | None,
        domain_path: str,
    ) -> None:
        identity = _project_identity(project_location, project_name)
        repository = self._text(matched_ref.get("repository")) or self._text(matched_ref.get("ghidra_url"))
        with self._matched_load_state_lock:
            if executable_md5:
                self._loaded_match_index[f"md5:{executable_md5.lower()}"] = target
            self._loaded_match_index[f"program:{identity[0]}::{identity[1]}::{domain_path}"] = target
            if repository:
                self._loaded_match_index[f"url:{repository}::{domain_path}"] = target

    def _matched_ref_project_identity(self, matched_ref: dict[str, object]) -> tuple[str, str] | None:
        project_location = self._text(matched_ref.get("project_location"))
        project_name = self._text(matched_ref.get("project_name"))
        repository = self._text(matched_ref.get("repository")) or self._text(matched_ref.get("ghidra_url"))
        if not project_location and repository:
            try:
                project_location, project_name = _project_from_ghidra_url(
                    repository,
                    remote_cache_dir=self._config.remote_cache_dir,
                )
            except ValueError:
                return None
        if not project_location:
            return None
        try:
            return _project_identity(project_location, project_name)
        except ValueError:
            return None

    def _is_remote_matched_ref(self, matched_ref: dict[str, object]) -> bool:
        if self._text(matched_ref.get("project_location")) is not None:
            return False
        repository = self._text(matched_ref.get("repository")) or self._text(matched_ref.get("ghidra_url"))
        if repository is None:
            return False
        try:
            parts = urlsplit(repository)
        except ValueError:
            return False
        return parts.scheme == "ghidra" and bool(parts.netloc)

    def _target_matches_ref(
        self,
        item: dict[str, object],
        *,
        domain_path: str,
        expected_identity: tuple[str, str] | None,
    ) -> bool:
        item_domain = _normalize_domain_path(self._text(item.get("domain_path")))
        if item_domain != domain_path:
            return False
        if expected_identity is None:
            # This is safe only when the caller explicitly names the manually loaded
            # target. The caller prevents this weaker match from scanning other targets.
            return True
        item_project_location = self._text(item.get("project_location"))
        if not item_project_location:
            return False
        try:
            identity = _project_identity(
                item_project_location,
                self._text(item.get("project_name")),
            )
        except Exception:
            return False
        return identity == expected_identity

    def _find_loaded_match_target(
        self,
        *,
        executable_md5: str | None,
        matched_ref: dict[str, object],
        domain_path: str,
        requested_target: str,
        allow_domain_only_requested_target: bool,
    ) -> dict[str, str] | None:
        candidates: list[str] = []
        seen_candidates: set[str] = set()

        def _add_candidate(candidate: str | None) -> None:
            if candidate and candidate not in seen_candidates:
                candidates.append(candidate)
                seen_candidates.add(candidate)

        expected_identity = self._matched_ref_project_identity(matched_ref)
        with self._matched_load_state_lock:
            loaded_match_index = dict(self._loaded_match_index)
        _add_candidate(requested_target)
        if executable_md5:
            indexed = loaded_match_index.get(f"md5:{executable_md5.lower()}")
            _add_candidate(indexed)
        repository = self._text(matched_ref.get("repository")) or self._text(matched_ref.get("ghidra_url"))
        if repository:
            indexed = loaded_match_index.get(f"url:{repository}::{domain_path}")
            _add_candidate(indexed)
        if expected_identity is not None:
            indexed = loaded_match_index.get(f"program:{expected_identity[0]}::{expected_identity[1]}::{domain_path}")
            _add_candidate(indexed)

        targets = self._target_service.list_targets()
        by_name = {str(item.get("target")): item for item in targets if item.get("target") is not None}
        if expected_identity is None:
            # A remote ghidra:// reference cannot be tied to a local project. Preserve
            # the documented manual-load retry by checking an explicitly supplied target,
            # but never attach to an arbitrary target merely because its domain path is
            # the same.
            if not allow_domain_only_requested_target:
                return None
            info = by_name.get(requested_target)
            if info is not None and self._target_matches_ref(
                info,
                domain_path=domain_path,
                expected_identity=None,
            ):
                return {"target": requested_target, "program": domain_path}
            return None

        for candidate in candidates:
            info = by_name.get(candidate)
            if info is None:
                continue
            if self._target_matches_ref(info, domain_path=domain_path, expected_identity=expected_identity):
                return {"target": candidate, "program": domain_path}

        for item in targets:
            if self._target_matches_ref(item, domain_path=domain_path, expected_identity=expected_identity):
                return {"target": str(item["target"]), "program": domain_path}
        return None


__all__ = ["BsimConfig", "BsimService"]
