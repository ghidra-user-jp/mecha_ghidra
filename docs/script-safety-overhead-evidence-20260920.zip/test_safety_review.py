"""Observations of current behavior and isolated alternatives; no production edits."""
import json
import statistics
import time
from pathlib import Path

import jpype
import pytest

from ghidra_mcp import cli
from test_runtime_script_commands import _nested_script_project, _run, _plate, _start_pyghidra_if_needed

WORK = Path(__file__).parent


def save(name, value):
    (WORK / (name + '.json')).write_text(json.dumps(value, indent=2) + '\n')
    print(name, value)


@pytest.mark.parametrize('runtime', ['PyGhidra', 'Java'])
def test_manifest_rejection_is_stricter_than_native_provider(tmp_path, runtime):
    filename = 'ManifestScript.py' if runtime == 'PyGhidra' else 'ManifestScript.java'
    source = ('# @runtime PyGhidra\nprintln("MANIFEST_SCRIPT_OK")\n' if runtime == 'PyGhidra' else
              'import ghidra.app.script.GhidraScript;\npublic class ManifestScript extends GhidraScript {\n'
              'public void run() { println("MANIFEST_SCRIPT_OK"); }\n}\n')
    manifest = ('Manifest-Version: 1.0\nBundle-ManifestVersion: 2\n'
                'Bundle-SymbolicName: mecha.review.manifest\nBundle-Version: 1.0.0\n'
                'Import-Package: ghidra.app.script\n\n')
    with _nested_script_project(tmp_path, {filename: source, 'META-INF/MANIFEST.MF': manifest}) as (target, address):
        service = cli._script_service
        assert cli.list_scripts()['total'] == 0
        with pytest.raises(Exception, match='SCRIPT_NOT_FOUND'):
            _run(target, script_id='t:' + filename)
        root = service.snapshot_base / 't'
        # Enter the ordinary runtime adapter after catalog resolution to check
        # whether the native provider actually rejects this operator-owned root.
        result = service._runtime.run_script(target, request={
            'script_id': 't:' + filename, 'script_path': str(root / filename),
            'runtime': runtime, 'snapshot_roots': [str(root)], 'inline': False,
            'timeout_seconds': 10,
        })
        assert result['status'] == 'ok'
        assert 'MANIFEST_SCRIPT_OK' in result['stdout']['text']
        save('manifest-' + runtime, {'catalog_total':0, 'native_status':result['status'],
                                    'stdout':result['stdout'], 'transaction_outcome':result['transaction_outcome']})


def test_noop_disposes_a_healthy_decompiler(tmp_path):
    from ghidra_headless.handlers.core_runtime import _CONTEXTS
    with _nested_script_project(tmp_path, {}) as (target, address):
        functions = cli.list_functions(target=target, offset=0, limit=1)
        selector = {'target':target, 'name':functions[0]['name']}
        cli.decompile_function(**selector)
        ctx = _CONTEXTS[target]
        before_interface = ctx._decompiler
        assert before_interface is not None
        observations = []
        for _ in range(3):
            begin = time.perf_counter()
            cli.decompile_function(**selector)
            warm_ms = (time.perf_counter() - begin) * 1000
            result = _run(target, source='# @runtime PyGhidra\nprintln("READ_ONLY_NOOP")\n')
            disposed = ctx._decompiler is None
            assert disposed
            assert result['transaction_outcome'] == 'unchanged'
            begin = time.perf_counter()
            cli.decompile_function(**selector)
            after_ms = (time.perf_counter() - begin) * 1000
            observations.append({'warm_ms':warm_ms, 'after_noop_ms':after_ms,
                                 'disposed':disposed, 'transaction_outcome':result['transaction_outcome'],
                                 'revision_before':result['revision_before'], 'revision_after':result['revision']})
        save('decompiler', observations)


def test_normal_analysis_after_script_is_not_quarantined(tmp_path):
    from ghidra_headless.handlers.core_runtime import _CONTEXTS
    with _nested_script_project(tmp_path, {}) as (target, address):
        _run(target, source='# @runtime PyGhidra\npass\n')
        result = cli.analyze_program(target=target, force=True)
        state = _CONTEXTS[target].execution_invalid
        save('analysis-after-script', {'analysis':result, 'quarantine':state})
        assert state is None
        cli.apply_edits(target=target, edits=[{'kind':'set_comment','address':address,'comment':'still usable','comment_type':'plate'}])
        assert _plate(target,address) == 'still usable'


def measure(function, count):
    for _ in range(10):
        function()
    samples=[]
    for _ in range(5):
        begin=time.perf_counter()
        for _ in range(count):
            function()
        samples.append((time.perf_counter()-begin)*1000/count)
    return {'median_ms':statistics.median(samples),'samples_ms':samples,'iterations_per_sample':count}


def test_thread_id_collection_cost():
    _start_pyghidra_if_needed()
    from ghidra_headless.scripts.execution import snapshot_threads
    management=jpype.JClass('java.lang.management.ManagementFactory').getThreadMXBean()
    def ids_only():
        return {int(value) for value in management.getAllThreadIds()}
    current=int(jpype.JClass('java.lang.Thread').currentThread().threadId())
    assert current in snapshot_threads()['java']
    assert current in ids_only()
    save('thread-enumeration', {'threads':len(ids_only()), 'current':measure(snapshot_threads,100),
                                'ids_only':measure(ids_only,100)})


def test_capture_full_buffer_copy_cost():
    _start_pyghidra_if_needed()
    from ghidra_headless.scripts.capture import BoundedCapture
    capture=BoundedCapture(65536)
    channel=capture._channel
    buffer=jpype.JClass('java.nio.ByteBuffer').wrap(jpype.JArray(jpype.JByte)(b'A'*8192))
    for _ in range(8):
        buffer.clear()
        channel.write(buffer)
    before=channel.snapshot()[0]
    def current():
        buffer.clear()
        return channel.write(buffer)
    def discard_without_copy():
        buffer.clear()
        remaining=int(buffer.remaining())
        with channel._lock:
            assert len(channel._buffer) == channel._limit
            buffer.position(buffer.limit())
            channel._dropped += remaining
        return remaining
    current_result=measure(current,1000)
    candidate_result=measure(discard_without_copy,1000)
    after,dropped=channel.snapshot()
    assert before == after
    assert dropped == (10 + 5*1000)*8192*2
    save('capture', {'chunk_bytes':8192, 'retained_bytes':len(after),'dropped_bytes':dropped,
                     'current':current_result, 'discard_without_copy':candidate_result})
