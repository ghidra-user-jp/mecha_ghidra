import json
from pathlib import Path

import pytest

from ghidra_mcp.contracts.tool_spec import get_all_tool_specs, get_checkout_required_tool_names
from ghidra_mcp.presentation.cli_runtime import create_cli_runtime
from test_runtime_readonly_commands import _start_pyghidra_if_needed

WORK = Path(__file__).parent


@pytest.mark.parametrize('bits,base,valid', [(32,0x1000,True),(32,1<<32,False),(64,1<<64,False),(64,0xffff800000001000,True)])
def test_import_does_not_replace_out_of_range_base_with_zero(tmp_path, bits, base, valid):
    _start_pyghidra_if_needed()
    from ghidra_headless.handlers import core, core_runtime
    specs=get_all_tool_specs()
    bundle=create_cli_runtime(registered_specs=specs, core_accessor=lambda: core,
                             checkout_required_commands=get_checkout_required_tool_names(specs))
    api=bundle.runtime.tools
    observed={'bits':bits,'base':hex(base),'valid':valid}
    try:
        api['create_project'](project_location=str(tmp_path),project_name='range')
        api['register_target'](target='range',project_location=str(tmp_path),project_name='range')
        binary=tmp_path/'tiny.bin'
        binary.write_bytes(bytes.fromhex('b8 2a 00 00 00 c3'))
        try:
            imported=api['import_program'](target='range',binary_path=str(binary),import_mode='raw_binary',
                                          language_id=f'x86:LE:{bits}:default',base_address=hex(base),
                                          analyze_imported=False)
        except Exception as exc:
            observed['error']=str(exc)
            observed['domain_error']=getattr(exc,'domain_error',None)
            if valid: raise
            return
        observed['result']=imported
        api['load_project_program'](target='range',domain_path=imported['program'])
        program=core_runtime._CONTEXTS['range'].program
        actual=int(str(program.getMinAddress().getOffsetAsBigInteger()))
        observed['actual']=hex(actual)
        assert valid, 'out-of-range input was accepted'
        assert actual==base
    finally:
        (WORK/f'base-{bits}-{base:x}.json').write_text(json.dumps(observed,indent=2))
        bundle.target_service.close_all()
