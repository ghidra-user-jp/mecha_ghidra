import asyncio
import json
from pathlib import Path

import pytest
from mcp import Client

from ghidra_mcp.contracts.tool_spec import get_tool_spec
from ghidra_mcp.presentation.config import ToolPresentationConfig
from ghidra_mcp.presentation.mcp_server import create_mcp_server
from ghidra_mcp.presentation.tool_dispatcher import dispatch_tool

WORK = Path(__file__).parent


@pytest.mark.parametrize('threshold', [1024, 12000])
@pytest.mark.parametrize('count_mode', ['bounded', 'none'])
def test_search_returns_a_match_and_continuation_within_budget(threshold, count_mode):
    pattern = 'a' * 400
    text = ('prefix ' + pattern + ' suffix\n') * 40

    class Registry:
        def call(self, command, params, target):
            assert command == 'decompile_function'
            return text

    registry = Registry()
    server = create_mcp_server(
        specs={'decompile_function': get_tool_spec('decompile_function')},
        registry_provider=lambda: registry,
        dispatcher_provider=lambda: dispatch_tool,
        presentation_config=ToolPresentationConfig(
            large_result_threshold_chars=threshold, large_result_preview_chars=0
        ),
    )

    async def check():
        async with Client(server.mcp) as client:
            result = await client.call_tool('decompile_function', {'target': 'test', 'name': 'main'})
            assert not result.is_error
            result_id = result.structured_content['result_id']
            found = await client.call_tool('search_result', {
                'result_id': result_id, 'pattern': pattern, 'max_matches': 1,
                'context_chars': 0, 'count_mode': count_mode,
            })
            assert not found.is_error
            payload = found.structured_content['result']
            (WORK/f'search-{threshold}-{count_mode}.json').write_text(json.dumps(payload, indent=2))
            assert payload['match_count'] > 0
            assert payload['matches_shown'] == 1, 'response fitting discarded every match'
            assert payload['matches'][0]['offset_chars'] == len('prefix ')
            assert payload['next_cursor'], 'more matches exist; continuation must remain possible'

    asyncio.run(check())
