import pytest
from prototype import public_raw_import
from test_raw import assert_closed
from test_runtime_resource_safety import runtime
from test_runtime_resource_safety import test_runtime_reloading_and_closing_reclaims_native_decompilers


@pytest.fixture(autouse=True)
def substitute_public_raw_import(monkeypatch):
    from ghidra_headless.session.project_handle import ProjectHandle
    captures = []
    analyses = []
    real_analyze = ProjectHandle._analyze_program_locked
    def analyze(self, program, flat_api):
        analyses.append(str(program.getName()))
        return real_analyze(self, program, flat_api)
    def replacement(self, path, *, program_dir, program_name, language_id, compiler_spec_id,
                    base_address, file_offset, length, block_name, overlay):
        assert program_dir == '/'
        options = {k:v for k,v in {'Base Address':base_address,'File Offset':file_offset,
                                  'Length':length,'Block Name':block_name}.items() if v is not None}
        if overlay:
            options['Overlay'] = 'true'
        evidence = {}
        try:
            return public_raw_import(self.project,path,program_name,language=language_id,
                                     compiler=compiler_spec_id,options=options,evidence=evidence)
        finally:
            captures.append(evidence)
    monkeypatch.setattr(ProjectHandle,'_import_program_raw_locked',replacement)
    monkeypatch.setattr(ProjectHandle,'_analyze_program_locked',analyze)
    yield captures, analyses
    for evidence in captures:
        assert_closed(evidence)


@pytest.mark.parametrize('analyze_imported',[False,True])
def test_raw_tool_boundary_entry_offset_and_analysis(runtime,tmp_path,substitute_public_raw_import,analyze_imported):
    from ghidra_headless.handlers import core_runtime
    captures,analyses = substitute_public_raw_import
    # The imported fixture validates the alternate entry_address route with analysis enabled.
    assert '0x2a' in runtime['decompile_function'](target='resource_safety',address='0x1000')
    binary = tmp_path / 'offset.bin'
    payload = bytes.fromhex('90 b8 2a 00 00 00 c3')
    binary.write_bytes(b'padding012345678' + payload)
    before = len(analyses)
    imported = runtime['import_program'](target='resource_safety',binary_path=str(binary),import_mode='raw_binary',
        language_id='x86:LE:64:default',compiler_spec_id='windows',base_address='0x2000',file_offset=16,
        length=len(payload),block_name='public_block',entry_offset=1,analyze_imported=analyze_imported)
    assert len(analyses) == before + int(analyze_imported)
    runtime['load_project_program'](target='resource_safety',domain_path=imported['program'])
    program = core_runtime._CONTEXTS['resource_safety'].program
    entry = program.getAddressFactory().getAddress('2001')
    assert program.getSymbolTable().isExternalEntryPoint(entry)
    assert program.getFunctionManager().getFunctionAt(entry) is not None
    assert '0x2a' in runtime['decompile_function'](target='resource_safety',address='0x2001')
    assert captures[-1]['base'] == 0x2000 and captures[-1]['block_name'] == 'public_block'
    assert captures[-1]['data'] == payload.hex()
