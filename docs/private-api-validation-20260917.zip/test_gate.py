import importlib
from importlib.metadata import version
import pytest
import prototype
from test_runtime_script_commands import _nested_script_project, _run, _plate, PYGHIDRA_FAIL
from ghidra_mcp import cli

JAVA_PARENT = '''import ghidra.app.script.GhidraScript;
public class BlockedParent extends GhidraScript {
    public void run() throws Exception { runScript("Child.py"); }
}
'''


@pytest.fixture
def gate_project(tmp_path):
    sources = {"Child.py": PYGHIDRA_FAIL, "BlockedParent.java": JAVA_PARENT,
               "ParentPy.py": '# @runtime PyGhidra\nrunScript("Child.py")\n',
               "ParentJy.py": '# @runtime Jython\nrunScript("Child.py")\n'}
    with _nested_script_project(tmp_path, sources) as (target, address):
        plugin = importlib.import_module("pyghidra.internal.plugin.plugin")
        from pyghidra.script import PyGhidraScript
        previous_class = plugin.PyGhidraScript
        previous_gate = dict(prototype.gate)
        plugin.PyGhidraScript = PyGhidraScript
        prototype.gate.clear()
        prototype.gate.update(ready=False, mode="test_reset")
        try:
            yield target, address, plugin, PyGhidraScript
        finally:
            plugin.PyGhidraScript = previous_class
            prototype.gate.clear()
            prototype.gate.update(previous_gate)
            cli._script_service._runtime_overrides.clear()


def test_probe_before_patch_and_conditional_application(gate_project, monkeypatch):
    target, address, plugin, original = gate_project
    before = prototype.probe(cli._script_service.snapshot_base / "before")
    assert plugin.PyGhidraScript is original
    from ghidra_headless.scripts import pyghidra_compat
    calls = []
    apply = pyghidra_compat.ensure_script_runner_binding
    def counted():
        calls.append(1)
        return apply()
    state = prototype.prepare(cli._script_service, apply_fn=counted)
    if version("pyghidra") == "3.1.0":
        assert before["result"] == "swallowed"
        assert state["mode"] == "compat"
        assert calls == [1]
    else:
        assert before["result"] == "propagated"
        assert state["mode"] == "native"
        assert calls == []
        assert plugin.PyGhidraScript is original
    assert prototype.probe(cli._script_service.snapshot_base / "after")["result"] == "propagated"
    print("CONDITIONAL_GATE", state)


def test_characterize_pyghidra_only_disable_does_not_block_java_children(gate_project):
    assert version("pyghidra") == "3.1.0", "Run this old-version negative control only on 3.1.0"
    target, address, plugin, original = gate_project
    assert plugin.PyGhidraScript is original
    cli._script_service.mark_runtime_unavailable("PyGhidra", "negative_control")
    prototype.gate.update(ready=True, mode="negative_control_without_global_block")
    result = _run(target, script_id="t:BlockedParent.java")
    assert result["transaction_outcome"] == "committed"
    assert _plate(target,address) == "PYFAIL"
    print("CURRENT_PYGHIDRA_ONLY_DISABLE_INSUFFICIENT", "Java parent executed a failing Python child and committed its edit")


@pytest.mark.parametrize("fault", ["unknown_version", "unexpected_probe", "probe_raises", "apply_raises", "apply_no_effect", "apply_partial_raises"])
def test_failed_preparation_blocks_all_roots_and_nested_calls(gate_project, fault):
    target, address, plugin, original = gate_project
    from ghidra_headless.scripts import pyghidra_compat
    before = _plate(target, address)
    kwargs = {}
    calls = []
    def counted_probe(directory):
        calls.append("probe")
        if fault == "probe_raises":
            raise RuntimeError("injected probe failure")
        if fault == "unexpected_probe":
            return {"result": "unexpected"}
        # Force a failed native probe for decision branches even with fixed upstream.
        return {"result": "swallowed"}
    def apply():
        calls.append("apply")
        if fault == "apply_partial_raises":
            pyghidra_compat.ensure_script_runner_binding()
            raise RuntimeError("injected failure after class replacement")
        if fault == "apply_raises":
            raise RuntimeError("injected apply failure")
    state = prototype.prepare(cli._script_service, declared_version="99.0" if fault == "unknown_version" else "3.1.0",
                              probe_fn=counted_probe, apply_fn=apply)
    assert state["ready"] is False and state["mode"] == "disabled"
    assert plugin.PyGhidraScript is original
    if fault in {"unknown_version", "unexpected_probe", "probe_raises"}:
        assert "apply" not in calls
    for script_id in ["t:Child.py", "t:BlockedParent.java", "t:ParentPy.py", "t:ParentJy.py"]:
        with pytest.raises(Exception, match="SCRIPT_RUNTIME_UNAVAILABLE"):
            _run(target, script_id=script_id)
    for runtime in ["PyGhidra", "Jython"]:
        with pytest.raises(Exception, match="SCRIPT_RUNTIME_UNAVAILABLE"):
            _run(target, source=f'# @runtime {runtime}\nrunScript("Child.py")\n')
    with pytest.raises(Exception, match="SCRIPT_RUNTIME_UNAVAILABLE"):
        _run(target, source=JAVA_PARENT)
    # Also exercise the shared execution boundary without catalog filtering.
    from ghidra_headless.scripts.execution import run_script_with_transaction
    with pytest.raises(Exception, match="SCRIPT_RUNTIME_UNAVAILABLE"):
        run_script_with_transaction()
    assert _plate(target, address) == before
    assert cli.get_program_info(target=target)["min_address"] == address
    print("FAILED_GATE", fault, state, "direct + inline + nested roots rejected; normal reads still work")
