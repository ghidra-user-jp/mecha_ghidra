import json
from pathlib import Path
import prototype


def pytest_configure(config):
    prototype.install()
    from importlib.metadata import version
    if version("pyghidra") == "3.2.0":
        from ghidra_headless.scripts import pyghidra_compat
        def forbidden():
            raise AssertionError("Mecha compatibility shim must never run with the upstream candidate")
        pyghidra_compat.ensure_script_runner_binding = forbidden
        pyghidra_compat._build_subclass = forbidden


def pytest_sessionfinish(session, exitstatus):
    import os
    import pyghidra
    import importlib.metadata
    from ghidra_headless.scripts import pyghidra_compat
    path = Path(os.environ["VALIDATION_RESULT_DIR"])
    path.mkdir(parents=True, exist_ok=True)
    state = {
        "exitstatus": exitstatus, "pyghidra_version": pyghidra.__version__,
        "metadata_version": importlib.metadata.version("pyghidra"),
        "nested_jython_lifecycle_prototype": os.environ.get("VALIDATION_NESTED_JYTHON") == "1",
        "pyghidra_path": pyghidra.__file__, "gate_events": prototype.events,
        "compat_state": pyghidra_compat.compat_state(),
    }
    (path / "runtime-state.json").write_text(json.dumps(state, indent=2))
