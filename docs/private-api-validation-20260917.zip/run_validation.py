from pathlib import Path
import os
import json
import shutil
import subprocess
import sys

ROOT = Path('/Users/samsepi0l/ghidra/mecha_ghidra')
WORK = Path(__file__).resolve().parent
mode = sys.argv[1]
run = WORK / mode
run.mkdir(exist_ok=True)
for name in ['home', 'tmp', 'cache', 'settings']:
    (run / name).mkdir(exist_ok=True)
extension = run / 'settings/samsepi0l-ghidra/ghidra_12.1.2_PUBLIC/Extensions/Jython'
if not extension.exists():
    shutil.copytree('/private/tmp/mecha-jython-validation-20260916/settings/samsepi0l-ghidra/ghidra_12.1.2_PUBLIC/Extensions/Jython', extension)
env = dict(os.environ)
env.update(json.loads(Path('/private/tmp/mecha-jython-validation-20260916/environment.json').read_text()))
env.update({
    'GHIDRA_JYTHON_RUNTIME_VALIDATION': '1',
    'JAVA_TOOL_OPTIONS': f'-Xmx2g -Duser.home={run / "home"} -Dapplication.settingsdir={run / "settings"} -Djava.io.tmpdir={run / "tmp"}',
    'XDG_CACHE_HOME': str(run / 'cache'),
    'PYTHONDONTWRITEBYTECODE': '1',
    'PYTHONPATH': os.pathsep.join(([str(WORK / 'upstream-site')] if mode.startswith('upstream') else []) +
                               [str(WORK), str(ROOT / 'src'), str(ROOT / 'tests')]),
    'VALIDATION_RESULT_DIR': str(run),
    'VALIDATION_NESTED_JYTHON': '1' if mode.endswith('-final') else '0',
})
(run / 'environment.json').write_text(json.dumps({k:env[k] for k in ['GHIDRA_INSTALL_DIR','JAVA_HOME','JAVA_TOOL_OPTIONS','PYTHONPATH','GHIDRA_JYTHON_RUNTIME_VALIDATION']}, indent=2))
args = sys.argv[2:] or [str(WORK / 'test_raw.py'), str(WORK / 'test_gate.py'), str(WORK / 'test_cross_runtime.py'), str(ROOT / 'tests/test_runtime_script_commands.py')]
cmd = [str(ROOT / '.venv/bin/python'), '-m', 'pytest', '-p', 'validation_plugin', '-o', 'cache_dir=' + str(run / 'pytest-cache'), '-s', '-q', '--tb=short', '--junitxml=' + str(run / 'result.xml'), *args]
print('Running', mode, flush=True)
with (run / 'runtime.log').open('w') as log:
    result = subprocess.run(cmd, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=600)
print((run / 'runtime.log').read_text()[-12000:])
raise SystemExit(result.returncode)
