"""Disposable migration prototype. No production files are modified."""
from pathlib import Path
from importlib.metadata import version
import uuid
import jpype

gate = {"ready": False, "mode": "uninitialized"}
events = []


def probe(directory):
    """Exercise the actual provider without first installing the Mecha shim."""
    from ghidra_headless.scripts import providers
    from ghidra_headless.scripts.capture import BoundedCapture
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    token = "propagation_probe_" + uuid.uuid4().hex
    path = directory / (token + ".py")
    path.write_text('# @runtime PyGhidra\nraise RuntimeError("' + token + '")\n')
    providers.ensure_bundle_host()
    out, err = BoundedCapture(4096), BoundedCapture(4096)
    try:
        provider = providers.provider_for("PyGhidra")
        script = provider.getScriptInstance(jpype.JClass("generic.jar.ResourceFile")(str(path)), err.writer)
        state = jpype.JClass("ghidra.app.script.GhidraState")(None, None, None, None, None, None)
        controls = jpype.JClass("ghidra.app.script.ScriptControls")(
            out.writer, err.writer, jpype.JClass("ghidra.util.task.TaskMonitor").DUMMY
        )
        try:
            script.execute(state, controls)
        except BaseException as exc:
            return {"result": "propagated" if token in str(exc) else "unexpected", "exception": str(exc)}
        return {"result": "swallowed" if token in err.text() else "unexpected", "stderr": err.text()}
    except Exception as exc:
        return {"result": "unavailable", "exception": str(exc)}
    finally:
        out.writer.close()
        err.writer.close()
        path.unlink(missing_ok=True)


def prepare(service, *, declared_version=None, probe_fn=None, apply_fn=None):
    """Try native first; only known-broken 3.1.0 may receive the existing shim."""
    from ghidra_headless.scripts import pyghidra_compat
    from ghidra_mcp.application.locks import SCRIPT_BARRIER
    from ghidra_headless.scripts import providers
    providers.ensure_bundle_host()
    if gate.get("ready") and declared_version is None and probe_fn is None and apply_fn is None:
        events.append({**gate, "reused": True})
        return dict(gate)
    gate.clear()
    gate.update(ready=False, mode="checking", version=declared_version or version("pyghidra"))
    probe_fn = probe_fn or probe
    original = None
    plugin = None
    with SCRIPT_BARRIER.write_lock():
        try:
            before = probe_fn(service.snapshot_base / "native-probe")
            gate["before"] = before["result"]
            if before["result"] == "propagated":
                gate.update(ready=True, mode="native")
            elif before["result"] == "swallowed" and gate["version"] == "3.1.0":
                # Private access exists ONLY on the temporary known-broken version path.
                plugin = pyghidra_compat._plugin_module()
                original = plugin.PyGhidraScript
                (apply_fn or pyghidra_compat.ensure_script_runner_binding)()
                after = probe_fn(service.snapshot_base / "patched-probe")
                gate["after"] = after["result"]
                if after["result"] != "propagated":
                    raise RuntimeError("post-patch propagation check failed")
                gate.update(ready=True, mode="compat")
            else:
                raise RuntimeError("unsupported or unverifiable script runtime")
        except Exception as exc:
            if plugin is not None and original is not None:
                plugin.PyGhidraScript = original
            gate.update(ready=False, mode="disabled", error=str(exc))
    if not gate["ready"]:
        for runtime in ("PyGhidra", "Java", "Jython"):
            service.mark_runtime_unavailable(runtime, "propagation_check_failed")
    events.append(dict(gate))
    return dict(gate)


def install():
    from ghidra_mcp import cli
    from ghidra_headless.scripts import execution
    from ghidra_headless.errors import HeadlessError
    import os
    if os.environ.get("VALIDATION_NESTED_JYTHON") == "1":
        # Evaluate the one-line public-API lifecycle change without editing production.
        import inspect
        source = inspect.getsource(execution.execute_script)
        old = "if runtime == providers.RUNTIME_JYTHON:"
        assert source.count(old) == 1
        source = source.replace(old, 'if providers.runtime_availability().get(providers.RUNTIME_JYTHON, False):')
        exec(compile(source, "<isolated nested-Jython lifecycle prototype>", "exec"), execution.__dict__)
    original = execution.run_script_with_transaction

    def guarded(**kwargs):
        if not gate["ready"]:
            raise HeadlessError("SCRIPT_RUNTIME_UNAVAILABLE: global script propagation check failed")
        return original(**kwargs)

    cli._prepare_script_runtime = prepare
    execution.run_script_with_transaction = guarded


def public_raw_import(project, path, name, *, language="x86:LE:64:default", compiler=None,
                      options=None, fail_stage=None, evidence=None):
    """Public Java API replacement, with real provider/result cleanup."""
    import pyghidra
    evidence = evidence if evidence is not None else {}
    evidence.update(programs=[], provider=None, results=None)
    J = jpype.JClass
    loader = J("ghidra.app.util.opinion.BinaryLoader")()
    provider = J("ghidra.app.util.bin.RandomAccessByteProvider")(J("java.io.File")(str(path)), "r")
    evidence["provider"] = provider
    try:
        if fail_stage == "metadata":
            raise RuntimeError("injected metadata failure")
        loader_map = J("ghidra.app.util.opinion.LoaderMap")()
        loader_map.put(loader, loader.findSupportedLoadSpecs(provider))
        cs = J("ghidra.program.model.lang.CompilerSpecID")(compiler) if compiler else None
        chooser = J("ghidra.app.util.importer.LcsHintLoadSpecChooser")(
            J("ghidra.program.model.lang.LanguageID")(language), cs
        )
        load_spec = chooser.choose(loader_map)
        metadata = loader.getDefaultOptions(provider, load_spec, None, False, False)
        names = {str(o.getName()): str(o.getArg()) for o in metadata if o.getArg() is not None}
        evidence["option_args"] = names
        builder = (pyghidra.program_loader().project(project.getProject()).projectFolderPath("/")
                   .source(provider).name(name).loaders(loader.getClass()).language(language))
        if compiler:
            builder = builder.compiler(compiler)
        for key, value in (options or {}).items():
            if key not in names:
                raise RuntimeError("RAW_LOADER_OPTION_UNAVAILABLE: " + key)
            # HexLong options parse even unprefixed text as hexadecimal.
            wire_value = hex(value) if key in {"File Offset", "Length"} else str(value)
            builder = builder.addLoaderArg(names[key], wire_value)
        results = builder.load()
        evidence["results"] = results
        try:
            loaded = results.getPrimary()
            assert loaded is not None
            def inspect(p):
                evidence["programs"].append(p)
                blocks = list(p.getMemory().getBlocks())
                block = blocks[0]
                buf = jpype.JArray(jpype.JByte)(int(block.getSize()))
                p.getMemory().getBytes(block.getStart(), buf)
                evidence.update(base=int(block.getStart().getOffset()), size=int(block.getSize()),
                                block_name=str(block.getName()), overlay=bool(block.isOverlay()),
                                data=bytes(buf).hex(), language=str(p.getLanguageID()),
                                compiler=str(p.getCompilerSpec().getCompilerSpecID()))
            loaded.apply(jpype.JProxy("java.util.function.Consumer", dict(accept=inspect)))
            if fail_stage == "save":
                raise RuntimeError("injected save failure")
            domain_file = loaded.save(J("ghidra.util.task.TaskMonitor").DUMMY)
            evidence["saved_path"] = str(domain_file.getPathname())
            return domain_file
        finally:
            results.close()
    finally:
        provider.close()
