import itertools
import importlib
import sys
import pytest
from ghidra_mcp import cli
from test_runtime_script_commands import _nested_script_project, _run, _plate, _domain_error, _runtimes

RUNTIMES = ["Java", "PyGhidra", "Jython"]
CASES = list(itertools.product(RUNTIMES, RUNTIMES, ["success", "caught", "uncaught"]))


def wrap(runtime, name, body):
    if runtime == "Java":
        return ('import ghidra.app.script.GhidraScript;\nimport ghidra.program.model.listing.CodeUnit;\n'
                f'public class {name} extends GhidraScript {{ public void run() throws Exception {{\n{body}\n}} }}\n')
    return f'# @runtime {runtime}\nfrom ghidra.program.model.listing import CodeUnit\n{body}\n'


def edit(runtime, text):
    return f'currentProgram.getListing().setComment(currentProgram.getMinAddress(), CodeUnit.PLATE_COMMENT, "{text}")' + (';' if runtime == 'Java' else '')


def sources_for(parent_runtime, child_runtime, outcome):
    suffix = '_'.join([parent_runtime, child_runtime, outcome])
    parent, child = 'Parent_' + suffix, 'Child_' + suffix
    child_file = child + ('.java' if child_runtime == 'Java' else '.py')
    parent_file = parent + ('.java' if parent_runtime == 'Java' else '.py')
    child_body = edit(child_runtime, 'CHILD_EDIT') + '\nprintln("CHILD_EXECUTED");\n' if child_runtime == 'Java' else edit(child_runtime, 'CHILD_EDIT') + '\nprint("CHILD_EXECUTED")\n'
    if outcome != 'success':
        child_body += 'throw new RuntimeException("CROSS_CHILD_FAILURE");' if child_runtime == 'Java' else 'raise RuntimeError("CROSS_CHILD_FAILURE")'
    call = f'runScript("{child_file}")' + (';' if parent_runtime == 'Java' else '')
    if outcome == 'caught':
        if parent_runtime == 'Java':
            call = f'try {{ {call} }} catch (Exception e) {{ println("CHILD_HANDLED"); }}'
        else:
            call = f'from java.lang import Exception as JavaException\ntry:\n    {call}\nexcept (Exception, JavaException):\n    print("CHILD_HANDLED")'
    parent_body = edit(parent_runtime, 'PARENT_BEFORE') + '\n' + call + '\n' + edit(parent_runtime, 'PARENT_AFTER')
    return parent_file, {parent_file: wrap(parent_runtime, parent, parent_body), child_file: wrap(child_runtime, child, child_body)}


@pytest.fixture
def cross_project(tmp_path_factory):
    sources = {}
    for case in CASES:
        _, generated = sources_for(*case)
        sources.update(generated)
    with _nested_script_project(tmp_path_factory.mktemp('cross_runtime'), sources) as pair:
        assert all(_runtimes()[r] for r in RUNTIMES), 'All three runtimes are required, no skips'
        try:
            yield pair
        finally:
            cli.close_session(target=pair[0], discard_changes=True)
            cli.load_project_program(target=pair[0], domain_path='/hello.bin')


@pytest.mark.parametrize('parent_runtime,child_runtime,outcome', CASES)
def test_parent_child_runtime_matrix(cross_project, parent_runtime, child_runtime, outcome):
    target, address = cross_project
    parent_file, _ = sources_for(parent_runtime, child_runtime, outcome)
    cli.apply_edits(target=target, edits=[{'kind':'set_comment','address':address,'comment':'BASELINE','comment_type':'plate'}])
    if outcome == 'uncaught':
        with pytest.raises(Exception, match='SCRIPT_FAILED') as failed:
            _run(target, script_id='t:' + parent_file)
        details = _domain_error(failed.value)['details']
        assert details['transaction_outcome'] == 'rolled_back'
        message = details['error']['message']
        assert 'CROSS_CHILD_FAILURE' in message or (parent_runtime == 'Jython' and child_runtime == 'PyGhidra' and 'org.jpype.PyExceptionProxy' in message)
        assert _plate(target,address) == 'BASELINE'
    else:
        result = _run(target, script_id='t:' + parent_file)
        assert result['transaction_outcome'] == 'committed'
        assert result['error'] is None
        assert 'CHILD_EXECUTED' in result['stdout']['text']
        if outcome == 'caught':
            assert 'CHILD_HANDLED' in result['stdout']['text']
        assert _plate(target,address) == 'PARENT_AFTER'
    print('CROSS_RUNTIME', parent_runtime, child_runtime, outcome, 'OK')


@pytest.mark.parametrize('expression,success', [('None',True),('0',True),('3',False),('"failure"',False)])
def test_pyghidra_system_exit(cross_project, expression, success):
    target, address = cross_project
    before = _plate(target,address)
    source = wrap('PyGhidra','unused', edit('PyGhidra','EXIT_VALIDATION') + f'\nimport sys\nsys.exit({expression})')
    if success:
        result = _run(target,source=source)
        assert result['transaction_outcome'] == 'committed'
        assert _plate(target,address) == 'EXIT_VALIDATION'
    else:
        with pytest.raises(Exception,match='SCRIPT_FAILED') as failed:
            _run(target,source=source)
        assert _domain_error(failed.value)['details']['transaction_outcome'] == 'rolled_back'
        assert _plate(target,address) == before


def test_pyghidra_keyboard_interrupt_and_process_state_restoration(cross_project):
    target,address = cross_project
    before = _plate(target,address)
    argv, path, modules = list(sys.argv), list(sys.path), set(sys.modules)
    source = wrap('PyGhidra','unused',edit('PyGhidra','INTERRUPTED') + '\nimport sys, types\nsys.modules["mecha_ephemeral_validation"] = types.ModuleType("mecha_ephemeral_validation")\nraise KeyboardInterrupt("expected interrupt")')
    with pytest.raises(Exception,match='SCRIPT_FAILED') as failed:
        _run(target,source=source)
    assert _domain_error(failed.value)['details']['transaction_outcome'] == 'rolled_back'
    assert _plate(target,address) == before
    assert sys.argv == argv and sys.path == path
    assert 'mecha_ephemeral_validation' not in sys.modules


def test_pyghidra_timeout_rolls_back_and_recovers(cross_project):
    target,address = cross_project
    before = _plate(target,address)
    source = wrap('PyGhidra','unused',edit('PyGhidra','TIMED_OUT') + '\nfrom java.lang import Thread\nwhile True:\n    monitor.checkCancelled()\n    Thread.sleep(10)')
    with pytest.raises(Exception,match='SCRIPT_TIMEOUT') as failed:
        _run(target,source=source,timeout_seconds=1)
    assert _domain_error(failed.value)['details']['transaction_outcome'] == 'rolled_back'
    assert _plate(target,address) == before
    result = _run(target,source=wrap('PyGhidra','unused',edit('PyGhidra','RECOVERED')))
    assert result['transaction_outcome'] == 'committed'
    assert _plate(target,address) == 'RECOVERED'
