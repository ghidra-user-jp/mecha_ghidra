from pathlib import Path
import uuid
import jpype
import pytest
from prototype import public_raw_import
from test_runtime_script_commands import _start_pyghidra_if_needed


@pytest.fixture(scope="module")
def raw_project(tmp_path_factory):
    _start_pyghidra_if_needed()
    root = tmp_path_factory.mktemp("public_raw")
    project = jpype.JClass("ghidra.base.project.GhidraProject").createProject(str(root), "raw", False)
    binary = root / "bytes.bin"
    binary.write_bytes(bytes(range(256)))
    yield project, binary, root
    project.close()
    reopened = jpype.JClass("ghidra.base.project.GhidraProject").openProject(str(root), "raw", True)
    reopened.close()


def assert_closed(evidence):
    provider = evidence["provider"]
    with pytest.raises(Exception, match="closed|Closed"):
        provider.readByte(0)
    assert all(p.isClosed() for p in evidence["programs"]), "LoadResults.close did not release a program"


@pytest.mark.parametrize("options,compiler", [
    ({}, None),
    ({"Base Address": "0x12345000"}, None),
    ({"Length": 24}, None),
    ({"Block Name": "validated_block"}, None),
    ({"File Offset": 16}, None),
    ({"File Offset": 16, "Length": 24}, None),
    ({"Base Address": "0x2000", "File Offset": 32, "Length": 48, "Block Name": "all_options"}, "windows"),
    ({"Length": 0}, None),
])
def test_public_raw_arguments_and_cleanup(raw_project, options, compiler):
    project, binary, root = raw_project
    evidence = {}
    public_raw_import(project, binary, "case_" + uuid.uuid4().hex, options=options, compiler=compiler, evidence=evidence)
    assert_closed(evidence)
    assert evidence["base"] == int(options.get("Base Address", "0"), 0)
    offset = options.get("File Offset", 0)
    # Preserve BinaryLoader's official default: full file length, even with an offset.
    # The portion beyond the source bytes is zero filled by Ghidra.
    length = options.get("Length") or 256
    assert evidence["size"] == length
    expected = bytes(range(256))[offset:offset+length]
    expected += bytes(length - len(expected))
    assert bytes.fromhex(evidence["data"]) == expected
    if "Block Name" in options:
        assert evidence["block_name"] == options["Block Name"]
    if compiler:
        assert evidence["compiler"] == compiler
    assert evidence["language"] == "x86:LE:64:default"
    assert evidence["overlay"] is False
    print("RAW", {k:v for k,v in evidence.items() if k not in {"programs","provider","results","data"}})


@pytest.mark.parametrize("options,language,fail_stage", [
    ({"Overlay": "true"}, "x86:LE:64:default", None),
    ({}, "nonexistent:LE:64:default", None),
    ({"File Offset": 512}, "x86:LE:64:default", None),
    ({"Length": -1}, "x86:LE:64:default", None),
    ({}, "x86:LE:64:default", "metadata"),
    ({}, "x86:LE:64:default", "save"),
])
def test_public_raw_failure_cleanup(raw_project, options, language, fail_stage):
    project, binary, root = raw_project
    evidence = {}
    name = "fail_" + uuid.uuid4().hex
    with pytest.raises(Exception) as failed:
        public_raw_import(project, binary, name, options=options, language=language, fail_stage=fail_stage, evidence=evidence)
    assert_closed(evidence)
    assert project.getProject().getProjectData().getFile("/" + name) is None
    print("RAW_FAILURE", options, language, fail_stage, str(failed.value))


def test_public_raw_repeated_success_failure_releases_descriptors(raw_project):
    project, binary, root = raw_project
    bean = jpype.JClass("java.lang.management.ManagementFactory").getOperatingSystemMXBean()
    before = int(bean.getOpenFileDescriptorCount())
    for i in range(20):
        evidence = {}
        if i % 2:
            with pytest.raises(RuntimeError, match="injected save failure"):
                public_raw_import(project, binary, "cycle_" + uuid.uuid4().hex, fail_stage="save", evidence=evidence)
        else:
            public_raw_import(project, binary, "cycle_" + uuid.uuid4().hex, evidence=evidence)
        assert_closed(evidence)
    after = int(bean.getOpenFileDescriptorCount())
    print("RAW_DESCRIPTOR_COUNTS", before, after)
    assert after <= before + 2


def test_characterize_current_production_numeric_argument_bug(raw_project):
    from ghidra_headless.session.project_handle import ProjectHandle
    project, binary, root = raw_project
    handle = object.__new__(ProjectHandle)
    handle.project = project
    domain_file = handle._import_program_raw_locked(
        binary, program_dir="/", program_name="production_numeric_baseline", language_id="x86:LE:64:default",
        compiler_spec_id=None, base_address="0x1000", file_offset=16, length=24, block_name="baseline", overlay=False,
    )
    consumer = jpype.JClass("java.lang.Object")()
    program = domain_file.getReadOnlyDomainObject(consumer, -1, jpype.JClass("ghidra.util.task.TaskMonitor").DUMMY)
    try:
        block = list(program.getMemory().getBlocks())[0]
        actual_length = int(block.getSize())
        first_byte = int(program.getMemory().getByte(block.getStart())) & 255
        print("CURRENT_PRODUCTION_NUMERIC_BUG", {"requested_offset":16,"actual_offset":first_byte,"requested_length":24,"actual_length":actual_length})
        assert (first_byte, actual_length) == (0x16, 0x24)
    finally:
        program.release(consumer)
    assert program.isClosed()
