import json
from pathlib import Path
import pytest
from test_runtime_resource_safety import runtime as _runtime

runtime = _runtime
TARGET = 'resource_safety'
OUT = Path(__file__).parent

@pytest.mark.parametrize('offset,size', [(None,0),(0,4),(0,0),(16,0)])
def test_struct_with_explicit_member_offset(runtime, offset, size):
    member = {'name':'value','type':'int'}
    if offset is not None:
        member['offset'] = offset
    result = None
    error = None
    try:
        result = runtime['create_struct'](target=TARGET,name='Layout',size=size,members=[member])
    except Exception as exc:
        error = str(exc)
    (OUT/f'struct-offset-{offset}-{size}.json').write_text(json.dumps({'input':{'size':size,'members':[member]},'result':result,'error':error},indent=2))
    assert error is None, error
    values = [m for m in result['members'] if m['name']=='value']
    assert values[0]['offset'] == (offset or 0)
    assert values[0]['length'] == 4

@pytest.mark.parametrize('offset', [None,4,16])
def test_append_struct_member_with_explicit_offset(runtime, offset):
    before = runtime['create_struct'](target=TARGET,name='Layout',members=[{'name':'first','type':'int'}])
    member = {'name':'second','type':'int'}
    if offset is not None:
        member['offset'] = offset
    result = None
    error = None
    try:
        result = runtime['add_struct_members'](target=TARGET,struct_name='Layout',members=[member])
    except Exception as exc:
        error = str(exc)
    after = runtime['get_data_type'](target=TARGET,path='/Layout')
    (OUT/f'struct-append-{offset}.json').write_text(json.dumps({'before':before,'input':member,'result':result,'error':error,'after':after},indent=2))
    assert error is None, error
    assert [(m['name'],m['offset']) for m in result['members'] if m['name']] == [('first',0),('second',4 if offset is None else offset)]

@pytest.mark.parametrize('order', [('A','B'),('B','A')])
def test_enum_update_can_replace_all_negative_values(runtime, order):
    before = runtime['create_enum'](target=TARGET,name='Codes',size=1,values={'A':-1,'B':-2})
    values = {'A':255,'B':1}
    result = None
    error = None
    try:
        result = runtime['set_enum_values'](target=TARGET,name='Codes',values={k:values[k] for k in order})
    except Exception as exc:
        error = str(exc)
    after = runtime['get_data_type'](target=TARGET,path='/Codes')
    (OUT/f'enum-update-{order[0]}.json').write_text(json.dumps({'before':before,'result':result,'error':error,'after':after},indent=2))
    assert error is None, error
    assert {v['name']:v['value'] for v in after['values']} == values


def test_public_api_struct_growth_and_enum_staged_replacement(runtime):
    from ghidra.program.model.data import StructureDataType, CategoryPath, IntegerDataType, EnumDataType
    struct = StructureDataType(CategoryPath('/'), 'Layout', 0)
    for offset in (0,16):
        struct.growStructure(max(0, offset + 4 - struct.getLength()))
        struct.replaceAtOffset(offset,IntegerDataType.dataType,4,f'at_{offset}','')
    assert struct.getLength() == 20
    assert str(struct.getComponentAt(16).getFieldName()) == 'at_16'
    for order in [('A','B'),('B','A')]:
        enum = EnumDataType(CategoryPath('/'),'Codes',1)
        enum.add('A',-1)
        enum.add('B',-2)
        values = {'A':255,'B':1}
        for name in order:
            enum.remove(name)
        for name in order:
            enum.add(name,values[name])
        assert int(enum.getValue('A')) == 255
        assert int(enum.getValue('B')) == 1
        assert not enum.isSigned()
