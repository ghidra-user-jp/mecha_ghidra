import json
from pathlib import Path

import pytest

from ghidra_mcp.contracts.tool_spec import get_all_tool_specs,get_checkout_required_tool_names
from ghidra_mcp.presentation.cli_runtime import create_cli_runtime
from test_runtime_readonly_commands import _start_pyghidra_if_needed

WORK=Path(__file__).parent

@pytest.mark.parametrize('offset,length',[(0,None),(4,None),(4,6)])
def test_raw_offset_without_length_imports_remaining_file(tmp_path,offset,length):
    _start_pyghidra_if_needed()
    from ghidra_headless.handlers import core,core_runtime
    specs=get_all_tool_specs()
    bundle=create_cli_runtime(registered_specs=specs,core_accessor=lambda:core,checkout_required_commands=get_checkout_required_tool_names(specs))
    api=bundle.runtime.tools
    observed={'offset':offset,'length':length}
    try:
        api['create_project'](project_location=str(tmp_path),project_name='offset')
        api['register_target'](target='offset',project_location=str(tmp_path),project_name='offset')
        binary=tmp_path/'tiny.bin'
        data=bytes(range(10))
        binary.write_bytes(data)
        imported=api['import_program'](target='offset',binary_path=str(binary),import_mode='raw_binary',language_id='x86:LE:32:default',
                                      file_offset=offset,length=length,base_address='0x1000',analyze_imported=False)
        observed['result']=imported
        api['load_project_program'](target='offset',domain_path=imported['program'])
        program=core_runtime._CONTEXTS['offset'].program
        block=program.getMemory().getBlocks()[0]
        size=int(block.getSize())
        actual=bytes(int(program.getMemory().getByte(block.getStart().add(i))) & 255 for i in range(size))
        observed.update(size=size,actual_hex=actual.hex())
        assert actual==data[offset:offset+length if length is not None else None]
    except Exception as exc:
        observed.update(error=str(exc),domain_error=getattr(exc,'domain_error',None))
        raise
    finally:
        (WORK/f'offset-{offset}-{length}.json').write_text(json.dumps(observed,indent=2))
        bundle.target_service.close_all()
