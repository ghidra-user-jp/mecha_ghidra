import json
from pathlib import Path

import pytest

from ghidra_mcp.contracts.tool_spec import get_all_tool_specs, get_checkout_required_tool_names
from ghidra_mcp.presentation.cli_runtime import create_cli_runtime
from test_runtime_readonly_commands import _start_pyghidra_if_needed

WORK=Path(__file__).parent

@pytest.mark.parametrize('language,label,code',[('PIC-16:LE:16:PIC-16','pic',b'\0\0\0\0'),('x86:LE:32:default','x86',b'\x90\xc3')])
@pytest.mark.parametrize('selector',['entry_address','entry_offset'])
def test_explicit_entry_points_to_imported_base(tmp_path,language,label,code,selector):
    _start_pyghidra_if_needed()
    from ghidra_headless.handlers import core,core_runtime
    specs=get_all_tool_specs()
    bundle=create_cli_runtime(registered_specs=specs,core_accessor=lambda: core,
                             checkout_required_commands=get_checkout_required_tool_names(specs))
    api=bundle.runtime.tools
    observed={'language':language,'selector':selector}
    try:
        api['create_project'](project_location=str(tmp_path),project_name='entry')
        api['register_target'](target='entry',project_location=str(tmp_path),project_name='entry')
        binary=tmp_path/'tiny.bin'
        binary.write_bytes(code)
        imported=api['import_program'](target='entry',binary_path=str(binary),import_mode='raw_binary',
                language_id=language,base_address='0x1000',analyze_imported=False,
                **{selector:'0x1000' if selector=='entry_address' else 0})
        observed['imported']=imported
        api['load_project_program'](target='entry',domain_path=imported['program'])
        program=core_runtime._CONTEXTS['entry'].program
        addr=program.getMinAddress()
        symbols=program.getSymbolTable()
        entries=list(symbols.getExternalEntryPointIterator())
        observed.update(base=str(addr),base_bytes=str(addr.getOffsetAsBigInteger()),unit_size=int(addr.getAddressSpace().getAddressableUnitSize()),
                        external_entries=[str(a) for a in entries],entry_in_memory=[bool(program.getMemory().contains(a)) for a in entries],
                        function_at_base=program.getFunctionManager().getFunctionAt(addr) is not None)
        assert symbols.isExternalEntryPoint(addr)
        assert observed['function_at_base']
    finally:
        (WORK/f'entry-{label}-{selector}.json').write_text(json.dumps(observed,indent=2))
        bundle.target_service.close_all()
