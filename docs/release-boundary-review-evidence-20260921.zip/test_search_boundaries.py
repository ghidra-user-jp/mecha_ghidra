import asyncio
import json
from pathlib import Path

import pytest
import regex
from mcp import Client

from ghidra_mcp.presentation.config import ToolPresentationConfig
from ghidra_mcp.presentation.mcp_server import create_mcp_server
from ghidra_mcp.presentation.tool_dispatcher import dispatch_tool

WORK = Path(__file__).parent

@pytest.mark.parametrize('pattern,label', [(r'a\K','keep'), (r'(?=a)','lookahead'), (r'|a','empty_alternative')])
@pytest.mark.parametrize('mode', ['bounded','none'])
@pytest.mark.parametrize('threshold', [1024,12000])
def test_paged_search_matches_single_search(pattern,label,mode,threshold):
    server=create_mcp_server(specs={}, registry_provider=lambda: None,
                             dispatcher_provider=lambda: dispatch_tool,
                             presentation_config=ToolPresentationConfig(large_result_threshold_chars=threshold,large_result_preview_chars=0))
    entry=server.result_store.add(tool='decompile_function',target='sample',text='aaa',mime_type='text/plain',result_type='string',item_count=None)
    observed={'pattern':pattern,'mode':mode,'threshold':threshold,'pages':[]}
    async def run():
        async with Client(server.mcp) as client:
            args={'result_id':entry.result_id,'pattern':pattern,'context_chars':0}
            baseline=await client.call_tool('search_result',{**args,'max_matches':100})
            assert not baseline.is_error
            expected=[m.span() for m in regex.finditer(pattern, entry.text)]
            assert baseline.structured_content['result']['match_count']==len(expected)
            observed['baseline']=baseline.structured_content['result']
            actual=[]
            cursor=None
            for _ in range(20):
                page=await client.call_tool('search_result',{**args,'max_matches':1,'count_mode':mode,'cursor':cursor})
                assert not page.is_error
                payload=page.structured_content['result']
                observed['pages'].append(payload)
                actual.extend((m['offset_chars'],m['end_offset']) for m in payload['matches'])
                cursor=payload['next_cursor']
                if cursor is None:break
            else:pytest.fail('did not finish')
            observed.update(expected=expected,actual=actual)
            assert actual==expected
    try:asyncio.run(run())
    finally:(WORK/f'search-{label}-{mode}-{threshold}.json').write_text(json.dumps(observed,indent=2))
