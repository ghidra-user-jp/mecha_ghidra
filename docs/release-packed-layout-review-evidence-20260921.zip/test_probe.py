import json
from pathlib import Path
import pytest
from test_runtime_resource_safety import runtime as _runtime
runtime = _runtime
TARGET = 'resource_safety'
WORK = Path(__file__).resolve().parent

@pytest.mark.parametrize('offset',[1,2,4,12,16])
def test_packed_structure(runtime,offset):
    from ghidra_headless.handlers import core_runtime
    parsed = runtime['parse_c_declarations'](target=TARGET,source='struct Packet { char tag; int value; char tail; };')
    before = runtime['get_data_type'](target=TARGET,path='/Packet')
    dt = core_runtime._CONTEXTS[TARGET].program.getDataTypeManager().getDataType('/Packet')
    result = {'parsed':parsed,'before':before,'packing':bool(dt.isPackingEnabled()),'offset':offset}
    try:
        result['edited'] = runtime['add_struct_members'](target=TARGET,struct_name='Packet',members=[{'name':'extra','type':'char','offset':offset}])
    except Exception as exc:
        result['error'] = str(exc)
    result['after'] = runtime['get_data_type'](target=TARGET,path='/Packet')
    (WORK/f'packed-{offset}.json').write_text(json.dumps(result,indent=2))
    assert 'error' not in result, result
    actual = next(m['offset'] for m in result['after']['members'] if m['name']=='extra')
    assert actual == offset, result


def test_wrong_type_for_struct(runtime):
    runtime['create_enum'](target=TARGET,name='WrongKind',values={'A':1})
    before = runtime['get_data_type'](target=TARGET,path='/WrongKind')
    try:
        runtime['add_struct_members'](target=TARGET,struct_name='WrongKind',members=[{'name':'B','type':'int'}])
    except Exception as exc:
        result={'before':before,'error':str(exc),'after':runtime['get_data_type'](target=TARGET,path='/WrongKind')}
        (WORK/'wrong-kind.json').write_text(json.dumps(result,indent=2))
        assert result['before']['values']==result['after']['values']

@pytest.mark.parametrize('offset',[2,4,12,16])
def test_unpacked_offset_control(runtime,offset):
    runtime['create_struct'](target=TARGET,name='Packet',size=12,members=[{'name':'tag','type':'char','offset':0},{'name':'value','type':'int','offset':4},{'name':'tail','type':'char','offset':8}])
    result=runtime['add_struct_members'](target=TARGET,struct_name='Packet',members=[{'name':'extra','type':'char','offset':offset}])
    members={m['name']:m['offset'] for m in result['members'] if m['name']}
    assert members['extra']==offset
    assert members['tag']==0 and members['tail']==8
    assert result['length']==max(12,offset+1)


def test_packed_implicit_append_control(runtime):
    runtime['parse_c_declarations'](target=TARGET,source='struct Packet { char tag; int value; char tail; };')
    result=runtime['add_struct_members'](target=TARGET,struct_name='Packet',members=[{'name':'extra','type':'char'}])
    assert {m['name']:m['offset'] for m in result['members']}=={'tag':0,'value':4,'tail':8,'extra':9}


def test_packed_invalid_offset_rolls_back(runtime):
    runtime['parse_c_declarations'](target=TARGET,source='struct Packet { char tag; int value; char tail; };')
    before=runtime['get_data_type'](target=TARGET,path='/Packet')
    with pytest.raises(Exception):
        runtime['add_struct_members'](target=TARGET,struct_name='Packet',members=[{'name':'extra','type':'char','offset':4},{'name':'invalid','type':'char','offset':-1}])
    after=runtime['get_data_type'](target=TARGET,path='/Packet')
    assert (after['members'],after['length'])==(before['members'],before['length'])


def test_packed_misplacement_persists(runtime):
    runtime['parse_c_declarations'](target=TARGET,source='struct Packet { char tag; int value; char tail; };')
    before=runtime['get_data_type'](target=TARGET,path='/Packet')
    result=runtime['add_struct_members'](target=TARGET,struct_name='Packet',members=[{'name':'extra','type':'char','offset':4}])
    runtime['save_project_program'](target=TARGET)
    runtime['load_project_program'](target=TARGET,domain_path='/tiny.bin')
    after=runtime['get_data_type'](target=TARGET,path='/Packet')
    (WORK/'packed-persistence.json').write_text(json.dumps({'before':before,'result':result,'reloaded':after},indent=2))
    assert {m['name']:m['offset'] for m in after['members']}=={'tag':0,'extra':1,'tail':2}
    assert after['length']==3


@pytest.mark.parametrize('offset',[2,4,12,16])
def test_public_api_layout_prototype(runtime,monkeypatch,offset):
    from ghidra_headless.handlers.commands import mutating_data_types
    from ghidra_headless.handlers import core_runtime
    place=mutating_data_types._place_struct_member
    def preserve_layout(struct,data_type,length,field_name,comment,offset):
        if offset is not None and struct.isPackingEnabled():
            struct.setPackingEnabled(False)
        return place(struct,data_type,length,field_name,comment,offset)
    monkeypatch.setattr(mutating_data_types,'_place_struct_member',preserve_layout)
    runtime['parse_c_declarations'](target=TARGET,source='struct Packet { char tag; int value; char tail; };')
    before=runtime['get_data_type'](target=TARGET,path='/Packet')
    result=runtime['add_struct_members'](target=TARGET,struct_name='Packet',members=[{'name':'extra','type':'char','offset':offset}])
    runtime['save_project_program'](target=TARGET)
    runtime['load_project_program'](target=TARGET,domain_path='/tiny.bin')
    after=runtime['get_data_type'](target=TARGET,path='/Packet')
    dt=core_runtime._CONTEXTS[TARGET].program.getDataTypeManager().getDataType('/Packet')
    observed={'before':before,'result':result,'after':after,'packing_after':bool(dt.isPackingEnabled())}
    (WORK/f'public-api-prototype-{offset}.json').write_text(json.dumps(observed,indent=2))
    members={m['name']:m['offset'] for m in after['members'] if m['name']}
    assert members['extra']==offset
    assert members['tag']==0 and members['tail']==8
    assert after['length']==max(12,offset+1)
    assert not observed['packing_after']
