"""ScriptBarrier: readers and shutdown are bounded against a running script."""

from __future__ import annotations

import threading
import time
from types import SimpleNamespace

import fasteners
import pytest

from ghidra_mcp.application.locks import ScriptBarrier
from ghidra_mcp.domain import DomainError, ErrorCode


def _hold_writer(barrier: ScriptBarrier):
    entered = threading.Event()
    release = threading.Event()

    def run():
        with barrier.write_lock():
            entered.set()
            release.wait(5)

    thread = threading.Thread(target=run, daemon=True)
    thread.start()
    assert entered.wait(5)
    return release, thread


def test_reader_times_out_while_a_script_holds_the_barrier():
    barrier = ScriptBarrier()
    release, thread = _hold_writer(barrier)
    try:
        with pytest.raises(DomainError) as excinfo, barrier.read_lock(timeout=0.05):
            pass
        assert excinfo.value.code is ErrorCode.LOCK_TIMEOUT
        assert excinfo.value.retryable is True
        assert excinfo.value.details == {"lock": "script_barrier", "timeout": 0.05}
    finally:
        release.set()
        thread.join(5)
    with barrier.read_lock(timeout=0.05):
        pass


def test_bounded_writer_times_out_behind_a_running_writer():
    barrier = ScriptBarrier()
    release, thread = _hold_writer(barrier)
    try:
        with pytest.raises(DomainError) as excinfo, barrier.write_lock(timeout=0.05):
            pass
        assert excinfo.value.code is ErrorCode.LOCK_TIMEOUT
    finally:
        release.set()
        thread.join(5)
    with barrier.write_lock(timeout=0.05):
        assert barrier.writer_pending is True
    assert barrier.writer_pending is False


def test_writer_may_reenter_as_reader_without_waiting_for_itself():
    barrier = ScriptBarrier()
    with barrier.write_lock(), barrier.read_lock(timeout=0.01), barrier.write_lock(timeout=0.01):
        pass


def test_readers_proceed_after_the_writer_leaves():
    barrier = ScriptBarrier()
    release, thread = _hold_writer(barrier)
    results = []

    def reader():
        with barrier.read_lock(timeout=5):
            results.append("read")

    reader_thread = threading.Thread(target=reader, daemon=True)
    reader_thread.start()
    release.set()
    thread.join(5)
    reader_thread.join(5)
    assert results == ["read"]


def test_close_all_skips_instead_of_hanging_behind_a_script(monkeypatch, caplog):
    from ghidra_mcp.application import locks
    from ghidra_mcp.infrastructure.ghidra_adapter.runtime import target_lifecycle

    barrier = ScriptBarrier()
    monkeypatch.setattr(target_lifecycle, "SCRIPT_BARRIER", barrier)
    monkeypatch.setattr(locks, "get_lock_timeout_seconds", lambda: 0.05)
    lifecycle = object.__new__(target_lifecycle.RuntimeTargetLifecycle)
    lifecycle._store = SimpleNamespace(operation_lock=fasteners.ReaderWriterLock())
    closed = []
    lifecycle._close_all_locked = lambda: closed.append(True)

    release, thread = _hold_writer(barrier)
    try:
        with caplog.at_level("ERROR"):
            lifecycle.close_all()
        assert closed == []
        assert "close_all skipped" in caplog.text
    finally:
        release.set()
        thread.join(5)
    lifecycle.close_all()
    assert closed == [True]


def test_bounded_writer_times_out_behind_a_reader_and_removes_its_ticket():
    barrier = ScriptBarrier()
    done = threading.Event()
    errors = []

    def writer():
        try:
            with barrier.write_lock(timeout=0.05):
                pass
        except DomainError as exc:
            errors.append(exc)
        finally:
            done.set()

    thread = threading.Thread(target=writer, daemon=True)
    try:
        with barrier.read_lock():
            thread.start()
            assert done.wait(2), "writer ignored its timeout while a reader remained active"
            assert len(errors) == 1 and errors[0].code is ErrorCode.LOCK_TIMEOUT
            assert barrier.writer_pending is False
    finally:
        thread.join(5)
    with barrier.write_lock(timeout=0):
        pass


def test_queued_writer_blocks_new_readers_but_not_reader_reentrancy(monkeypatch):
    barrier = ScriptBarrier()
    waiting = threading.Event()
    wait_until = barrier._wait_until
    errors = []

    def observe_wait(predicate, timeout, *, role):
        if role == "writer":
            waiting.set()
        return wait_until(predicate, timeout, role=role)

    monkeypatch.setattr(barrier, "_wait_until", observe_wait)

    def new_reader():
        try:
            with barrier.read_lock(timeout=0.05):
                pass
        except DomainError as exc:
            errors.append(exc)

    written = threading.Event()

    def writer():
        with barrier.write_lock():
            written.set()

    thread = threading.Thread(target=writer, daemon=True)
    reader = threading.Thread(target=new_reader, daemon=True)
    try:
        with barrier.read_lock():
            thread.start()
            assert waiting.wait(5)
            with barrier.read_lock(timeout=0):
                pass
            reader.start()
            reader.join(2)
            assert not reader.is_alive()
            assert len(errors) == 1 and errors[0].code is ErrorCode.LOCK_TIMEOUT
            assert not written.is_set()
    finally:
        thread.join(5)
        if reader.ident is not None:
            reader.join(5)
    assert written.is_set()


def test_writers_run_fifo_before_new_readers(monkeypatch):
    barrier = ScriptBarrier()
    wait_until = barrier._wait_until
    waiting = {name: threading.Event() for name in ("writer-1", "writer-2", "reader")}
    order = []
    errors = []

    def observe_wait(predicate, timeout, *, role):
        event = waiting.get(threading.current_thread().name)
        if event is not None:
            event.set()
        return wait_until(predicate, timeout, role=role)

    monkeypatch.setattr(barrier, "_wait_until", observe_wait)

    def worker(name):
        try:
            lock = barrier.read_lock(timeout=5) if name == "reader" else barrier.write_lock(timeout=5)
            with lock:
                order.append(name)
        except Exception as exc:
            errors.append(exc)

    threads = []
    try:
        with barrier.read_lock():
            for name in waiting:
                thread = threading.Thread(target=worker, args=(name,), name=name, daemon=True)
                threads.append(thread)
                thread.start()
                assert waiting[name].wait(5)
    finally:
        for thread in threads:
            thread.join(5)
    assert not errors
    assert order == ["writer-1", "writer-2", "reader"]


def test_reader_to_writer_upgrade_fails_without_leaking_a_ticket():
    barrier = ScriptBarrier()
    with barrier.read_lock():
        with pytest.raises(RuntimeError, match="Cannot upgrade"), barrier.write_lock(timeout=0):
            pass
        assert not barrier.writer_pending
    with barrier.write_lock(timeout=0):
        pass


@pytest.mark.parametrize("kind", ["read", "write"])
def test_body_exception_releases_the_barrier(kind):
    barrier = ScriptBarrier()
    context = barrier.read_lock() if kind == "read" else barrier.write_lock()
    with pytest.raises(ValueError, match="body failed"), context:
        raise ValueError("body failed")
    acquired = []

    def writer():
        with barrier.write_lock(timeout=0):
            acquired.append(True)

    thread = threading.Thread(target=writer, daemon=True)
    thread.start()
    thread.join(5)
    assert acquired == [True]


def test_interrupted_writer_does_not_leave_a_pending_ticket(monkeypatch):
    barrier = ScriptBarrier()
    wait_until = barrier._wait_until

    def interrupt(*args, **kwargs):
        raise KeyboardInterrupt

    monkeypatch.setattr(barrier, "_wait_until", interrupt)
    with pytest.raises(KeyboardInterrupt), barrier.write_lock(timeout=0):
        pass
    assert not barrier.writer_pending
    monkeypatch.setattr(barrier, "_wait_until", wait_until)
    with barrier.read_lock(timeout=0):
        pass


def test_concurrent_readers_never_overlap_a_writer():
    barrier = ScriptBarrier()
    start = threading.Barrier(8)
    guard = threading.Lock()
    active = {"read": 0, "write": 0}
    errors = []

    def worker(index):
        try:
            start.wait(5)
            for iteration in range(20):
                kind = "write" if (iteration + index) % 3 == 0 else "read"
                context = barrier.write_lock(timeout=5) if kind == "write" else barrier.read_lock(timeout=5)
                with context:
                    with guard:
                        assert active["write"] == 0
                        if kind == "write":
                            assert active["read"] == 0
                        active[kind] += 1
                    time.sleep(0)  # Give contenders a chance to run while ownership is held.
                    with guard:
                        active[kind] -= 1
        except Exception as exc:
            errors.append(exc)

    threads = [threading.Thread(target=worker, args=(index,), daemon=True) for index in range(8)]
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join(10)
    assert not any(thread.is_alive() for thread in threads)
    assert not errors
    assert active == {"read": 0, "write": 0}
