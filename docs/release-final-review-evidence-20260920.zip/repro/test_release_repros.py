"""Independent release-review reproductions; no application monkeypatches for Ghidra."""
import json
import threading
import time

import pytest

from ghidra_mcp.application.locks import ScriptBarrier


def test_reader_timeout_covers_writer_arriving_after_precheck():
    barrier = ScriptBarrier()
    checked = threading.Event()
    proceed = threading.Event()
    finished = threading.Event()
    observed = {}
    original = barrier._wait_for_writers

    def pause_after_check(timeout, *, role):
        original(timeout, role=role)
        checked.set()
        assert proceed.wait(5)

    barrier._wait_for_writers = pause_after_check

    def reader():
        started = time.monotonic()
        try:
            with barrier.read_lock(timeout=0.05):
                observed['acquired'] = True
        except Exception as exc:
            observed['error'] = str(exc)
        finally:
            observed['elapsed_seconds'] = time.monotonic() - started
            finished.set()

    thread = threading.Thread(target=reader, daemon=True)
    thread.start()
    assert checked.wait(5)
    try:
        with barrier.write_lock():
            proceed.set()
            respected_timeout = finished.wait(0.25)
    finally:
        proceed.set()
        thread.join(5)
    print(json.dumps(observed))
    assert respected_timeout, 'read_lock(timeout=0.05) still blocked after 0.25 seconds'


def test_writer_timeout_covers_active_readers():
    barrier = ScriptBarrier()
    started = threading.Event()
    finished = threading.Event()
    observed = {}

    def writer():
        begin = time.monotonic()
        started.set()
        try:
            with barrier.write_lock(timeout=0.05):
                observed['acquired'] = True
        except Exception as exc:
            observed['error'] = str(exc)
        finally:
            observed['elapsed_seconds'] = time.monotonic() - begin
            finished.set()

    with barrier.read_lock():
        thread = threading.Thread(target=writer, daemon=True)
        thread.start()
        assert started.wait(5)
        respected_timeout = finished.wait(0.25)
    thread.join(5)
    print(json.dumps(observed))
    assert respected_timeout, 'write_lock(timeout=0.05) still blocked after 0.25 seconds'


def test_java_parent_nested_jython_failure_rolls_back(tmp_path):
    from ghidra_mcp import cli
    from test_runtime_script_commands import _nested_script_project, _plate, _run, _runtimes

    child_source = (
        '# @runtime Jython\n'
        'setPlateComment(currentProgram.getMinAddress(), "CHILD_EDIT")\n'
        'raise RuntimeError("EXTERNAL_CHILD_FAILURE")\n'
    )
    parent = (
        'import ghidra.app.script.GhidraScript;\n'
        'public class ExternalParent extends GhidraScript {\n'
        'public void run() throws Exception {\n'
        'setPlateComment(currentProgram.getMinAddress(), "PARENT_BEFORE");\n'
        'runScript("sub/ExternalFailure.py");\n'
        'setPlateComment(currentProgram.getMinAddress(), "PARENT_AFTER");\n'
        '} }\n'
    )
    with _nested_script_project(tmp_path, {'ExternalParent.java': parent, 'sub/ExternalFailure.py': child_source}) as (target, address):
        assert _runtimes()['Jython']
        _run(target, source='print("WARM_JYTHON")', runtime='Jython')
        cli.apply_edits(target=target, edits=[{
            'kind': 'set_comment', 'address': address, 'comment': 'BASELINE', 'comment_type': 'plate'
        }])
        error = None
        result = None
        try:
            result = _run(target, script_id='t:ExternalParent.java')
        except Exception as exc:
            error = exc
        plate = _plate(target, address)
        print(json.dumps({'result': result, 'error': str(error), 'plate': plate}, default=str))
        assert error is not None and 'SCRIPT_FAILED' in str(error)
        assert 'EXTERNAL_CHILD_FAILURE' in json.dumps(getattr(error, 'domain_error', {}))
        assert plate == 'BASELINE'
